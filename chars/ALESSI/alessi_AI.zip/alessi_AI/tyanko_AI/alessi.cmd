﻿
;---|AI Commands|--------------------------------------------------------------
[Command]
name = "AI0"
command = a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a
time = 0
[Command]
name = "AI1"
command = b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b
time = 0
[Command]
name = "AI2"
command = c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c
time = 0
[Command]
name = "AI3"
command = x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x
time = 0
[Command]
name = "AI4"
command = y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y
time = 0
[Command]
name = "AI5"
command = z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI6"
command = s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s
time = 0
[Command]
name = "AI7"
command = F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F
time = 0
[Command]
name = "AI8"
command = D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D
time = 0
[Command]
name = "AI9"
command = B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B
time = 0
[Command]
name = "AI10"
command = U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U
time = 0
[Command]
name = "AI11"
command = a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a
time = 0
[Command]
name = "AI12"
command = c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c
time = 0
[Command]
name = "AI13"
command = x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x
time = 0
[Command]
name = "AI14"
command = y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y
time = 0
[Command]
name = "AI15"
command = z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI16"
command = s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s
time = 0
[Command]
name = "AI17"
command = a,B,c,x,y,z,s,B,D,F,U,a,b,c,x,y,z,s,s
time = 0
[Command]
name = "AI18"
command = a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a
time = 0
[Command]
name = "AI19"
command = b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b
time = 0
[Command]
name = "AI20"
command = c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c
time = 0
[Command]
name = "AI21"
command = x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x
time = 0
[Command]
name = "AI22"
command = y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y
time = 0
[Command]
name = "AI23"
command = z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI24"
command = s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s
time = 0
[Command]
name = "AI25"
command = F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F
time = 0
[Command]
name = "AI26"
command = D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D
time = 0
[Command]
name = "AI27"
command = B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B
time = 0
[Command]
name = "AI28"
command = U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U
time = 0
[Command]
name = "AI29"
command = a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a
time = 0
[Command]
name = "AI30"
command = c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c
time = 0
[Command]
name = "AI31"
command = x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x
time = 0
[Command]
name = "AI32"
command = y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y
time = 0
[Command]
name = "AI33"
command = z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI34"
command = s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s
time = 0
[Command]
name = "AI35"
command = z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI36"
command = z,z,z,z,z,z,a,a,a,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI37"
command = z,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,z,z,z
time = 0
[Command]
name = "AI38"
command = z,z,z,z,z,a,a,a,z,z,z,z,z,a,a,a,z,z,z
time = 0
[Command]
name = "AI39"
command = z,z,z,z,z,a,a,a,z,z,z,z,z,z,a,a,z,z,z
time = 0
[Command]
name = "AI40"
command = z,z,z,z,a,a,a,z,z,z,z,a,z,z,a,a,z,z,z
time = 0
[Command]
name = "AI41"
command = z,z,z,a,z,z,z,z,z,z,z,z,z,a,a,z,z,z,z
time = 0
[Command]
name = "AI42"
command = z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI43"
command = z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,a,a,z
time = 0
[Command]
name = "AI44"
command = z,z,a,a,a,a,z,z,z,z,z,z,z,z,z,a,a,a,z
time = 0
[Command]
name = "AI45"
command = z,z,z,z,z,z,a,a,z,z,z,z,z,a,a,a,a,z,z
time = 0
[Command]
name = "AI46"
command = z,z,z,z,z,z,z,z,a,a,a,a,a,a,z,z,z,z,z
time = 0
[Command]
name = "AI47"
command = z,z,z,a,a,a,a,z,z,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI48"
command = z,z,z,z,z,a,a,a,z,z,z,a,a,a,z,z,a,z,a
time = 0
[Command]
name = "AI49"
command = z,z,z,z,a,a,a,z,z,z,z,z,a,a,a,z,z,z,z
time = 0
[Command]
name = "AI50"
command = z,z,z,a,a,z,z,z,z,z,z,z,z,z,a,a,z,z,z
time = 0

[Remap]
x = x      ;Ｘボタンの入力判定を実際に押すボタンに割り当てる。
y = y      ;Ｙボタン　　　　　　　　　〃
z = z      ;Ｚボタン　　　　　　　　　〃
a = a      ;Ａボタン　　　　　　　　　〃
b = b      ;Ｂボタン　　　　　　　　　〃
c = c      ;Ｃボタン　　　　　　　　　〃
s = s      ;スタートボタン　　　　　　〃
;-| 超必殺技 |-----------------------------------------------------------------

[Command]
name = "236aa"
command = ~D,DF,F,x+y
time = 16

[Command]
name = "236aa"
command = ~D,DF,F,y+z
time = 16

[Command]
name = "236aa"
command = ~D,DF,F,x+z
time = 16

[Command]
name = "214aa"
command = ~D,DB,B,x+y
time = 16

[Command]
name = "214aa"
command = ~D,DB,B,y+z
time = 16

[Command]
name = "214aa"
command = ~D,DB,B,x+z
time = 16

[Command]
name = "214s"
command = ~D,DB,B,a
time = 16

[Command]
name = "214s"
command = ~D,DB,B,~a
time = 16

;------------------------------------------------------------------------------
;-| 必殺技 |-------------------------------------------------------------------

[Command]
name = "41236x"
command = ~B,DB,D,DF,F,x
time = 18
[Command]
name = "41236x"
command = ~B,DB,D,DF,F,~x
time = 18

[Command]
name = "41236y"
command = ~B,DB,D,DF,F,y
time = 18
[Command]
name = "41236y"
command = ~B,DB,D,DF,F,~y
time = 18

[Command]
name = "41236z"
command = ~B,DB,D,DF,F,z
time = 18
[Command]
name = "41236z"
command = ~B,DB,D,DF,F,~z
time = 18

[Command]
name = "41236b"
command = ~B,DB,D,DF,F,b
time = 18
[Command]
name = "41236b"
command = ~B,DB,D,DF,F,~b
time = 18

;
[Command]
name = "63214x"
command = ~F,DF,D,DB,B,x
time = 18
[Command]
name = "63214x"
command = ~F,DF,D,DB,B,~x
time = 18

[Command]
name = "63214y"
command = ~F,DF,D,DB,B,y
time = 18
[Command]
name = "63214y"
command = ~F,DF,D,DB,B,~y
time = 18

[Command]
name = "63214z"
command = ~F,DF,D,DB,B,z
time = 18
[Command]
name = "63214z"
command = ~F,DF,D,DB,B,~z
time = 18

[Command]
name = "63214b"
command = ~F,DF,D,DB,B,b
time = 18
[Command]
name = "63214b"
command = ~F,DF,D,DB,B,~b
time = 18

;

[Command]
name = "236b"
command = ~D,DF,F,b
time = 12
[Command]
name = "236b"
command = ~D,DF,F,~b
time = 12


[Command]
name = "214b"
command = ~D,DB,B,b
time = 12
[Command]
name = "214b"
command = ~D,DB,B,~b
time = 12

[Command]
name = "236s"
command = ~D,DF,F,a
time = 12
[Command]
name = "236s"
command = ~D,DF,F,~a
time = 12

;
[Command]
name = "623x"
command = ~F,D,DF,x
time = 12
[Command]
name = "623x"
command = ~F,D,DF,~x
time = 12

[Command]
name = "623y"
command = ~F,D,DF,y
time = 12
[Command]
name = "623y"
command = ~F,D,DF,~y
time = 12

[Command]
name = "623z"
command = ~F,D,DF,z
time = 12
[Command]
name = "623z"
command = ~F,D,DF,~z
time = 12

[Command]
name = "623b"
command = ~F,D,DF,b
time = 12
[Command]
name = "623b"
command = ~F,D,DF,~b
time = 12

[Command]
name = "longjump"
command = $D, $U
time = 10

;------------------------------------------------------------------------------
;-| キー２回連続入力 |---------------------------------------------------------

[Command]
name = "FF"
command = F,F
time = 10

[Command]
name = "BB"
command = B,B
time = 10

;------------------------------------------------------------------------------
;-| 同時押し |-----------------------------------------------------------------

[Command]
name = "recovery" ;必須コマンド名
command = a+b
time = 1

[Command]
name = "recovery" ;必須コマンド名
command = x+y
time = 1

;------------------------------------------------------------------------------
;-| 方向キー＋ボタン |---------------------------------------------------------

[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;------------------------------------------------------------------------------
;-| ボタン単発 |---------------------------------------------------------------

[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

[Command]
name = "xy"
command = x+y
time = 1

[Command]
name = "yz"
command = y+z
time = 1

[Command]
name = "xz"
command = x+z
time = 1

[Command]
name = "xyz"
command = x+y+z
time = 1

;------------------------------------------------------------------------------
;-| 方向キー |-----------------------------------------------------------------

[Command]
name = "holdfwd"   ;必須コマンド名
command = /$F
time = 1

[Command]
name = "holdback"  ;必須コマンド名
command = /$B
time = 1

[Command]
name = "holdup"    ;必須コマンド名
command = /$U
time = 1

[Command]
name = "holddown"  ;必須コマンド名
command = /$D
time = 1

;------------------------------------------------------------------------------

[Command]
name = "holdx"	   ;必須コマンド名
command = /x
time = 1

[Command]
name = "holdy"	   ;必須コマンド名
command = /y
time = 1

[Command]
name = "holdz"	   ;必須コマンド名
command = /z
time = 1

[Command]
name = "holda"	   ;必須コマンド名
command = /a
time = 1

[Command]
name = "holdb"	   ;必須コマンド名
command = /b
time = 1
[Command]
name = "fwd"   ;必須コマンド名
command = F
time = 1
[Command]
name = "back"
command = B
time = 1

[Statedef -1] ;←この行は絶対に消さないでね。必須項目です。

[State -1, AI起動用ヘルパー]
type=helper
Triggerall=!ishelper
Triggerall=Roundstate<2||(Roundstate=2&&Ctrl)
Trigger1=!Numhelper(11000+id)&&!Numhelper(11000)
Trigger1=Alive
Trigger1=var(59)=0
helpertype=normal
name="AI"
stateno =11000
ID=11000+id
pos=9999,9999
keyCtrl=1
pausemovetime=2147483647
supermovetime=2147483647
persistent = 0

[State -1, ↑が余計なことしないように]
type=ChangeState
Trigger1= ishelper
Trigger1= ishelper(11000+root,id)
Trigger1= stateno !=11000
value=11000

[State -1, AI_F]
type =null;varSet
trigger1 = stateno= 3500||enemy,Movetype=H
;trigger2 = statetype = A
;trigger3 = stateno = 3500
var(59) = 4
IgnoreHitPause = 1
Persistent = 1

[State -1, AI_F]
type = null;VarSet
trigger1 =enemy,statetype != A
var(59) = 0
IgnoreHitPause = 1
Persistent = 1

[State -1, AI_F]
type = VarSet
Triggerall = (var(59) <= 0)&&!IsHelper
Trigger1 = Command="AI0"||Command="AI1"
Trigger2 = Command="AI2"||Command="AI3"
Trigger3 = Command="AI4"||Command="AI5"
Trigger4 = Command="AI6"||Command="AI7"
Trigger5 = Command="AI8"||Command="AI9"
Trigger6 = Command="AI10"||Command="AI11"
Trigger7 = Command="AI12"||Command="AI13"
Trigger8 = Command="AI14"||Command="AI15"
Trigger9 = Command="AI16"||Command="AI17"
Trigger10= Command="AI18"||Command="AI19"
Trigger11= Command="AI20"||Command="AI21"
Trigger12= Command="AI22"||Command="AI23"
Trigger13= Command="AI24"||Command="AI25"
Trigger14= Command="AI26"||Command="AI27"
Trigger15= Command="AI28"||Command="AI29"
Trigger16= Command="AI30"||Command="AI31"
Trigger17= Command="AI32"||Command="AI33"
Trigger18= Command="AI34"||Command="AI35"
Trigger19= Command="AI36"||Command="AI37"
Trigger20= Command="AI38"||Command="AI39"
Trigger21= Command="AI40"||Command="AI41"
Trigger22= Command="AI42"||Command="AI43"
Trigger23= Command="AI44"||Command="AI45"
Trigger24= Command="AI46"||Command="AI47"
Trigger25= Command="AI48"||Command="AI49"
Trigger26= Command="AI50"
Trigger27= var(59)=0
Trigger27= numhelper(11000+id)
Trigger27= helper(11000+id),var(59)>0
;Trigger28= 1 ;←AI制御スイッチ　左端の「;」を消すとAI常時起動になります
var(59) = 2 ;←AIレベルはここで変更します(1～4まで デフォルトは2)
IgnoreHitPause = 1
Persistent = 1


;==============================================================================
;設定
;==============================================================================
;画面端検出ヘルパー
[State -1, 画面右端検出用ヘルパー]
type  = helper
Trigger1 = !NumHelper(21000)
helpertype = normal
name = "migihasi"
PosType = left 
stateno = 21000
ID = 21000
facing = -1
pos=160,9999
pausemovetime  = 2147483647
supermovetime  = 2147483647
persistent = 0
ignorehitpause = 1
keyctrl = 0
ownpal = 1

[State -1, 念のため↓も付けておく]
type=ChangeState
Trigger1= ishelper
Trigger1= ishelper(21000)
Trigger1= stateno !=21000
value=21000

[State -1, 画面左端検出用ヘルパー]
type = helper
Trigger1 = !NumHelper(25000)
helpertype = normal
name = "hidarihasi"
PosType = left
stateno = 25000
ID = 25000
facing = 1
pos=160,9999
pausemovetime  = 2147483647
supermovetime  = 2147483647
persistent = 0
ignorehitpause = 1
keyctrl = 0
ownpal = 1

[State -1, 念のため↓も付けておく]
type=ChangeState
Trigger1= ishelper
Trigger1= ishelper(25000)
Trigger1= stateno !=25000
value=25000

[State -1, ガード用ヘルパー]
type = helper
Trigger1 = !NumHelper(21474)
helpertype = normal
name = "guard1"
PosType = P1
stateno = 21474
ID = 21474
facing = -1
pos=0,0;9999
pausemovetime  = 2147483647
supermovetime  = 2147483647
persistent = 0
ignorehitpause = 1
keyctrl = 0
ownpal = 1

[State -1, 念のため↓も付けておく]
type=ChangeState
Trigger1= ishelper
Trigger1= ishelper(21474)
Trigger1= stateno !=21474
value=21474


;フライング防止用
[State -1,ctrl確認]
type = varset
Trigger1 = var(49) = 0
Trigger1 = ctrl && RoundState = 2
var(49) = 1

[State -1,ctrl確認リセット]
type = varset
Trigger1 = var(49) = 1
Trigger1 = RoundState != 2
var(49) = 0


[State -1, タッグ用敵生死判別]
Type = VarSet
trigger1 = NumEnemy = 1
trigger2 = NumEnemy = 2
trigger2 = EnemyNear,life > 0
trigger2 = EnemyNear,stateno != 5150
trigger3 = NumEnemy = 2
trigger3 = EnemyNear,life <= 0
trigger3 = EnemyNear,statetype = A
trigger3 = (EnemyNear,stateno = [5000,5081])
trigger3 = (EnemyNear(1),stateno != [5000,5081])
trigger4 = NumEnemy = 2
trigger4 = EnemyNear,life <= 0
trigger4 = EnemyNear,statetype = L 
trigger4 = EnemyNear,stateno = [5080,5110]
trigger4 = EnemyNear(1),stateno != [5000,5110]
trigger5 = NumEnemy = 2
trigger5 = EnemyNear,life <= 0
trigger5 = EnemyNear,statetype = L
trigger5 = (EnemyNear,stateno = [5080,5110])
trigger5 = EnemyNear(1),statetype != A&&EnemyNear(1),statetype != L
trigger6 = NumEnemy = 2
trigger6 = EnemyNear,life <= 0
trigger6 = EnemyNear,statetype = A
trigger6 = (EnemyNear,stateno != [5000,5081])
trigger7 = NumEnemy = 2
trigger7 = EnemyNear,life <= 0
trigger7 = EnemyNear,statetype != A&&EnemyNear,statetype != L
trigger8 = NumEnemy = 2
trigger8 = EnemyNear,life <= 0
trigger8 = EnemyNear,statetype = L 
trigger8 = (EnemyNear,stateno != [5080,5110])&& EnemyNear,stateno != 5150
var(58) = 0
IgnoreHitPause = 1

[State -1, タッグ用敵生死判別]
Type = VarSet
triggerall = NumEnemy = 2
triggerall = EnemyNear,life <= 0
trigger1 = EnemyNear,statetype = A
trigger1 = (EnemyNear,stateno = [5000,5081])
trigger1 = (EnemyNear(1),stateno = [5000,5081])
trigger2 = EnemyNear,statetype = L
trigger2 = (EnemyNear,stateno = [5080,5110])
trigger2 = EnemyNear(1),statetype = A||EnemyNear(1),statetype = L
trigger2 = (EnemyNear(1),stateno = [5000,5110])
var(58) = 1
IgnoreHitPause = 1

[State -1, タッグ用敵生死判別]
Type = VarSet
trigger1 = NumEnemy = 2
trigger1 = EnemyNear,stateno = 5150
var(58) = 1
IgnoreHitPause = 1

[State -1, タッグ用人数判別]
Type = VarSet
Trigger1 = numpartner = 1
Trigger1 = partner,Alive
trigger2 = NumEnemy >= 3
var(57) = 0
IgnoreHitPause = 1

[State -1, タッグ用人数判別]
Type = VarSet
Triggerall = numpartner = 1
Triggerall = partner,Alive
Trigger1 = NumEnemy = 2
Trigger1 = !Enemy(0),Alive || !Enemy(1),Alive
Trigger2 = NumEnemy = 1
var(57) = 1
IgnoreHitPause = 1

[State -1, タッグ用人数判別]
Type = VarSet
Trigger1 = numpartner = 0
Trigger1 = NumEnemy = 1
Trigger2 = numpartner = 1
Trigger2 = !partner,Alive
Trigger2 = NumEnemy = 2
Trigger2 = !Enemy(0),Alive || !Enemy(1),Alive
Trigger3 = numpartner = 0
Trigger3 = NumEnemy = 2
Trigger3 = !Enemy(0),Alive || !Enemy(1),Alive
Trigger4 = numpartner = 1
Trigger4 = !partner,Alive
Trigger4 = NumEnemy = 1
var(57) = 2
IgnoreHitPause = 1

[State -1, タッグ用人数判別]
Type = VarSet
Trigger1 = numpartner = 1
Trigger1 = !partner,Alive
Trigger1 = NumEnemy = 2
Trigger1 = Enemy(0),Alive && Enemy(1),Alive
Trigger2 = numpartner = 0
Trigger2 = NumEnemy = 2
Trigger2 = Enemy(0),Alive && Enemy(1),Alive
var(57) = 3
IgnoreHitPause = 1

[State -1, コンボ分岐]
type = VarRandom
trigger1 = 1
v = 47
range = 0,11

[State -2, 移動起き上がり判別]
type = VarSet
triggerall = var(39) = 0
Triggerall = enemynear(var(58)),Movetype = H
triggerall = enemynear(var(58)),Stateno != [5296,5300]
trigger1 = enemynear(var(58)),statetype = A
trigger2 = enemynear(var(58)),Statetype = L
var(39) = 2

[State -2, 移動起き上がり判別]
type = VarSet
triggerall = var(39) = 2
Triggerall = enemynear(var(58)),Alive
triggerall = enemynear(var(58)),stateno != 5201&&enemynear(var(58)),stateno != 5210
trigger1 = enemynear(var(58)),statetype = A
trigger2 = enemynear(var(58)),Statetype = L
var(39) = 1

[State -2, 移動起き上がり判別]
type = VarSet
triggerall = var(39) = [1,2]
Trigger1 = enemynear(var(58)),Alive=0
trigger2 = enemynear(var(58)),stateno = 5120||enemynear(var(58)),stateno = 5201||enemynear(var(58)),stateno = 5210||enemynear(var(58)),stateno =[5100,5101]
trigger3 = (enemynear(var(58)),Anim = [0,22])||(enemynear(var(58)),stateno=[120,155])||(enemynear(var(58)),Anim = [40,52])||(enemynear(var(58)),Anim = [100,110])
trigger4 = enemynear(var(58)),Movetype = A
trigger5 = enemynear(var(58)),Anim = 5300||enemynear(var(58)),stateno = 5300
trigger6 = enemynear(var(58)),statetype != A
trigger6 = (enemynear(var(58)),stateno = [5000,5081])

trigger7 = (enemynear(var(58)),stateno=[5652,5654])||(enemynear(var(58)),stateno=[51200,51203])||(enemynear(var(58)),stateno=[51210,51213])
var(39) = 0

[State -2, 簡易スカリ認識]
type = VarSet
triggerall = var(39) = [3,4]
trigger1 = enemynear(var(58)),statetype = A||enemynear(var(58)),statetype = L
trigger2 = Movecontact ||Anim=[810,811]
trigger3 = (enemynear(var(58)),stateno = [5000,5081])||(enemynear(var(58)),stateno = [150,155])
trigger4 = Movetype = H
trigger5 = enemynear(var(58)),facing != facing
trigger5 = Movetype != A
trigger5 = (enemynear(var(58)),stateno = [0,55])||(enemynear(var(58)),stateno = [100,119])
trigger6 = (var(57) = [0,1])||var(59) != [3,4]
trigger7 = random = 999
trigger8 = numhelper(10010)
trigger8 = helper(10010),Movecontact
var(39) = 0


;==============================================================================
; 超必殺技
;==============================================================================
;絶望ォォォだねッ！
[State -1, 3000]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "236aa" || command = "236b") || (var(36)&2**7)
triggerall = !var(8)
triggerall = !var(13)
triggerall = power >= 1000
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1) || stateno = 40
trigger2 = stateno = 200
trigger3 = stateno = 210
trigger4 = stateno = 220
trigger5 = stateno = 400
trigger6 = stateno = 410
trigger7 = stateno = 420
trigger8 = stateno = 195 && time >= 20
trigger9 = stateno = 5201
value = 3000

;Soffウシウシウシッ！
[State -1, 3000]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "214aa" || command = "214b") || (var(36)&2**8)
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = power >= 1000
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1) || stateno = 40
trigger2 = stateno = 200
trigger3 = stateno = 210
trigger4 = stateno = 220
trigger5 = stateno = 400
trigger6 = stateno = 410
trigger7 = stateno = 420
trigger8 = stateno = 195 && time >= 20
trigger9 = stateno = 5201
value = 3100

;Sonウシウシウシッ！
[State -1, 3000]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "214aa" || command = "214b") || (var(36)&2**8)
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = power >= 1000
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1) || stateno = 40
trigger2 = stateno = 200
trigger3 = stateno = 210
trigger4 = stateno = 220
trigger5 = stateno = 400
trigger6 = stateno = 410
trigger7 = stateno = 195 && time >= 20
trigger8 = stateno = 5201
value = 3200

;タンデム
[State -1,Light Kung Fu Knee]
type = ChangeState
triggerall = var(59) <= 0
triggerall = !numhelper(3509)
triggerall = (command = "214s") || (var(36)&2**9)
triggerall = statetype != A
triggerall = power >= 1000
triggerall = !var(8) || var(0)
triggerall = !var(13)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1) || stateno = 40
trigger2 = stateno = 200
trigger3 = stateno = 210
trigger4 = stateno = 220
trigger5 = stateno = 400
trigger6 = stateno = 410
trigger7 = stateno = 420
trigger8 = stateno = 11200
trigger9 = stateno = 700 && var(0) && (var(6)&1048576)
trigger10 = stateno = 195 && time >= 20
trigger11 = stateno = 5201
value = 3500

;==============================================================================
; 必殺技(共通)
;==============================================================================
;蜂の巣だッ！
[State -1, 1000]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "41236x" || command = "41236y" || command = "41236z" || command = "41236b" || (var(36)&2**0) || (var(36)&2**1) || (var(36)&2**2)
triggerall = !var(8)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1) || stateno = 40
trigger2 = stateno = 200
trigger3 = stateno = 210
trigger4 = stateno = 220
trigger5 = stateno = 250
trigger6 = stateno = 260
trigger7 = stateno = 265
trigger8 = stateno = 270
trigger9 = stateno = 271
trigger10= stateno = 275
trigger11= stateno = 400
trigger12= stateno = 410
trigger13= stateno = 420
trigger14= stateno = 450
trigger15= stateno = 195 && time >= 20
trigger16= stateno = 5201
value = 1000

;==============================================================================
; 必殺技(Son)
;==============================================================================
;ガキンチョがッ！
[State -1, 1000]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "63214x" || command = "63214y" || command = "63214z" || command = "63214b" || (var(36)&2**3) || (var(36)&2**4) || (var(36)&2**5)
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1) || stateno = 40
trigger2 = stateno = 200
trigger3 = stateno = 210
trigger4 = stateno = 220
trigger5 = stateno = 400
trigger6 = stateno = 410
trigger7 = stateno = 195 && time >= 20
trigger8 = stateno = 5201
value = 11100

;カッサバイてやるッ！
[State -1, 1000]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = var(25)
triggerall = var(0)
triggerall = !var(8)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1) || stateno = 40
trigger2 = stateno = 200
trigger3 = stateno = 210
trigger4 = stateno = 220
trigger5 = stateno = 400
trigger6 = stateno = 410
trigger7 = stateno = 195 && time >= 20
trigger8 = stateno = 5201
value = 11200

;==============================================================================
; 必殺技(Soff)
;==============================================================================
;ガキンチョがッ！
[State -1, 1000]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "63214x" || command = "63214y" || command = "63214z" || command = "63214b" || (var(36)&2**3) || (var(36)&2**4) || (var(36)&2**5)
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1) || stateno = 40
trigger2 = stateno = 200
trigger3 = stateno = 210
trigger4 = stateno = 220
trigger5 = stateno = 400
trigger6 = stateno = 410
trigger7 = stateno = 420
trigger8 = stateno = 195 && time >= 20
trigger9 = stateno = 5201
value = 1100

;==============================================================================
; 超必殺技(デム)
;==============================================================================
;絶望ォォォだねッ！
[State -1, 1000]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "236aa" || command = "236b") || (var(36)&2**7)
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = power >= 1000
triggerall = var(31)
trigger1 = stateno = 3501
trigger2 = stateno = 3700
trigger3 = stateno = 3701
trigger4 = stateno = 3702
trigger5 = stateno = 3900
trigger6 = stateno = 3901
value = 3940

;ウシウシウシッ！
[State -1, 1000]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "214aa" || command = "214b") || (var(36)&2**8)
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = power >= 1000
triggerall = var(31)
trigger1 = stateno = 3501
trigger2 = stateno = 3700
trigger3 = stateno = 3701
trigger4 = stateno = 3702
trigger5 = stateno = 3900
trigger6 = stateno = 3901
value = 3950

;==============================================================================
; 必殺技(デム)
;==============================================================================
;蜂の巣だッ！
[State -1, 1000]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "41236x" || command = "41236y" || command = "41236z" || command = "41236b" || (var(36)&2**0) || (var(36)&2**1) || (var(36)&2**2)
triggerall = var(31)
triggerall = !var(8)
trigger1 = stateno = 3501
trigger2 = stateno = 3700
trigger3 = stateno = 3701
trigger4 = stateno = 3702
trigger5 = stateno = 3900
trigger6 = stateno = 3901
value = 3910

;ガキンチョがッ！
[State -1, 1000]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "63214x" || command = "63214y" || command = "63214z" || command = "63214b" || (var(36)&2**3) || (var(36)&2**4) || (var(36)&2**5)
triggerall = var(31)
triggerall = !var(8)
triggerall = !var(13)
trigger1 = stateno = 3501
trigger2 = stateno = 3700
trigger3 = stateno = 3701
trigger4 = stateno = 3702
trigger5 = stateno = 3900
trigger6 = stateno = 3901
value = 3920

;カッサバイてやるッ！
[State -1, 1000]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = var(25)
triggerall = var(31)
triggerall = !var(8)
trigger1 = stateno = 3501
trigger2 = stateno = 3700
trigger3 = stateno = 3701
trigger4 = stateno = 3702
trigger5 = stateno = 3900
trigger6 = stateno = 3901
value = 3930

;==============================================================================
[State -1, Stand ON攻撃]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "236s" || (var(36)&2**9)
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(48)
triggerall = !var(13)
triggerall = stateno != 900
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1) || stateno = 40
trigger2 = stateno = 200
trigger3 = stateno = 210
trigger4 = stateno = 220
trigger5 = stateno = 400
trigger6 = stateno = 410
trigger7 = stateno = 420
trigger8 = stateno = 195 && time >= 20
trigger9 = stateno = 5201
value = 10950

[State -1, Stand ON]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "a"
triggerall = !var(0)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1) || stateno = 40
value = 10900

[State -1, Stand ON(Air)]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = command = "a"
triggerall = !var(0)
triggerall = !var(48)
triggerall = stateno != 910
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1) || stateno = 40
value = 10910

[State -1, Stand OFF]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "a"
triggerall = var(0)
triggerall = !var(48)
triggerall = stateno != 10900
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1) || stateno = 40
value = 900

[State -1, Stand OFF(Air)]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = command = "a"
triggerall = var(0)
triggerall = !var(48)
triggerall = stateno != 10910
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1) || stateno = 40
value = 910

;==============================================================================
; 移動関連
;==============================================================================
[State -1,Run]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype = S
triggerall = command = "FF"
trigger1 = ctrl
value = 100

[State -1, Back Run]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype = S
triggerall = command = "BB"
trigger1 = ctrl
value = 105

;==============================================================================
; 特殊技
;==============================================================================
[State -1, ガードキャンセル]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "623x" || command = "623y" || command = "623z" || command = "623b"
triggerall = prevstateno != [710,711]
trigger1 = ((helper(20032*(numhelper(20032)>0)),var(10)) = 0)
trigger1 = (stateno = 151 || stateno = 153)
trigger1 = time <= 5
trigger2 = ((helper(20032*(numhelper(20032)>0)),var(10)) = 1)
trigger2 = power >= 1000
trigger2 = (stateno = [150,153])
trigger2 = time > 0
value = 700

[State -1, アドバンシングガード]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "recovery" || command = "b"
triggerall = prevstateno != [710,711]
triggerall = ((helper(20032*(numhelper(20032)>0)),var(10)) = 0)
trigger1 = stateno = [150,153]
trigger1 = time > 0
value = 710

[State -1, 回り込み]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "xyz" || command = "b"
triggerall = !var(0)
triggerall = !var(56)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1) || stateno = 40
value = 300

[State -1,  投げ]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "z" && command != "holddown" && (command = "holdfwd" || command = "holdback")
triggerall = p2bodydist x = [-23,23]
triggerall = p2statetype != A && p2statetype != L && p2movetype != H
triggerall = !((prevstateno = [100,105]) && time < 8)
triggerall = !var(13)
triggerall = !fvar(7)
trigger1 = ctrl
value = 800

;==============================================================================
; 子供化時通常攻撃技
;==============================================================================
[State -1, Soffダッシュ攻撃]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "x" || command = "y" || command = "z")
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
trigger1 = ((stateno = 100 || stateno = 105) && time > 1)
value = 271

[State -1, Soff弱]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "x" || (command = "b" && var(56)>0)) && command != "holddown"
triggerall = (!var(0) || (p2bodydist x = [-5,30]))
triggerall = !var(8)
triggerall = var(13)
trigger1 = ctrl
value = 250

[State -1, Soff近中]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "y" && command != "holddown"
triggerall = (p2bodydist x = [-5,40])
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
trigger1 = ctrl
value = 265

[State -1, Soff中]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "y" && command != "holddown"
triggerall = (!var(0) || (p2bodydist x = [-5,30]))
triggerall = !var(8)
triggerall = var(13)
trigger1 = ctrl
value = 260

[State -1, Soff近強]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "z" && command != "holddown"
triggerall = (p2bodydist x = [-5,30])
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
trigger1 = ctrl
value = 275

[State -1, Soff強]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "z" && command != "holddown"
triggerall = (!var(0) || (p2bodydist x = [-5,40]))
triggerall = !var(8)
triggerall = var(13)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1 && !var(0))
value = 270

[State -1, Soff屈攻撃]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "x" || command = "y" || command = "z") && command = "holddown"
triggerall = (!var(0) || (p2bodydist x = [-5,40]))
triggerall = !var(8)
triggerall = var(13)
trigger1 = ctrl
value = 450

;==============================================================================
; 通常攻撃技
;==============================================================================
[State -1, Soff弱(Son近弱)]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "x" || (command = "b" && var(56)>0)) && command != "holddown"
triggerall = (!var(0) || (p2bodydist x = [-5,30]))
triggerall = !var(8)
triggerall = !var(13)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1 && !var(0))
trigger2 = StateNo = 200 && (prevstateno != [100,105]) && animelemtime(4) >= 0
value = 200

[State -1, Soff中(Son近中)]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "y" && command != "holddown"
triggerall = (!var(0) || ((p2bodydist x = [-5,30]) && command != "holdfwd"))
triggerall = !var(8)
triggerall = !var(13)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1 && !var(0))
value = 210

[State -1, Soff強(Son近強)]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "z" && command != "holddown"
triggerall = (!var(0) || (p2bodydist x = [-5,40]))
triggerall = !var(8)
triggerall = !var(13)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1 && !var(0))
value = 220

[State -1, Soff屈弱]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "x" || (command = "b" && var(56)>0)) && command = "holddown"
triggerall = (!var(0) || (p2bodydist x = [-5,40]))
triggerall = !var(8)
triggerall = !var(13)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1 && !var(0))
trigger2 = StateNo = 200 && (prevstateno != [100,105]) && animelemtime(4) >= 0
value = 400

;近6中はなぜかSoff屈中が出る

[State -1, Soff屈中]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "y" && (command = "holddown" || (var(0) && command = "holdfwd"))
triggerall = (!var(0) || (p2bodydist x = [-5,40]))
triggerall = !var(8)
triggerall = !var(13)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1 && !var(0))
value = 410

[State -1, Soff屈強]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "z" && command = "holddown"
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time > 1 && !var(0))
value = 420

;------------------------------------------------------------------------------
[State -1, Son6中]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "y" && command = "holdfwd" && command != "holddown"
triggerall = var(0)
triggerall = !var(8)
trigger1 = ctrl
value = 10212

[State -1, SonD弱]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "x" || command = "b")
triggerall = var(0)
triggerall = !var(8)
trigger1 = (stateno = 100 || stateno = 105) && time > 1
value = 10201

[State -1, SonD中]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "y"
triggerall = var(0)
triggerall = !var(8)
trigger1 = (stateno = 100 || stateno = 105) && time > 1
value = 10211

[State -1, SonD強]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "z"
triggerall = var(0)
triggerall = !var(8)
trigger1 = (stateno = 100 || stateno = 105) && time > 1
value = 10221

[State -1, Son弱]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "x" || command = "b") && command != "holddown"
triggerall = var(0)
triggerall = !var(8)
trigger1 = ctrl
value = 10200

[State -1, Son中]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "y" && command != "holddown"
triggerall = var(0)
triggerall = !var(8)
trigger1 = ctrl
value = 10210

[State -1, Son強]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "z" && command != "holddown"
triggerall = var(0)
triggerall = !var(8)
trigger1 = ctrl
value = 10220

[State -1, Son屈弱]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "x" || command = "b") && command = "holddown"
triggerall = var(0)
triggerall = !var(8)
trigger1 = ctrl
value = 10400

[State -1, Son屈中]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "y" && command = "holddown"
triggerall = var(0)
triggerall = !var(8)
trigger1 = ctrl
value = 10410

[State -1, Son屈中]
type = ChangeState
triggerall = var(59) <= 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "z" && command = "holddown"
triggerall = var(0)
triggerall = !var(8)
trigger1 = ctrl
value = 10420

;------------------------------------------------------------------------------
[State -1, off挑発]
type = ChangeState
value = 195
triggerall = var(59) <= 0
triggerall = command = "start"
trigger1 = statetype != A
trigger1 = ctrl

;------------------------------------------------------------------------------
[State -1, ジャンプ弱(SonJ弱)]
type = ChangeState
value = 600
triggerall = var(59) <= 0
triggerall = command = "x" || command = "b"
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = stateno = 910
trigger3 = stateno = 10910

[State -1, Soffジャンプ中]
type = ChangeState
value = 610
triggerall = var(59) <= 0
triggerall = !var(0)
triggerall = command = "y"
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = stateno = 910

[State -1, Soffジャンプ強]
type = ChangeState
value = 620
triggerall = var(59) <= 0
triggerall = !var(0)
triggerall = command = "z"
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = stateno = 910

[State -1, Sonジャンプ中]
type = ChangeState
value = 10610
triggerall = var(59) <= 0
triggerall = var(0)
triggerall = command = "y"
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = stateno = 10910

[State -1, Sonジャンプ強]
type = ChangeState
value = 10620
triggerall = var(59) <= 0
triggerall = var(0)
triggerall = command = "z"
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = stateno = 10910

;===========================================================================
; 優先行動
;===========================================================================

[State -1, カッサバイてやるッ！]
type = ChangeState
value = 11200
triggerall = var(59) > 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = var(25)
triggerall = var(0)
triggerall = !var(8)
trigger1 = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime)) || ((stateno = 100 || stateno = 105) && time > 1) || stateno = [40,44]
trigger2 = stateno = 200
trigger3 = stateno = 210
trigger4 = stateno = 220
trigger5 = stateno = 400
trigger6 = stateno = 410
trigger7 = stateno = 195 && time >= 20
trigger8 = stateno = 5201

[State -1, カッサバイてやるッ！]
type = ChangeState
value = 3930
triggerall = var(59) > 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = var(25)
triggerall = var(31)
triggerall = !var(8)
trigger1 = stateno = 3501
trigger2 = stateno = 3700
trigger3 = stateno = 3701
trigger4 = stateno = 3702
trigger5 = stateno = 3900
trigger6 = stateno = 3901

;===========================================================================
; 追撃
;===========================================================================

[state -1, Soffウシウシウシッ！]
type = changestate
value = 3100
triggerall = var(59) = [3,4]
Triggerall = var(57) != 3
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = statetype != A
triggerall = power >= 1000
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = EnemyNear(var(58)),Movetype = H
Triggerall = P2dist X > 0
trigger1 =  P2Dist Y + (enemynear(var(58)),Vel y*21)+(enemynear(var(58)),GetHitVar(Yaccel) *((21*(21-1)))/2) <=-1
Trigger1 = enemynear(var(58)),stateno=[5000,5050]
trigger1 = var(57) = 2 && (((floor(helper(21000),RootDist X) = [60,115]) && facing = 1)||((floor(helper(25000),RootDist X) = [60,115]) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist = [40,95]
trigger1 = stateno = 220
trigger1 = Movehit 
Trigger2 = enemynear(var(58)),stateno=[4000,4030]
trigger2 = P2bodydist X <= 62
trigger2 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno = 410||stateno = 420
trigger2 = Movehit 

[state -1, Sonウシウシウシッ！]
type = changestate
value = 3200
triggerall = var(59) = [3,4]
Triggerall = var(57) != 3
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = statetype != A
triggerall = power >= 1000
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = EnemyNear(var(58)),Movetype = H
Triggerall = P2dist X > 0
trigger1 =  P2Dist Y + (enemynear(var(58)),Vel y*21)+(enemynear(var(58)),GetHitVar(Yaccel) *((21*(21-1)))/2) <=-1
Trigger1 = enemynear(var(58)),stateno=[5000,5050]
trigger1 = var(57) = 2 && (((floor(helper(21000),RootDist X) = [60,115]) && facing = 1)||((floor(helper(25000),RootDist X) = [60,115]) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist = [40,95]
trigger1 = stateno = 220
trigger1 = Movehit 
Trigger2 = enemynear(var(58)),stateno=[4000,4030]
trigger2 = P2bodydist X <= 62
trigger2 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno = 410
trigger2 = Movehit 

[State -1, Stand ON攻撃]
type = ChangeState
value = 1100
triggerall = var(59) = [3,4]
Triggerall = var(57) != [0,1]
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
triggerall = var(57) = 2 && (((floor(helper(21000),RootDist X) <=115) && facing = 1)||((floor(helper(25000),RootDist X) <= 115) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist <= 95
Triggerall = P2dist X > 0
triggerall = stateno != 900
trigger1 =  (P2Dist Y + (enemynear(var(58)),Vel y*24)+(enemynear(var(58)),GetHitVar(Yaccel) *((24*(24-1)))/2) =[-80,5]) || (P2Dist Y + (enemynear(var(58)),Vel y*27)+(enemynear(var(58)),GetHitVar(Yaccel) *((27*(27-1)))/2) =[-20,5])
Trigger1 = (enemynear(var(58)),stateno=[5000,5050])
trigger1 = stateno = 220
trigger1 = Movehit 
Trigger2 = enemynear(var(58)),stateno=[4000,4030]
trigger2 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno = 410||stateno = 420
trigger2 = Movehit 
Trigger3 = enemynear(var(58)),stateno=5210||enemynear(var(58)),stateno=5201
trigger3 = (P2Dist Y + (enemynear(var(58)),Vel y*24)+(enemynear(var(58)),GetHitVar(Yaccel) *((24*(24-1)))/2) =[-80,5]) || (P2Dist Y + (enemynear(var(58)),Vel y*27)+(enemynear(var(58)),GetHitVar(Yaccel) *((27*(27-1)))/2) =[-20,5])
trigger3 = stateno = 220
trigger3 = Movehit 

[State -1, ガキンチョ]
type = ChangeState
value = 11100
triggerall = var(59) = [3,4]
Triggerall = var(57) != [0,1]
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = statetype != A
Triggerall = P2dist X > 0
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
triggerall = var(57) = 2 && (((floor(helper(21000),RootDist X) =[75,125]) && facing = 1)||((floor(helper(25000),RootDist X) = [75,125]) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist = [55,105]
triggerall = stateno != 900
Trigger1 = enemynear(var(58)),GetHitVar(fall)=0
trigger1 =  (P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),GetHitVar(Yaccel) *((15*(15-1)))/2) =[-10,5]) || (P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),GetHitVar(Yaccel) *((20*(20-1)))/2) =[-10,5])
Trigger1 = (enemynear(var(58)),stateno=[5000,5050])
trigger1 = stateno = 220
trigger1 = Movehit 
Trigger2 = enemynear(var(58)),stateno=5210||enemynear(var(58)),stateno=5201
trigger2 =  (P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),GetHitVar(Yaccel) *((15*(15-1)))/2) =[-10,5]) || (P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),GetHitVar(Yaccel) *((20*(20-1)))/2) =[-10,5])
trigger2 = stateno = 220
trigger2 = Movehit 

[state -1, ダッシュ]
type = changestate
value = 100
triggerall = var(59) = 4||var(59)=3&&life<=lifemax/2
triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = !Inguarddist
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),stateno=821||enemynear(var(58)),GetHitVar(ChainID)=700&&enemynear(var(58)),stateno=[5000,5050]
Triggerall = P2dist X > 0
triggerall = Prevstateno = 815||enemynear(var(58)),vel Y < 2
triggerall = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = !var(0)
trigger1 = var(57) = 2 && (((floor(helper(21000),RootDist X) <=160) && facing = 1)||((floor(helper(25000),RootDist X) <= 160) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist <= 140
trigger2 = var(0)
trigger2 = var(57) = 2 && (((floor(helper(21000),RootDist X) >230) && facing = 1)||((floor(helper(25000),RootDist X) > 230) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist > 205



[State -1, 蜂の巣だッ！]
type = ChangeState
value = 1000
triggerall = var(59) = 4||var(59)=3&&life<=lifemax/2
triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !Inguarddist
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),stateno=821||enemynear(var(58)),GetHitVar(ChainID)=700&&enemynear(var(58)),stateno=[5000,5050]
Triggerall = P2dist X > 0
triggerall = Prevstateno = 815||enemynear(var(58)),vel Y < 2
triggerall = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = !var(0)
trigger1 = var(57) = 2 && (((floor(helper(21000),RootDist X) >160) && facing = 1)||((floor(helper(25000),RootDist X) > 160) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist > 140
trigger1 = var(2) := 2

[State -1, SonD強]
type = ChangeState
value = 10221
triggerall = var(59) = 4||var(59)=3&&life<=lifemax/2
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !Inguarddist
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),stateno=821||enemynear(var(58)),GetHitVar(ChainID)=700&&enemynear(var(58)),stateno=[5000,5050]
Triggerall = P2dist X > 0
triggerall = var(0)
triggerall = !var(8)
triggerall = P2bodydist Y >= -50
trigger1 = stateno = 100 && time > 1


[state -1, 立ち弱]
type = changestate
value = 200
triggerall = var(59) = [3,4]
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Const(size.head.pos.y) <= -45
Triggerall = enemynear(var(58)),stateno=[5040,5050]
Triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -50
Triggerall = var(57) = 2
triggerall = enemynear(var(58)),gethitvar(fall)=0
triggerall = var(57) = 2 && (((floor(helper(21000),RootDist X) <= 105) && facing = 1)||((floor(helper(25000),RootDist X) <=105) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist <= 85
triggerall = p2bodydist x <= 38
trigger1 = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime)) || ((stateno = 100 || stateno = 105) && time > 1 && !var(0))
trigger2 = StateNo = 200 && (prevstateno != [100,105]) && animelemtime(4) >= 0
trigger2 = Movecontact

[state -1, 立ち強]
type = changestate
value = 220
triggerall =var(59) = 4||var(59)=3&&life<=lifemax/2
triggerall = var(49) = 1
triggerall = (!var(0) || (p2bodydist x = [-5,40]))
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = (enemynear(var(58)),stateno=[5000,5050])||(enemynear(var(58)),stateno=[4000,4030])||enemynear(var(58)),stateno=821
Triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -50
triggerall = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime)) || ((stateno = 100 || stateno = 105) && time > 1 && !var(0))
Trigger1 = var(57) != [0,1]
trigger1 = (!var(0)&&p2bodydist x <= ifelse((enemynear(var(58)),facing!=facing),30,40) || var(0)&&(p2bodydist x = [-5,30]))||stateno=100&&!var(0)&&p2bodydist x <= 40+vel X*8
Trigger2 = var(57) >= 0
trigger2 = var(57) = 2 && (((floor(helper(21000),RootDist X) <= 105) && facing = 1)||((floor(helper(25000),RootDist X) <=105) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist <= 85
trigger2 = (!var(0)&&p2bodydist x <= 44 || (p2bodydist x = [-5,40]))
trigger2 = random <= 200

[state -1, S立ち強]
type = changestate
value = 10220
triggerall = var(59) = 4||var(59)=3&&life<=lifemax/2
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = numhelper(10010)
triggerall = !Inguarddist&&!(helper(10010),Inguarddist)
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
triggerall = p2bodydist x > 40
Triggerall = P2dist X > 0
triggerall = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = enemynear(var(58)),Movetype = H
trigger1 = enemynear(var(58)),stateno=821||enemynear(var(58)),GetHitVar(ChainID)=700&&enemynear(var(58)),stateno=[5000,5050]
trigger1 =  P2Dist Y + (enemynear(var(58)),Vel y*10)+(enemynear(var(58)),GetHitVar(Yaccel) *((10*(10-1)))/2) = [-10,-1]
trigger2 = (enemynear(var(58)),gethitvar(fall)=0&&enemynear(var(58)),stateno = [5000,5040])||(enemynear(var(58)),gethitvar(fall)=1&&enemynear(var(58)),canrecover=0&&enemynear(var(58)),stateno = [5000,5081])
trigger2 = (P2Dist Y + (enemynear(var(58)),Vel y*10)+(enemynear(var(58)),GetHitVar(Yaccel) *((10*(10-1)))/2) = [-10,20])||P2Dist Y + (enemynear(var(58)),Vel y*8)+(enemynear(var(58)),GetHitVar(Yaccel) *((8*(8-1)))/2) = [-20,20]
trigger2 = (EnemyNear(var(58)),facing!=facing&&P2bodydist X>=41+EnemyNear(var(58)),Vel X*7+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing=facing&&P2bodydist X>=41+EnemyNear(var(58)),Vel X*-7+((fvar(10)-1)/0.02*1.35))
trigger2 = (EnemyNear(var(58)),facing!=facing&&P2bodydist X<=145+EnemyNear(var(58)),Vel X*7+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing=facing&&P2bodydist X>=145+EnemyNear(var(58)),Vel X*-7+((fvar(10)-1)/0.02*1.35))
trigger2 = enemynear(var(58)),gethitvar(fall)=0||enemynear(var(58)),gethitvar(fall)=1 &&Random <= 180
trigger3 = var(57) = 2 
Trigger3 = (enemynear(var(58)),gethitvar(fall)=0&&enemynear(var(58)),stateno = [5000,5040])||(enemynear(var(58)),gethitvar(fall)=1&&enemynear(var(58)),canrecover=0&&enemynear(var(58)),stateno = [5000,5081])
trigger3 = (P2Dist Y + (enemynear(var(58)),Vel y*10)+(enemynear(var(58)),GetHitVar(Yaccel) *((10*(10-1)))/2) = [-10,20])||P2Dist Y + (enemynear(var(58)),Vel y*8)+(enemynear(var(58)),GetHitVar(Yaccel) *((8*(8-1)))/2) = [-20,20]
Trigger3 = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
trigger3 =  helper(21000),RootDist X >= 115+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X >=115+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger3 =  helper(21000),RootDist X <= 190+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=190+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger3 = enemynear(var(58)),gethitvar(fall)=0||enemynear(var(58)),gethitvar(fall)=1 &&Random <= 180
trigger4 = var(57) != 2 
trigger4 = (enemynear(var(58)),gethitvar(fall)=0&&enemynear(var(58)),stateno = [5000,5040])||(enemynear(var(58)),gethitvar(fall)=1&&enemynear(var(58)),canrecover=0&&enemynear(var(58)),stateno = [5000,5081])
trigger4 = (P2Dist Y + (enemynear(var(58)),Vel y*10)+(enemynear(var(58)),GetHitVar(Yaccel) *((10*(10-1)))/2) = [-10,20])||P2Dist Y + (enemynear(var(58)),Vel y*8)+(enemynear(var(58)),GetHitVar(Yaccel) *((8*(8-1)))/2) = [-20,20]
Trigger4 = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
trigger4 =  frontEdgeBodyDist >= 95+((fvar(10)-1)/0.02*1.35) 
trigger4 =  frontEdgeBodyDist <= 170+((fvar(10)-1)/0.02*1.35)
trigger4 = enemynear(var(58)),gethitvar(fall)=0||enemynear(var(58)),gethitvar(fall)=1 &&Random <= 180

[state -1, S立ち中]
type = changestate
value = 10210
triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = numhelper(10010)
triggerall = !Inguarddist&&!(helper(10010),Inguarddist)
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
triggerall = (enemynear(var(58)),gethitvar(fall)=0&&enemynear(var(58)),stateno = [5000,5040])||(enemynear(var(58)),gethitvar(fall)=1&&enemynear(var(58)),stateno = [5000,5081])
triggerall = p2bodydist x > 30
triggerall = (P2Dist Y + (enemynear(var(58)),Vel y*8)+(enemynear(var(58)),GetHitVar(Yaccel) *((8*(8-1)))/2) = [-40,20])||P2Dist Y + (enemynear(var(58)),Vel y*6)+(enemynear(var(58)),GetHitVar(Yaccel) *((6*(6-1)))/2) = [-40,20]
Triggerall = P2dist X > 0
triggerall = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = enemynear(var(58)),gethitvar(fall)=0||enemynear(var(58)),gethitvar(fall)=1 &&Random <= 180
trigger1 = (EnemyNear(var(58)),facing!=facing&&P2bodydist X>=65+EnemyNear(var(58)),Vel X*5+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing=facing&&P2bodydist X>=41+EnemyNear(var(58)),Vel X*-5+((fvar(10)-1)/0.02*1.35))
trigger1 = (EnemyNear(var(58)),facing!=facing&&P2bodydist X<=123+EnemyNear(var(58)),Vel X*5+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing=facing&&P2bodydist X>=123+EnemyNear(var(58)),Vel X*-5+((fvar(10)-1)/0.02*1.35))
trigger2 = var(57) = 2 
Trigger2 = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
trigger2 =  helper(21000),RootDist X >= 125+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X >=125+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger2 =  helper(21000),RootDist X <= 160+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=160+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger3 = var(57) != 2 
Trigger3 = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
trigger3 =  frontEdgeBodyDist >= 105+((fvar(10)-1)/0.02*1.35) 
trigger3 =  frontEdgeBodyDist <= 140+((fvar(10)-1)/0.02*1.35)

[state -1, S立ち弱]
type = changestate
value = 10200
triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = numhelper(10010)
triggerall = !Inguarddist&&!(helper(10010),Inguarddist)
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
triggerall = (enemynear(var(58)),gethitvar(fall)=0&&enemynear(var(58)),stateno = [5000,5040])||(enemynear(var(58)),gethitvar(fall)=1&&enemynear(var(58)),stateno = [5000,5081])
triggerall = p2bodydist x > 40
triggerall = (P2Dist Y + (enemynear(var(58)),Vel y*5)+(enemynear(var(58)),GetHitVar(Yaccel) *((5*(5-1)))/2) = [-10,20])
Triggerall = P2dist X > 0
triggerall = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = enemynear(var(58)),gethitvar(fall)=0||enemynear(var(58)),gethitvar(fall)=1 &&Random <= 180
trigger1 = (EnemyNear(var(58)),facing!=facing&&P2bodydist X>=41+EnemyNear(var(58)),Vel X*4+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing=facing&&P2bodydist X>=41+EnemyNear(var(58)),Vel X*-4+((fvar(10)-1)/0.02*1.35))
trigger1 = (EnemyNear(var(58)),facing!=facing&&P2bodydist X<=97+EnemyNear(var(58)),Vel X*4+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing=facing&&P2bodydist X>=97+EnemyNear(var(58)),Vel X*-4+((fvar(10)-1)/0.02*1.35))
trigger2 = var(57) = 2 
Trigger2 = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
trigger2 =  helper(21000),RootDist X >= 75+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X >=75+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger2 =  helper(21000),RootDist X <= 140+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=140+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger3 = var(57) != 2 
Trigger3 = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
trigger3 =  frontEdgeBodyDist <= 120+((fvar(10)-1)/0.02*1.35)
trigger3 =  frontEdgeBodyDist >= 55+((fvar(10)-1)/0.02*1.35) 

[state -1, Sしゃがみ中]
type = changestate
value = 10410
triggerall = var(59) = [3,4]
Triggerall = var(57) = [2,3]
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = numhelper(10010)
triggerall = !Inguarddist&&!(helper(10010),Inguarddist)
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
triggerall = (enemynear(var(58)),gethitvar(fall)=0&&enemynear(var(58)),stateno = [5000,5040])||(enemynear(var(58)),gethitvar(fall)=1&&enemynear(var(58)),stateno = [5000,5081])
triggerall = p2bodydist x > 40
triggerall = (P2Dist Y + (enemynear(var(58)),Vel y*7)+(enemynear(var(58)),GetHitVar(Yaccel) *((7*(7-1)))/2) = [-60,20])||P2Dist Y + (enemynear(var(58)),Vel y*8)+(enemynear(var(58)),GetHitVar(Yaccel) *((8*(8-1)))/2) = [-60,20]
Triggerall = P2dist X > 0
triggerall = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = enemynear(var(58)),gethitvar(fall)=0||enemynear(var(58)),gethitvar(fall)=1 &&Random <= 180
trigger1 = (EnemyNear(var(58)),facing!=facing&&P2bodydist X>=20+EnemyNear(var(58)),Vel X*6+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing=facing&&P2bodydist X>=10+EnemyNear(var(58)),Vel X*-6+((fvar(10)-1)/0.02*1.35))
trigger1 = (EnemyNear(var(58)),facing!=facing&&P2bodydist X<=53+EnemyNear(var(58)),Vel X*6+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing=facing&&P2bodydist X>=43+EnemyNear(var(58)),Vel X*-6+((fvar(10)-1)/0.02*1.35))
trigger2 = var(57) = 2 
Trigger2 = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
trigger2 =  helper(21000),RootDist X <= 90+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=90+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger3 = var(57) = 3
trigger3 =  frontEdgeBodyDist <= 70+((fvar(10)-1)/0.02*1.35)

[State -1, 蜂の巣だッ！]
type = ChangeState
value = 1000
triggerall = var(59) = [2,4]
Triggerall = var(57) != 3
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
triggerall =  (P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),GetHitVar(Yaccel) *((15*(15-1)))/2) <=-5)
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = EnemyNear(var(58)),Movetype = H
Triggerall = (EnemyNear(var(58)),stateno = [5000,5071])||enemynear(var(58)),stateno=[4000,4030]
triggerall = Movehit
Triggerall = P2dist X > 0
trigger1 = var(57) = 2
trigger1 = stateno=210||(stateno=[250,275])||stateno = 400||stateno = 410||stateno = 450
trigger1 = var(57) = 2 && (((floor(helper(21000),RootDist X) <= 120) && facing = 1)||((floor(helper(25000),RootDist X) <=120) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist <= 100
trigger1 = var(2) := 0||1
trigger2 = var(57) = 2
trigger2 = stateno = 210||stateno = 400||stateno = 410||stateno = [250,275]
trigger2 = P2bodydist X <= 20
trigger2 = var(2) := 0||1
trigger3 = var(57) = 2
trigger3 = stateno = 210||stateno = 400||stateno = 410||stateno = [250,275]
trigger3 = P2bodydist X > 20
trigger3 = var(2) := 1
trigger4 = stateno = 220
trigger4 = var(57) = 2 && (((floor(helper(21000),RootDist X) = [126,160]) && facing = 1)||((floor(helper(25000),RootDist X) =[126,160]) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist = [106,140]
trigger4 = var(2) :=1
trigger5 = stateno = 220
trigger5 = var(57) = 2 && (((floor(helper(21000),RootDist X) = [160,230]) && facing = 1)||((floor(helper(25000),RootDist X) =[160,230]) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist = [140,210]
trigger5 = var(2) :=2
trigger6 = stateno = 220
trigger6 = var(57) = 2 && (((floor(helper(21000),RootDist X) >= 126) && facing = 1)||((floor(helper(25000),RootDist X) >=126) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist >= 106
trigger6 = var(2) :=2
trigger7 = var(57) != 2
trigger7 = stateno=200||stateno = 210||stateno = 400||stateno = 410||(stateno = [250,275])||stateno = 450
trigger7 = frontEdgeBodyDist >= 106
trigger7= var(2) := 0||1

[State -1, 空中通常強攻撃]
type = ChangeState
value = 620
triggerall = var(59) = [2,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype = A
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = EnemyNear(var(58)),Alive
triggerall = (Pos Y + (Vel y*4)+(Const(Movement.Yaccel) *((4*(4-1)))/2) = [-5,-1])
Triggerall = P2dist X > 0
triggerall = P2bodydist X <= 60+vel X*4
triggerall = Ctrl
Trigger1 = enemynear(var(58)),stateno = [4000,4001]
Trigger2 = enemynear(var(58)),Anim = 5300
Trigger3 = enemynear(var(58)),Anim != 5300
Trigger3 = enemynear(var(58)),stateno = [5121,5400]
Trigger3 = enemynear(var(58)),Time >= 50
Trigger3 = enemynear(var(58)),Vel X = 0

[State -1, 空中S中攻撃]
type = ChangeState
value = 10610
triggerall = var(59) = [2,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = Power >= 1000
triggerall = !Inguarddist
triggerall = (Pos Y + (Vel y*11)+(Const(Movement.Yaccel) *((11*(11-1)))/2) = [-5,-1])
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = P2dist X > 0
triggerall = P2bodydist X<=35+vel X*10
triggerall = var(57) = 2 && (((floor(helper(21000),RootDist X) > 120) && facing = 1)||((floor(helper(25000),RootDist X) >120) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist > 100
triggerall = Ctrl
Trigger1 = enemynear(var(58)),stateno = [4000,4001]
Trigger2 = enemynear(var(58)),Anim = 5300
Trigger3 = enemynear(var(58)),Anim != 5300
Trigger3 = enemynear(var(58)),stateno = [5121,5400]
Trigger3 = enemynear(var(58)),Time >= 50
Trigger3 = enemynear(var(58)),Vel X = 0

[State -1, 空中S強攻撃]
type = ChangeState
value = 10620
triggerall = var(59) = [2,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = !Inguarddist
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = P2dist X > 0
triggerall = Pos Y + (Vel y*11)+(Const(Movement.Yaccel) *((11*(11-1)))/2) = [-5,-1]
triggerall = P2bodydist X<=48+vel X*9
triggerall = Ctrl
Trigger1 = enemynear(var(58)),stateno = [4000,4001]
Trigger2 = enemynear(var(58)),Anim = 5300
Trigger3 = enemynear(var(58)),Anim != 5300
Trigger3 = enemynear(var(58)),stateno = [5121,5400]
Trigger3 = enemynear(var(58)),Time >= 50
Trigger3 = enemynear(var(58)),Vel X = 0

[State -1, 立ちS強攻撃]
type = ChangeState
value = 10220
triggerall = var(59) = [2,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !Inguarddist
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = P2dist X > 0
triggerall = P2bodydist X >= 41+((fvar(10)-1)/0.02*1.35)
triggerall = P2bodydist X <= 145+((fvar(10)-1)/0.02*1.35)
triggerall = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = enemynear(var(58)),Anim != 5300
Trigger1 = enemynear(var(58)),stateno = [5121,5400]
Trigger1 = enemynear(var(58)),Time >= 50
Trigger1 = enemynear(var(58)),Vel X = 0
trigger1 =random <= 150

[State -1,  ガキンチョ]
type = ChangeState
value = 11100
triggerall = var(59) = [2,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !Inguarddist
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = P2dist X > 0
triggerall = P2bodydist X = [25,60]
triggerall = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = enemynear(var(58)),Anim != 5300
Trigger1 = enemynear(var(58)),stateno = [5121,5400]
Trigger1 = enemynear(var(58)),Time >= 50
Trigger1 = enemynear(var(58)),Vel X = 0
trigger1 =random <= 150

[State -1,  ガキンチョ]
type = ChangeState
value = 1100
triggerall = var(59) = [2,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !Inguarddist
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = P2dist X > 0
triggerall = P2bodydist X <= 124
triggerall = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = enemynear(var(58)),Anim != 5300
Trigger1 = enemynear(var(58)),stateno = [5121,5400]
Trigger1 = enemynear(var(58)),Time >= 50
Trigger1 = enemynear(var(58)),Vel X = 0
trigger1 =random <= 150

;===========================================================================
; 目押し ガキ
;===========================================================================

[State -1, 小ジャンプ・↑]
type = ChangeState
value = 44
triggerall = var(59) = [3,4]
Triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = life < lifemax /2||numpartner>0||var(59)=4
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = P2dist X > 0
triggerall = P2bodydist X <= 15||EnemyNear(var(58)),facing = facing|| var(57) = 2 && (((floor(helper(21000),RootDist X) <= 120) && facing = 1)||((floor(helper(25000),RootDist X) <=120) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist <= 100
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = numhelper(1160)
Trigger1 = EnemyNear(var(58)),stateno =200004&&EnemyNear(var(58)),Time=ifelse((teamside=1),37,38)
trigger1 = P2bodydist X <= 100
trigger1 = var(6) := 16
trigger2 = numhelper(1161)
Trigger2 = EnemyNear(var(58)),stateno =200004&&EnemyNear(var(58)),Time=ifelse((teamside=1),37,38)
trigger2 = P2bodydist X <= 100
trigger2 = var(6) := 16
trigger3 = numhelper(1160)
Trigger3 = EnemyNear(var(58)),stateno =205030
trigger3 = P2bodydist X <= 100
trigger3 = teamside=1&&P2Dist Y + (enemynear(var(58)),Vel y*9) >= -5||teamside=2&&P2Dist Y + (enemynear(var(58)),Vel y*8) >= -5
trigger3 = var(6) := 16
trigger4 = numhelper(1161)
Trigger4 = EnemyNear(var(58)),stateno =205030
trigger4 = P2bodydist X <= 100
trigger4 = teamside=1&&P2Dist Y + (enemynear(var(58)),Vel y*9) >= -5||teamside=2&&P2Dist Y + (enemynear(var(58)),Vel y*8) >= -5
trigger4 = var(6) := 16

[State -1, 小ジャンプ・前]
type = ChangeState
value = 42
triggerall = var(59) = [3,4]
Triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = life < lifemax /2||numpartner>0||var(59)=4
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),facing != facing
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = numhelper(1160)
Trigger1 = EnemyNear(var(58)),stateno =200004&&EnemyNear(var(58)),Time=ifelse((teamside=1),37,38)
trigger1 = P2bodydist X <= 100
trigger1 = var(6) := 16
trigger2 = numhelper(1161)
Trigger2 = EnemyNear(var(58)),stateno =200004&&EnemyNear(var(58)),Time=ifelse((teamside=1),37,38)
trigger2 = P2bodydist X <= 100
trigger2 = var(6) := 16
trigger3 = numhelper(1160)
Trigger3 = EnemyNear(var(58)),stateno =205030
trigger3 = P2bodydist X <= 100
trigger3 = teamside=1&&P2Dist Y + (enemynear(var(58)),Vel y*9) >= -5||teamside=2&&P2Dist Y + (enemynear(var(58)),Vel y*8) >= -5
trigger3 = var(6) := 16
trigger4 = numhelper(1161)
Trigger4 = EnemyNear(var(58)),stateno =205030
trigger4 = P2bodydist X <= 100
trigger4 = teamside=1&&P2Dist Y + (enemynear(var(58)),Vel y*9) >= -5||teamside=2&&P2Dist Y + (enemynear(var(58)),Vel y*8) >= -5
trigger4 = var(6) := 16

[State -1, 空中通常強攻撃]
type = ChangeState
value = 620
triggerall = var(59) = [3,4]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!Inguarddist
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = roundstate = 2
triggerall = statetype = A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = P2dist X > 0
triggerall = P2bodydist X <= 70+vel X*4
triggerall = Ctrl
trigger1 = (Pos Y + (Vel y*4)+(Const(Movement.Yaccel) *((4*(4-1)))/2) = [-5,-1])
Trigger1 = enemynear(var(58)),stateno = 200000||enemynear(var(58)),stateno = 200050||enemynear(var(58)),stateno = [205000,205001]
Trigger2 = enemynear(var(58)),stateno = 205151 &&enemynear(var(58)),time=ifelse((teamside=1),23,24)
Trigger3 = enemynear(var(58)),stateno = 205101 &&enemynear(var(58)),time=15

[State -1, off挑発]
type = ChangeState
value = 195
triggerall = var(59) = [1,3] 
Triggerall = var(57) = 2
triggerall = Numpartner = 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = var(13)
triggerall = Prevstateno != 195
triggerall = numpartner=0
triggerall = life >= lifemax /2
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),stateno >=200000&&(EnemyNear(var(58)),stateno !=[200060,200063])||P2bodydist X >= 150&&EnemyNear(var(58)),stateno =[200060,200063]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = EnemyNear(var(58)),stateno !=[200001,200004]
trigger1 = enemynear(var(58)),life >= enemynear(var(58)),lifemax / 2
trigger1 = random <= ifelse((EnemyNear(var(58)),stateno !=[200060,200063]),5,1)
Trigger2 = EnemyNear(var(58)),stateno !=[200001,200004]
trigger2 = enemynear(var(58)),life < enemynear(var(58)),lifemax / 2
trigger2 = random <= ifelse((EnemyNear(var(58)),stateno !=[200060,200063]),10,5)
Trigger3 = EnemyNear(var(58)),stateno =200002
trigger4 = Prevstateno = 3010||Prevstateno = 3942

[State -1, ガキ立ち強攻撃]
type = ChangeState
value = 270
triggerall = var(59) = [3,4]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = life < lifemax /2|| numpartner>0||var(59)=4
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),stateno = [205000,205001]
triggerall = (p2bodydist x = [31,80])||(p2bodydist x != [-5,31])&&(p2bodydist x <= 80)
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),6,5)

[State -1, ダッシュ]
type = ChangeState
value = 100
triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = var(13)
triggerall = !var(0)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = life < lifemax /2|| numpartner>0||var(59)=4
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),stateno = [205000,205001]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),7,6)
trigger1 = p2bodydist x != [31,80]

[State -1, 蜂の巣だッ！]
type = ChangeState
value = 1000
triggerall = var(59) = [3,4]
Triggerall = (var(57) = [1,2])||var(57) = 0&&!inGuarddist
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = var(13)
triggerall = numhelper(1160)
triggerall = life < lifemax /2||numpartner>0||var(59)=4
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),Statetype != A
Triggerall = EnemyNear(var(58)),stateno >=200000
triggerall = P2bodydist Y >= -40
triggerall = P2dist X > 0
trigger1 = (stateno = [270,271]) && Movehit
trigger1 = helper(1160),var(0) >= 135
trigger1 = P2bodydist X <= 20
trigger1 = var(2) := 0||1
trigger2 = (stateno = [270,271]) && Movehit
trigger2 = helper(1160),var(0) >= 135
trigger2 = P2bodydist X = [21,60]
trigger2 = var(2) := 1
trigger3 = (stateno = [270,271]) && Movehit
trigger3 = helper(1160),var(0) >= 135
trigger3 = P2bodydist X >= 60
trigger3 = var(2) := 2
trigger4 = helper(1160),var(0) >= 144
Trigger4 =EnemyNear(var(58)),stateno !=[200060,200063]
trigger4 = enemynear(var(58)),Statetype != L
trigger4 = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger4 = P2bodydist X = [50,65]
trigger4 = var(2) := 0||1
trigger5 = helper(1160),var(0) >= 144
trigger5 = enemynear(var(58)),Statetype != L
trigger5 = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger5 = P2bodydist X = [65,125]
trigger5 = var(2) := 1
trigger6 = helper(1160),var(0) >= 144
trigger6 = enemynear(var(58)),Statetype != L
trigger6 = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger6 = P2bodydist X = [125,165]
trigger6 = var(2) := 1

[State -1, 蜂の巣だッ！]
type = ChangeState
value = 1000
triggerall = var(59) = [3,4]
Triggerall = (var(57) = [1,2])||var(57) = 0&&!inGuarddist
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = var(13)
triggerall = numhelper(1161)
triggerall = life < lifemax /2||numpartner>0||var(59)=4
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),Statetype != A
Triggerall = EnemyNear(var(58)),stateno >=200000
triggerall = P2bodydist Y >= -40
triggerall = P2dist X > 0
trigger1 = (stateno = [270,271]) && Movehit
trigger1 = helper(1161),var(0) >= 135
trigger1 = P2bodydist X <= 20
trigger1 = var(2) := 0||1
trigger2 = (stateno = [270,271]) && Movehit
trigger2 = helper(1161),var(0) >= 135
trigger2 = P2bodydist X = [21,60]
trigger2 = var(2) := 1
trigger3 = (stateno = [270,271]) && Movehit
trigger3 = helper(1161),var(0) >= 135
trigger3 = P2bodydist X >= 60
trigger3 = var(2) := 2
trigger4 = helper(1161),var(0) >= 144
trigger4 = enemynear(var(58)),Statetype != L
Trigger4 =EnemyNear(var(58)),stateno !=[200060,200063]
trigger4 = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger4 = P2bodydist X = [50,65]
trigger4 = var(2) := 0||1
trigger5 = helper(1161),var(0) >= 144
trigger5 = enemynear(var(58)),Statetype != L
trigger5 = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger5 = P2bodydist X = [65,125]
trigger5 = var(2) := 1
trigger6 = helper(1161),var(0) >= 144
trigger6 = enemynear(var(58)),Statetype != L
trigger6 = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger6 = P2bodydist X = [125,165]
trigger6 = var(2) := 1


[State -1, ガキ近立ち強攻撃]
type = ChangeState
value = 275
triggerall = var(59) = 3
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = numpartner=0
triggerall = life >= lifemax /2
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000||EnemyNear(var(58)),stateno =205151&&EnemyNear(var(58)),time>=22||EnemyNear(var(58)),stateno =205101&&EnemyNear(var(58)),time>=14
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])&&EnemyNear(var(58)),stateno !=205030
triggerall = P2bodydist Y >= -40
triggerall = P2dist X > 0
triggerall = random<=150
triggerall = (p2bodydist x = [-5,30])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = numhelper(1160)
trigger1 = helper(1160),var(0) <= 146||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),4,3)
trigger2 = numhelper(1161)
trigger2 = helper(1161),var(0) <= 146||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),4,3)


[State -1, ガキ立ち中攻撃]
type = ChangeState
value = 260
triggerall = var(59) = 3
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = numpartner=0
triggerall = life >= lifemax /2
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000||EnemyNear(var(58)),stateno =205151&&EnemyNear(var(58)),time>=22||EnemyNear(var(58)),stateno =205101&&EnemyNear(var(58)),time>=14
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])&&EnemyNear(var(58)),stateno !=205030
triggerall = P2bodydist Y >= -40
triggerall = P2dist X > 0
triggerall = random<=100
triggerall = (p2bodydist x = [-5,30])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = numhelper(1160)
trigger1 = helper(1160),var(0) <= 144||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),5,4)
trigger2 = numhelper(1161)
trigger2 = helper(1161),var(0) <= 144||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),5,4)

[State -1, ガキ立ち強攻撃]
type = ChangeState
value = 270
triggerall = var(59) = [3,4]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000||EnemyNear(var(58)),stateno =205151&&EnemyNear(var(58)),time>=21||EnemyNear(var(58)),stateno =205101&&EnemyNear(var(58)),time>=13
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])&&EnemyNear(var(58)),stateno !=205030
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*6)+(enemynear(var(58)),GetHitVar(Yaccel) *((6*(6-1)))/2) >= -20
triggerall = P2dist X > 0
triggerall = life < lifemax /2||life >= lifemax /2&&random<=100|| numpartner>0||var(59)=4
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = !var(0)
trigger1 = numhelper(1160)
trigger1 = helper(1160),var(0) <= 143||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),6,5)
trigger1 = (p2bodydist x = [31,80])||(p2bodydist x != [-5,31])&&(p2bodydist x <= 80)
trigger2 = var(0)
trigger2 = numhelper(1160)
trigger2 = helper(1160),var(0) <= 143||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),6,5)
trigger2 = (p2bodydist x = [-5,40])
trigger3 = !var(0)
trigger3 = numhelper(1161)
trigger3 =helper(1161),var(0) <= 143||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),6,5)
trigger3 = (p2bodydist x = [31,80])||(p2bodydist x != [-5,31])&&(p2bodydist x <= 80)
trigger4 = var(0)
trigger4 = numhelper(1161)
trigger4 = helper(1161),var(0) <= 143||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),6,5)
trigger4 = (p2bodydist x = [-5,40])

[State -1, ダッシュガキ立ち強攻撃]
type = ChangeState
value = 271
triggerall = var(59) = [3,4]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000||EnemyNear(var(58)),stateno =205151&&EnemyNear(var(58)),time>=21||EnemyNear(var(58)),stateno =205101&&EnemyNear(var(58)),time>=13
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])&&EnemyNear(var(58)),stateno !=205030
triggerall = P2dist X > 0
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*6)+(enemynear(var(58)),GetHitVar(Yaccel) *((6*(6-1)))/2) >= -20
triggerall = life < lifemax /2||life >= lifemax /2&&random<=100|| numpartner>0||var(59)=4
triggerall = stateno = 100 && time > 1
triggerall = P2bodydist X + (Vel x*-6)+(Const(Movement.stand.friction) *((6*(6-1)))/2) <= 80
trigger1 = numhelper(1160)
trigger1 = helper(1160),var(0) <= 143||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),5,4)
trigger2 = numhelper(1161)
trigger2 = helper(1161),var(0) <= 143||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),5,4)

[State -1, ダッシュSガキ立ち強攻撃]
type = ChangeState
value = 10221
triggerall = var(59) = [3,4]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000||EnemyNear(var(58)),stateno =205151&&EnemyNear(var(58)),time>=21||EnemyNear(var(58)),stateno =205101&&EnemyNear(var(58)),time>=13
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])&&EnemyNear(var(58)),stateno !=205030
triggerall = P2dist X > 0
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*7)+(enemynear(var(58)),GetHitVar(Yaccel) *((7*(7-1)))/2) >= -20
triggerall = life < lifemax /2||life >= lifemax /2&&random<=100|| numpartner>0||var(59)=4
triggerall = stateno = 100 && time > 1
triggerall = P2bodydist X + (Vel x*-7)+(Const(Movement.stand.friction) *((7*(7-1)))/2) <= 41
triggerall = P2bodydist X + (Vel x*-7)+(Const(Movement.stand.friction) *((7*(7-1)))/2) <= 145
trigger1 = numhelper(1160)
trigger1 = helper(1160),var(0) <= 142||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),7,6)
trigger2 = numhelper(1161)
trigger2 = helper(1161),var(0) <= 142||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),7,6)

[State -1, ガキ近立ち中攻撃]
type = ChangeState
value = 265
triggerall = var(59) = [3,4]
Triggerall = (var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000||EnemyNear(var(58)),stateno =205151&&EnemyNear(var(58)),time>=24||EnemyNear(var(58)),stateno =205101&&EnemyNear(var(58)),time>=16
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])&&EnemyNear(var(58)),stateno !=205030
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*3)+(enemynear(var(58)),GetHitVar(Yaccel) *((3*(3-1)))/2) >= -20
triggerall = P2dist X > 0
triggerall = life < lifemax /2||life >= lifemax /2&&random<=100|| numpartner>0||var(59)=4
triggerall = !var(0)
triggerall = (p2bodydist x = [-5,30])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = numhelper(1160)
trigger1 = helper(1160),var(0) <= 146||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),3,2)
trigger2 = numhelper(1161)
trigger2 = helper(1161),var(0) <= 146||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),3,2)

[State -1, ガキしゃがみ攻撃]
type = ChangeState
value = 450
triggerall = var(59) =[3,4]
Triggerall = var(57) = 1||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000||EnemyNear(var(58)),stateno =205151&&EnemyNear(var(58)),time>=22||EnemyNear(var(58)),stateno =205101&&EnemyNear(var(58)),time>=14
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])&&EnemyNear(var(58)),stateno !=205030
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*4)+(enemynear(var(58)),GetHitVar(Yaccel) *((4*(4-1)))/2) >= -20
triggerall = P2dist X > 0
triggerall = (p2bodydist x = [-5,30])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = numhelper(1160)
trigger1 = helper(1160),var(0) <= 146||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),3,2)
trigger2 = numhelper(1161)
trigger2 = helper(1161),var(0) <= 146||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),3,2)

[State -1, S立ち強]
type = ChangeState
value = 10220
triggerall = var(59) = [3,4]
Triggerall = var(57) = 1||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000||EnemyNear(var(58)),stateno =205151&&EnemyNear(var(58)),time>=18||EnemyNear(var(58)),stateno =205101&&EnemyNear(var(58)),time>=10
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])&&EnemyNear(var(58)),stateno !=205030
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*7)+(enemynear(var(58)),GetHitVar(Yaccel) *((7*(7-1)))/2) >= -20
triggerall = P2dist X > 0
triggerall = P2bodydist X>=41+((fvar(10)-1)/0.02*1.35) 
triggerall = P2bodydist X<=145+((fvar(10)-1)/0.02*1.35) 
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = numhelper(1160)
trigger1 = helper(1160),var(0) <= 142||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),7,6)
trigger2 = numhelper(1161)
trigger2 = helper(1161),var(0) <= 142||enemynear(var(58)),Statetype = A||EnemyNear(var(58)),stateno =205101||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),7,6)

[State -1, 前進]
type = ChangeState
value = 21
triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = life < lifemax /2|| numpartner>0||var(59)=4
Triggerall = EnemyNear(var(58)),Alive
triggerall = (EnemyNear(var(58)),stateno =[200001,200004])
triggerall = P2dist X > 0
triggerall = ctrl||stateno=22||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X >= 80

[State -1, ダッシュ]
type = ChangeState
value = 100
triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = life < lifemax /2|| numpartner>0||var(59)=4
Triggerall = EnemyNear(var(58)),Alive
Triggerall = (EnemyNear(var(58)),stateno !=[200060,200063])
triggerall = (EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = !var(0)
trigger1 = numhelper(1160)
trigger1 = helper(1160),var(0) <= 141
trigger1 = p2bodydist x != [31,80]
Trigger1 = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000&&EnemyNear(var(58)),stateno !=205151||EnemyNear(var(58)),stateno =205151&&EnemyNear(var(58)),time>=19
trigger2 = var(0)
trigger2 = numhelper(1160)
trigger2 = helper(1160),var(0) <= 140||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),9,8)
trigger2 = p2bodydist x >= 40
Trigger2 = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000&&EnemyNear(var(58)),stateno !=205151||EnemyNear(var(58)),stateno =205151&&EnemyNear(var(58)),time>=19
trigger3 = !var(0)
trigger3 = numhelper(1161)
trigger3 = helper(1161),var(0) <= 141
trigger3 = p2bodydist x != [31,80]
Trigger3 = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000&&EnemyNear(var(58)),stateno !=205151||EnemyNear(var(58)),stateno =205151&&EnemyNear(var(58)),time>=19
trigger4 = var(0)
trigger4 =numhelper(1161)
trigger4 = helper(1161),var(0) <= 140||Enemynear(var(58)),GetHitVar(hittime)>=ifelse((teamside = 1),9,8)
trigger4 = p2bodydist x >= 40
Trigger4 = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000&&(EnemyNear(var(58)),stateno !=205151)||EnemyNear(var(58)),stateno =205151&&EnemyNear(var(58)),time>=19
trigger5 = var(59) = [1,2]
Trigger5 = EnemyNear(var(58)),stateno >=200000
trigger5 = random <= 100
trigger6 = !var(0)
trigger6 = numhelper(1160)
trigger6 = p2bodydist x != [31,80]
trigger6 = EnemyNear(var(58)),stateno =205101&&EnemyNear(var(58)),time>=11
trigger7 = var(0)
trigger7 = numhelper(1160)
trigger7 = EnemyNear(var(58)),stateno =205101&&EnemyNear(var(58)),time>=11
trigger7 = p2bodydist x >= 40
trigger8 = !var(0)
trigger8 = numhelper(1161)
trigger8 = p2bodydist x != [31,80]
trigger8 = EnemyNear(var(58)),stateno =205101&&EnemyNear(var(58)),time>=11
trigger9 = var(0)
trigger9 =numhelper(1161)
trigger9 = EnemyNear(var(58)),stateno =205101&&EnemyNear(var(58)),time>=11
trigger9 = p2bodydist x >= 40
trigger10 = !var(0)
trigger10 = numhelper(1160)
Trigger10 = EnemyNear(var(58)),Statetype = A
Trigger10 = EnemyNear(var(58)),Movetype != H
trigger10 = p2bodydist x <= 30
trigger10 = P2bodydist Y >= -40
trigger11 = !var(0)
trigger11 = numhelper(1161)
Trigger11 = EnemyNear(var(58)),Statetype = A
Trigger11 = EnemyNear(var(58)),Movetype != H
trigger11 = p2bodydist x <= 30
trigger11 = P2bodydist Y >= -40
trigger12 = var(0)
trigger12 = numhelper(1160)
Trigger12 = EnemyNear(var(58)),Statetype = A
Trigger12 = EnemyNear(var(58)),Movetype != H
trigger12 = p2bodydist x > 40
trigger13 = var(0)
trigger13 = numhelper(1161)
Trigger13 = EnemyNear(var(58)),Statetype = A
Trigger13 = EnemyNear(var(58)),Movetype != H
trigger13 = p2bodydist x > 40

[State -1, Soffダッシュ攻撃]
type = ChangeState
value = 271
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
trigger1 = stateno = 100 && time > 1
trigger1 = P2bodydist X + (Vel x*-7)+(Const(Movement.stand.friction) *((7*(7-1)))/2) <= 41
trigger1 = P2bodydist X + (Vel x*-7)+(Const(Movement.stand.friction) *((7*(7-1)))/2) <= 145
trigger1 = random <= 200

[State -1, Soff弱]
type = ChangeState
value = 250
triggerall = var(59) = [1,2]
Triggerall =(var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = var(13)
triggerall = (!var(0)&&p2bodydist X <= 32 || (p2bodydist x = [-5,30]))
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = random <= 200

[State -1, Soff近中]
type = ChangeState
value = 265
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = (p2bodydist x = [-5,40])
trigger1 = random <= 200

[State -1, Soff中]
type = ChangeState
value = 260
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = (!var(0)&&(p2bodydist x =[41,45]) || (p2bodydist x = [-5,30]))
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = random <= 200

[State -1, Soff近強]
type = ChangeState
value = 275
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = (p2bodydist x = [-5,30])
trigger1 = random <= 200

[State -1, Soff屈攻撃]
type = ChangeState
value = 450
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = (!var(0)&&p2bodydist x <=43 || (p2bodydist x = [-5,40]))
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
trigger1 = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = random <= 200

[State -1, ダッシュSガキ立ち強攻撃]
type = ChangeState
value = 10221
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
trigger1 = stateno = 100 && time > 1
trigger1 = P2bodydist X + (Vel x*-7)+(Const(Movement.stand.friction) *((7*(7-1)))/2) >= 41
trigger1 = P2bodydist X + (Vel x*-7)+(Const(Movement.stand.friction) *((7*(7-1)))/2) <= 145
trigger1 = random <= 200


[State -1, ダッシュSガキ立ち中攻撃]
type = ChangeState
value = 10211
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
trigger1 = stateno = 100 && time > 1
trigger1 = P2bodydist X + (Vel x*-5)+(Const(Movement.stand.friction) *((5*(5-1)))/2) >= 25
trigger1 = P2bodydist X + (Vel x*-5)+(Const(Movement.stand.friction) *((5*(5-1)))/2) <= 70
trigger1 = random <= 200

[State -1, ダッシュSガキ立ち弱攻撃]
type = ChangeState
value = 10201
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
trigger1 = stateno = 100 && time > 1
trigger1 = P2bodydist X + (Vel x*-4)+(Const(Movement.stand.friction) *((4*(4-1)))/2) >= 31
trigger1 = P2bodydist X + (Vel x*-4)+(Const(Movement.stand.friction) *((4*(4-1)))/2) <= 97
trigger1 = random <= 200

[State -1, Sガキしゃがみ弱攻撃]
type = ChangeState
value = 10400
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
triggerall = P2bodydist X != [-5,40]
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = random <= 200
trigger1 = P2bodydist X >= 5+((fvar(10)-1)/0.02*1.35)
trigger1 = P2bodydist X <= 61+((fvar(10)-1)/0.02*1.35)

[State -1, Sガキしゃがみ中攻撃]
type = ChangeState
value = 10410
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = random <= 200
trigger1 = P2bodydist X >= 41+((fvar(10)-1)/0.02*1.35)
trigger1 = P2bodydist X <= 53+((fvar(10)-1)/0.02*1.35)

[State -1, Soff強]
type = ChangeState
value = 270
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = (!var(0) || (p2bodydist x = [-5,40]))
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
triggerall = random <= 50
trigger1 = (!var(0)&&(p2bodydist x =[31,85]) || (p2bodydist x = [-5,40]))
trigger1 = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger2 = !var(0)
trigger2 = stateno = 100 && time > 1
trigger2 = P2bodydist X + (Vel x*-6)+(Const(Movement.stand.friction) *((6*(6-1)))/2) <= 80

[State -1, Sガキ立ち弱攻撃]
type = ChangeState
value = 10200
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = random <= 200
trigger1 = P2bodydist X >= 31
trigger1 = P2bodydist X <= 97+((fvar(10)-1)/0.02*1.35)

[State -1, Sガキしゃがみ強攻撃]
type = ChangeState
value = 10420
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = random <= 200
trigger1 = P2bodydist X = [41,100]

[State -1, Sガキ立ち中攻撃]
type = ChangeState
value = 10210
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = p2bodydist x != [-5,30]
triggerall = P2bodydist Y >= -40
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = random <= 200
trigger1 = P2bodydist X >= 65+((fvar(10)-1)/0.02*1.35)
trigger1 = P2bodydist X <= 123+((fvar(10)-1)/0.02*1.35)

[State -1, Sガキ立ち強攻撃]
type = ChangeState
value = 10220
triggerall = var(59) = [1,2]
Triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&!inGuarddist
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L&&EnemyNear(var(58)),stateno >=200000
Triggerall =(EnemyNear(var(58)),stateno !=[200060,200063])&&(EnemyNear(var(58)),stateno !=[200001,200004])
triggerall = P2dist X > 0
triggerall = P2bodydist Y >= -40
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = random <= 200
trigger1 = P2bodydist X >= 41+((fvar(10)-1)/0.02*1.35)
trigger1 = P2bodydist X <= 145+((fvar(10)-1)/0.02*1.35)


;===========================================================================
; 目押し
;===========================================================================

[State -1, ジャンプ・前]
type = ChangeState
value = 42
triggerall = var(59) = [2,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !Inguarddist
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),Movetype = H
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = stateno != 100
Trigger1 = enemynear(var(58)),Anim = 5300
trigger1 = P2bodydist X <= 80
trigger1 = var(6) := 16
trigger2 = enemynear(var(58)),var(52) +enemynear(var(58)),var(53)>=35
Trigger2 = enemynear(var(58)),stateno = [4000,4001]
trigger2 = P2bodydist X <= 80
trigger2 = var(6) := 16

[State -1, ダッシュ]
type = ChangeState
value = 100
triggerall = var(59) = [2,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !Inguarddist
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),Movetype = H
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
triggerall = P2dist X > 0
trigger1 = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = enemynear(var(58)),Anim = 5300
trigger1 = P2bodydist X > 80

[State -1, ガキンチョ]
type = ChangeState
value = 11100
triggerall = var(59) = [3,4]
Triggerall = var(57) != [0,1]
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !Inguarddist
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),Movetype = H
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
triggerall = enemynear(var(58)),var(52) +enemynear(var(58)),var(53)=[16,34]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = enemynear(var(58)),stateno = [4000,4001]
trigger1 = P2bodydist X <= 40

[State -1, ダッシュ]
type = ChangeState
value = 100
triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !Inguarddist
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),Movetype = H
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),stateno = [4000,4001]
triggerall = P2bodydist X <= 100
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = enemynear(var(58)),Statetype = S
Trigger1 = enemynear(var(58)),Const(size.head.pos.y) <= -45
trigger1 = enemynear(var(58)),var(52) +enemynear(var(58)),var(53)>=12
Trigger2 = enemynear(var(58)),Statetype = C||!(enemynear(var(58)),Const(size.head.pos.y) <= -45)
trigger2 = enemynear(var(58)),var(52) +enemynear(var(58)),var(53)>=8

[State -1, 通常立ち強攻撃]
type = ChangeState
value = 220
triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !Inguarddist
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = S
Triggerall = enemynear(var(58)),Const(size.head.pos.y) <= -45
Triggerall = EnemyNear(var(58)),Movetype = H
triggerall = P2dist X > 0
trigger1 = !var(0)
trigger1 = stateno = 100  && time > 1
trigger1 = P2bodydist X + (Vel x*-8)+(Const(Movement.stand.friction) *((8*(8-1)))/2) <= 30
Trigger1 = enemynear(var(58)),stateno = [4000,4001]

[State -1, 通常しゃがみ中攻撃]
type = ChangeState
value = 410
triggerall = var(59) =[3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !Inguarddist
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype = C||!(enemynear(var(58)),Const(size.head.pos.y) <= -45)
Triggerall = EnemyNear(var(58)),Movetype = H
triggerall = P2dist X > 0
trigger1 = stateno = 100  && time > 1
trigger1 = P2bodydist X + (Vel x*-4)+(Const(Movement.crouch.friction) *((4*(4-1)))/2) <= 30
Trigger1 = enemynear(var(58)),stateno = [4000,4001]

[State -1, 立ち強攻撃]
type = ChangeState
value = 220
triggerall = var(59) =[3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !Inguarddist
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = S
Triggerall = enemynear(var(58)),Const(size.head.pos.y) <= -45
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
triggerall = P2dist X > 0
triggerall = (!var(0)&&P2bodydist X <= 45|| (p2bodydist x = [-5,40]))
Trigger1 = (enemynear(var(58)),stateno = [5000,5050])||(enemynear(var(58)),stateno = [4000,4001])
trigger1 = stateno = 52 && ctrl
Trigger2 = (enemynear(var(58)),stateno = [4000,4001])
trigger2 = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))

[State -1, しゃがみ中攻撃]
type = ChangeState
value = 410
triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
triggerall = P2dist X > 0
triggerall = (!var(0)&&P2bodydist X <= 37|| (p2bodydist x = [-5,40]))
Trigger1 = (enemynear(var(58)),stateno = [5000,5050])||(enemynear(var(58)),stateno = [4000,4001])
trigger1 = stateno = 52 && ctrl
Trigger2 = (enemynear(var(58)),stateno = [4000,4001])
trigger2 = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))

[State -1, 蜂の巣だッ！]
type = ChangeState
value = 1000
triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),Movetype = H
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),stateno = [4000,4001]
triggerall= enemynear(var(58)),var(52) +enemynear(var(58)),var(53)>=15
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = P2dist X > 0
trigger1 = P2bodydist X =[10,60]
trigger1 = var(2) := 0||1
trigger2 = P2bodydist X =[55,105]
trigger2 = var(2) := 1
trigger3 = P2bodydist X =[105,165]
trigger3 = var(2) := 2

[State -1, S立ち強攻撃]
type = ChangeState
value = 10220
triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = (enemynear(var(58)),stateno = [4000,4001])
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
triggerall = P2dist X > 0
triggerall = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X>=41+((fvar(10)-1)/0.02*1.35) 
trigger1 = P2bodydist X<=145+((fvar(10)-1)/0.02*1.35) 

[State -1, しゃがみ中攻撃]
type = ChangeState
value = 410
triggerall = var(59) = [2,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
triggerall = P2dist X > 0
triggerall = (!var(0)&&P2bodydist X <= 37|| (p2bodydist x = [-5,40]))
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = EnemyNear(var(58)),Movetype = H
Trigger1 = enemynear(var(58)),Anim != 5300
Trigger1 = enemynear(var(58)),stateno = [5121,5400]
Trigger1 = enemynear(var(58)),Time >= 50
Trigger1 = enemynear(var(58)),Vel X = 0
trigger1 = random <= 200
trigger2 = var(57) != 2
Trigger2 = enemynear(var(58)),Anim = 5300


[State -1, 通常立ち強攻撃]
type = ChangeState
value = 220
triggerall = var(59) = [2,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = S
Triggerall = enemynear(var(58)),Const(size.head.pos.y) <= -45
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
triggerall = P2bodydist X  <= 45
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = var(59) = 3
trigger1 = life>=lifemax/2&&random <=enemynear(var(58)),GetHitVar(HitCount)*50||life<lifemax/2&&random <=enemynear(var(58)),GetHitVar(HitCount)*25
trigger2 = var(59) = 2
trigger2 = random <= 130
trigger3 = var(59) = 4
trigger3 = Power >= 1000
trigger3 = random <=enemynear(var(58)),GetHitVar(HitCount)*15

[State -1, 通常立ち弱攻撃]
type = ChangeState
value = 200
triggerall = var(59) = [2,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = S
Triggerall = enemynear(var(58)),Const(size.head.pos.y) <= -45
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
triggerall = P2bodydist X  <= 29
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = var(59) = [3,4]
trigger1 = Enemynear(var(58)),GetHitVar(hittime) <= ifelse((teamside=1),3,2)
trigger2 = var(59) = 2
trigger2 = random <= 150

[State -1,ダッシュ]
type = ChangeState
value = 100
triggerall = var(59) = [2,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = Prevstateno = 200||Enemynear(var(58)),GetHitVar(hittime) >= ifelse((teamside=1),6,5)
trigger1 = (var(59) = [3,4])||random <= 150

[State -1, しゃがみ弱攻撃]
type = ChangeState
value = 400
triggerall = var(59) = [2,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
triggerall = stateno = 100 && time > 1
triggerall = Enemynear(var(58)),GetHitVar(hittime) <= ifelse((teamside=1),3,2)
triggerall = P2bodydist X + (Vel x*-3)+(Const(Movement.crouch.friction) *((3*(3-1)))/2) <= 38
trigger1 = (var(59) = [3,4])||random <= 150

[State -1, 通常しゃがみ中攻撃]
type = ChangeState
value = 410
triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype = C||!(enemynear(var(58)),Const(size.head.pos.y) <= -45)
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
triggerall = Enemynear(var(58)),GetHitVar(hittime) >= ifelse((teamside=1),3,2)
triggerall = P2bodydist X  <= 37
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = (var(59) = [3,4])||random <= 150

[State -1, 立ち強攻撃]
type = ChangeState
value = 220
triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = S
Triggerall = enemynear(var(58)),Const(size.head.pos.y) <= -45
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = Enemynear(var(58)),GetHitVar(hittime) >= ifelse((teamside = 1),2,1)
trigger1 = P2bodydist X = [-5,40]

[State -1, しゃがみ中攻撃]
type = ChangeState
value = 410
triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = Enemynear(var(58)),GetHitVar(hittime) >= ifelse((teamside = 1),3,2)
trigger1 = P2bodydist X = [-5,37]

[State -1, S立ち強攻撃]
type = ChangeState
value = 10220
triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = Enemynear(var(58)),GetHitVar(hittime) >= ifelse((teamside = 1),6,5)
trigger1 = P2bodydist X>=41+((fvar(10)-1)/0.02*1.35) 
trigger1 = P2bodydist X<=145+((fvar(10)-1)/0.02*1.35) 

[State -1, S立ち中攻撃]
type = ChangeState
value = 10210
triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = Enemynear(var(58)),GetHitVar(hittime) >=ifelse((teamside = 1),4,3)
trigger1 = P2bodydist X >= 65+((fvar(10)-1)/0.02*1.35)
trigger1 = P2bodydist X <= 123+((fvar(10)-1)/0.02*1.35)

[State -1, Sしゃがみ強攻撃]
type = ChangeState
value = 10420
triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = Enemynear(var(58)),GetHitVar(hittime) >=ifelse((teamside = 1),4,3)
trigger1 = P2bodydist X <= 100

[State -1, Sしゃがみ中攻撃]
type = ChangeState
value = 410
triggerall = var(59) = 2
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
triggerall = Enemynear(var(58)),GetHitVar(hittime) >= ifelse((teamside=1),3,2)
triggerall = (p2bodydist x = [-5,40])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 =random <= 250

[State -1, Sしゃがみ強攻撃]
type = ChangeState
value = 10420
triggerall = var(59) = 2
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
triggerall = Enemynear(var(58)),GetHitVar(hittime) >= ifelse((teamside=1),3,2)
triggerall = p2bodydist x <= 100
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 =random <= 250

[State -1, 通常しゃがみ強攻撃]
type = ChangeState
value = 420
triggerall = var(59) = 2
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
triggerall = Enemynear(var(58)),GetHitVar(hittime) >= ifelse((teamside=1),3,2)
triggerall = p2bodydist x <= 100
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 =random <= 250

;===========================================================================
; 連携記述　デム中
;===========================================================================

[State -1, 絶望ォォォだねッ！]
type = ChangeState
value = 3940
triggerall = var(49) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = var(31)
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = (enemynear(var(58)),stateno = [5000,5050])||(enemynear(var(58)),stateno = [4000,4001])
triggerall = power >= 1000
triggerall = Movehit
trigger1 = var(59) = [3,4]
Trigger1 = var(57) != 0
trigger1 = fvar(2) <= 8
trigger1 = stateno = 3702&&Movehit=11||stateno = 3701&&Movehit=9
trigger1 = var(59) = 3||var(59)=4&&enemynear(var(58)),life <= enemynear(var(58)),lifemax/2||Power>=2000
trigger1 = var(47) = [0,3]
trigger2 = var(59) = [1,2]
trigger2 = fvar(2) <= 50
trigger2 = P2bodydist X <= 60
trigger2 = (stateno = [3700,3702])||stateno = 3701||stateno = [3900,3901]
trigger2 = random <= var(59)*25

[State -1, ウシウシウシッ！]
type = ChangeState
value = 3950
triggerall = var(49) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = (enemynear(var(58)),stateno = [5000,5050])||(enemynear(var(58)),stateno = [4000,4001])
triggerall = P2dist X > 0
triggerall = power >= 1000
triggerall = var(31)
triggerall = Movecontact
trigger1 = var(59) = [3,4]
Trigger1 = var(57) != 0
trigger1 = fvar(2) <= 8
trigger1 =  var(59) = 3||var(59)=4&&enemynear(var(58)),life <= enemynear(var(58)),lifemax/2||Power>=2000
trigger1 = stateno = 3702&&Movehit=11||stateno = 3701&&Movehit=9
trigger1 = var(47) = [4,7]
trigger2 = var(59) = [1,2]
trigger2 = fvar(2) <= 50
trigger2 = P2bodydist X <= 60
trigger2 = (stateno = [3700,3702])||stateno = 3701||stateno = [3900,3901]
trigger2 = random <= var(59)*25

[State -1, ガキンチョがッ！]
type = ChangeState
value = 3920
triggerall = var(49) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = (enemynear(var(58)),stateno = [5000,5050])||(enemynear(var(58)),stateno = [4000,4001])
triggerall = P2dist X > 0
triggerall = var(31)
triggerall = Movecontact
trigger1 = var(59) = [3,4]
Trigger1 = var(57) != 0
trigger1 = fvar(2) <= 8
trigger1 = stateno = 3702&&Movehit=11||stateno = 3701&&Movehit=9
trigger1 = var(59)<=3||var(47) = [0,9]
trigger2 = var(59) = [1,2]
trigger2 = fvar(2) <= 50
trigger2 = P2bodydist X <= 60
trigger2 = (stateno = [3700,3702])||stateno = 3701||stateno = [3900,3901]
trigger2 = random <= var(59)*25

[State -1, 蜂の巣だッ！]
type = ChangeState
value = 3910
triggerall = var(59) > 0
Triggerall = var(57) != 3
triggerall = var(49) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = var(0)
triggerall = !var(8)
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
triggerall = P2dist X > 0
triggerall = var(31)
triggerall = (stateno = [3700,3702])||stateno = 3701||stateno = [3900,3901]
trigger1 = fvar(2) <= 8
Trigger1 = enemynear(var(58)),Statetype != A
Trigger1 = enemynear(var(58)),stateno = [120,155]
trigger1 = Moveguarded
trigger1 = var(2) := 0||1
Trigger2 = enemynear(var(58)),Statetype = A
Trigger2 = (enemynear(var(58)),stateno = [5000,5050])||(enemynear(var(58)),stateno = [4000,4001])
trigger2 = Movecontact
trigger2 = var(2) := 0||1
trigger3 = var(59) = [1,2]
trigger3 = fvar(2) <= 50
trigger3 = (stateno = [3700,3702])||stateno = 3701||stateno = [3900,3901]
trigger3 = Movecontact
trigger3 = random <= var(59)*25
trigger3 = var(2) := 0||1

;===========================================================================
; 連携記述
;===========================================================================



[state -1, Soffウシウシウシッ！]
type = changestate
value = 3100
triggerall = var(59) = [3,4]
Triggerall = var(57) !=[1,2]
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = statetype != A
triggerall = power >= 1000
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = EnemyNear(var(58)),Movetype = H
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
Triggerall = P2dist X > 0
trigger1 = Prevstateno!=100&&stateno = 220&&Movehit=11||Prevstateno=100&&stateno = 220&&Movehit=12
trigger1 = P2bodydist X <= 3


[state -1, Sonウシウシウシッ！]
type = changestate
value = 3200
triggerall = var(59) = [3,4]
Triggerall = var(57) !=[1,2]
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = statetype != A
triggerall = power >= 1000
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = EnemyNear(var(58)),Movetype = H
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
Triggerall = P2dist X > 0
trigger1 = P2bodydist X <= 3
trigger1 = Prevstateno!=100&&stateno = 220&&Movehit=11||Prevstateno=100&&stateno = 220&&Movehit=12

[State -1, ガキンチョがッ！]
type = ChangeState
value = 1100
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = Power < 1000
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),stateno = 4000
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
trigger1 = P2bodydist X <=45
trigger1 = stateno = 220 && Movehit

[State -1,タンデム]
type = ChangeState
value = 3500
triggerall = var(59) = [3,4]
triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !numhelper(3509)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !var(25)||!var(24)
triggerall = power >= 1000
triggerall = !var(8) || var(0)
triggerall = !var(13)
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
trigger1 = numhelper(10000)
trigger1 = stateno = 11200&&helper(10000),Movehit=1
trigger2 = stateno = 210&&Movehit = 9|| Prevstateno!=100&&stateno = 220&&Movehit=11||Prevstateno=100&&stateno = 220&&Movehit=12
trigger2 = (Power = [1000,1999])&&random<=150||Power >= 2000&&random<=250||life<=lifemax/2||var(59)=4
trigger3 = stateno = 410&&Movehit=7
trigger3 = var(59)=3&&random <= enemynear(var(58)),GetHitVar(HitCount)*ifelse((life>lifemax/2),25,50)||prevstateno=100||P2bodydist X > 25||var(59)=4&&random <= enemynear(var(58)),GetHitVar(HitCount)*15
trigger4 = Prevstateno=100&&stateno=400&&Movehit=2
trigger4 = P2bodydist X >= 35
trigger5 = var(0)
trigger5 = !var(8)
trigger5 = stateno = 200 && Movehit = 8 || stateno = 400 && Movehit = 8||stateno = 410&&Movehit=7
trigger5 = (Power = [1000,1999])&&random<=180||Power >= 2000&&random<=250||life<=lifemax/2||var(59)=4

[State -1, ガキンチョがッ！]
type = ChangeState
value = 11100
triggerall = var(59) = [3,4]
triggerall = var(57) = 2&&random<=200||var(57) != 2||life<lifemax/2&&Power<1000||var(59)=4
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(25)||!var(24)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
trigger1 = stateno = 210&&Movehit = 9||stateno = 410&&Movehit=7
trigger1 = P2bodydist X <= 12
trigger2 = Prevstateno!=100&&stateno = 220&&Movehit=11||Prevstateno=100&&stateno = 220&&Movehit=12
trigger2 = P2bodydist X <= 5

[State -1,蜂の巣だッ！]
type = ChangeState
value = 1000
triggerall = var(59) =[3,4]
triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !var(25)||!var(24)
triggerall = !var(8)
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = (enemynear(var(58)),stateno = [5000,5050])
triggerall = P2dist X > 0
trigger1 = prevstateno!=100
trigger1 = stateno = 210&&Movehit = 9
trigger1 = var(2) := 0||1
trigger2 = !var(0)
trigger2 = var(59) = 3
trigger2 = stateno = 410&&Movehit=7
trigger2 = life>=lifemax/2&&random <=enemynear(var(58)),GetHitVar(HitCount)*ifelse((Power>=1000),25,50)||life<lifemax/2&&random <=enemynear(var(58)),GetHitVar(HitCount)*25||prevstateno=100
trigger2 = P2bodydist X <= 25||prevstateno=100
trigger2 = var(2) := 0||1
trigger3 = !var(0)
trigger3 = P2bodydist X > 25
trigger3 = var(59) = 3
trigger3 = prevstateno!=100
trigger3 = stateno = 410&&Movehit=7
trigger3 = life>=lifemax/2&&random <=enemynear(var(58)),GetHitVar(HitCount)*ifelse((Power>=1000),25,50)||life<lifemax/2&&random <=enemynear(var(58)),GetHitVar(HitCount)*25
trigger3 = var(2) := 1
trigger4 = Prevstateno!=100&&stateno = 220&&Movehit=11||Prevstateno=100&&stateno = 220&&Movehit=12
trigger4 = var(2) := 1
trigger5 = var(0)
trigger5 = P2bodydist X <= 25
trigger5 = stateno = 210&&Movehit = 9||stateno = 410&&Movehit = 7
trigger5 = var(2) := 0||1
trigger6 = var(0)
trigger6 = P2bodydist X > 25
trigger6 = stateno = 210&&Movehit = 9||stateno = 410&&Movehit = 7
trigger6 = var(2) := 1
trigger7 = !var(0)
trigger7 = var(59) = 4
trigger7 = stateno = 410&&Movehit=7
trigger7 = var(57) != 2||prevstateno=100||P2bodydist X > 25
trigger7 = var(2) := 0||1

[State -1,蜂の巣だッ！]
type = ChangeState
value = 1000
triggerall = var(59) =[3,4]
triggerall = var(57) != [1,3]
triggerall = var(49) = 1
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !var(8)
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
triggerall = P2dist X > 0
trigger1 = stateno = 210
trigger1 = (enemynear(var(58)),stateno = [5000,5050])&&Movecontact = 9||(enemynear(var(58)),stateno = [150,155])&&Movehit = 9
trigger1 = var(2) := 0||1
trigger2 = stateno = 410
trigger2 = (enemynear(var(58)),stateno = [5000,5050])&&Movecontact = 7||(enemynear(var(58)),stateno = [150,155])&&Movehit = 7
trigger2 = var(2) := 0||1
trigger3 = Prevstateno!=100&&stateno = 220
trigger3 = (enemynear(var(58)),stateno = [5000,5050])&&Movecontact = 11||(enemynear(var(58)),stateno = [150,155])&&Movehit = 11
trigger3 = var(2) := 0||1
trigger4 = Prevstateno=100&&stateno = 220
trigger4 = (enemynear(var(58)),stateno = [5000,5050])&&Movecontact = 12||(enemynear(var(58)),stateno = [150,155])&&Movehit = 12
trigger4 = var(2) := 0||1

[State -1,蜂の巣だッ！]
type = ChangeState
value = 1000
triggerall = var(59) =[3,4]
triggerall = var(57) != 3
triggerall = var(49) = 1
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !var(8)
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = (enemynear(var(58)),stateno = [150,155])
Triggerall = enemynear(var(58)),life>1
triggerall = P2dist X > 0
triggerall = var(57) = 2 && (((floor(helper(21000),RootDist X) >= 150) && facing = 1)||((floor(helper(25000),RootDist X) >=150) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist >= 130
triggerall = random <= ifelse((var(57)=2),100,160)
trigger1 = stateno = 210&&Moveguarded = 9
trigger1 = var(2) := 0||1
trigger2 = stateno = 410&&Moveguarded=7
trigger2 = var(2) := 0||1
trigger3 = Prevstateno!=100&&stateno = 220&&Moveguarded=11||Prevstateno=100&&stateno = 220&&Moveguarded=12
trigger3 = var(2) := 0||1
trigger4= stateno = 420&&Moveguarded=13
trigger4 = P2bodydist X <= 20
trigger4 = var(2) := 0||1
trigger5 = var(57) = [2,3]
trigger5= stateno = 420&&Moveguarded=13
trigger5 = P2bodydist X = [20,70]
trigger5 = var(2) := 1
trigger6 = var(57) != [2,3]
trigger6= stateno = 420&&Moveguarded=13
trigger6 = P2bodydist X = [20,70]
trigger6 = var(2) := 0||1
trigger7= stateno = 420&&Moveguarded=13
trigger7 = P2bodydist X >= 70
trigger7 = var(2) := 2

[State -1,タンデム]
type = ChangeState
value = 3500
triggerall = var(59) =[1,2]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !numhelper(3509)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = power >= 1000
triggerall = !var(8) || var(0)
triggerall = !var(13)
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
triggerall = P2dist X > 0
trigger1 = numhelper(10000)
trigger1 = stateno = 11200&&helper(10000),Movehit
trigger2 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno = 410
trigger2 = Movehit&&random<=var(59)*100||Moveguarded&&random<=30/var(59)

[State -1, ガキンチョがッ！]
type = ChangeState
value = 11100
triggerall = var(59) =[1,2]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
triggerall = Movehit&&random<=var(59)*50||Moveguarded&&random<=50/var(59)
trigger1 = stateno = 200||stateno = 400
trigger2 = stateno = 210||stateno = 410
trigger2 = P2bodydist X <= 20
trigger3 = stateno = 220
trigger3 = P2bodydist X <= 10

[State -1,蜂の巣だッ！]
type = ChangeState
value = 1000
triggerall = var(59) =[1,2]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !var(8)
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),life>1
triggerall = P2dist X > 0
trigger1 = stateno = 210||stateno = 410
trigger1 = Movehit&&random<=var(59)*100||Moveguarded&&random<=50/var(59)
trigger1 = var(2) := 0||1
trigger2 = stateno = 220
trigger2 = Movehit&&random<=var(59)*100||Moveguarded&&random<=50/var(59)
trigger2 = var(2) := 0||1
trigger3= stateno = 420
trigger3 = P2bodydist X <= 20
trigger3 = Movehit&&random<=var(59)*100||Moveguarded&&random<=50/var(59)
trigger3 = var(2) := 0||1
trigger4= stateno = 420
trigger4 = P2bodydist X = [20,70]
trigger4 = Movehit&&random<=var(59)*100||Moveguarded&&random<=50/var(59)
trigger4 = var(2) := 1
trigger5= stateno = 420
trigger5 = P2bodydist X >= 70
trigger5 = Movehit&&random<=var(59)*100||Moveguarded&&random<=50/var(59)
trigger5 = var(2) := 2
trigger6 = stateno = 200||stateno = 400
trigger6 = Movehit&&random<=var(59)*50||Moveguarded&&random<=50/var(59)
trigger6 = var(2) := 0||1

;===========================================================================
;　切り替えし
;===========================================================================

[State -1, ウシウシウシッ！]
type = ChangeState
value = 3100
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = power >= 1000
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),facing != facing
Triggerall = EnemyNear(var(58)),Vel X>=0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Movetype = A
triggerall = P2dist X > 0
Triggerall = Random <= 180
trigger1 = enemynear(var(58)),HitPauseTime<=0
trigger1 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*20
trigger1 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*20
trigger1 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger1 = stateno = 200&&time>=4||stateno = 210&&time>=5||Prevstateno!=100&&stateno = 220&&time>=4||stateno = 400&&time>=6||stateno =410&&time>=5||stateno =420&&time>=6||Prevstateno=100&&stateno = 220&&time>=9
trigger1 = var(39) := 3
trigger2 = var(57)!=[0,1]
trigger2 = enemynear(var(58)),HitPauseTime<=0
trigger2 = EnemyNear(var(58)),time <= time
trigger2 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*20
trigger2 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*20
trigger2 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger2 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno =410||stateno =420
trigger2 = var(39) := 3
trigger3 = enemynear(var(58)),HitPauseTime>0
trigger3 = P2bodydist X=[5,62]
trigger3 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger3 = stateno = 200&&time>=4||stateno = 210&&time>=5||Prevstateno!=100&&stateno = 220&&time>=4||stateno = 400&&time>=6||stateno =410&&time>=5||stateno =420&&time>=6||Prevstateno=100&&stateno = 220&&time>=9
trigger3 = var(39) := 3
trigger4 = var(57)!=[0,1]
trigger4 = enemynear(var(58)),HitPauseTime>0
trigger4 = EnemyNear(var(58)),time <= time
trigger4 = P2bodydist X=[5,62]
trigger4 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger4 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno =410||stateno =420
trigger4 = var(39) := 3

[State -1, Sonウシウシウシッ！]
type = ChangeState
value = 3200
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = var(39) = 0
triggerall = power >= 1000
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),facing != facing
Triggerall = EnemyNear(var(58)),Vel X>=0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Movetype = A
triggerall = P2dist X > 0
Triggerall = Random <= 180
trigger1 = enemynear(var(58)),HitPauseTime<=0
trigger1 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*20
trigger1 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*20
trigger1 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger1 = stateno = 200&&time>=4||stateno = 210&&time>=5||Prevstateno!=100&&stateno = 220&&time>=4||stateno = 400&&time>=6||stateno =410&&time>=5||Prevstateno=100&&stateno = 220&&time>=9
trigger1 = var(39) := 3
trigger2 = var(57)!=[0,1]
trigger2 = enemynear(var(58)),HitPauseTime<=0
trigger2 = EnemyNear(var(58)),time <= time
trigger2 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*20
trigger2 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*20
trigger2 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger2 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno =410
trigger2 = var(39) := 3
trigger3 = enemynear(var(58)),HitPauseTime>0
trigger3 = P2bodydist X=[5,62]
trigger3 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger3 = stateno = 200&&time>=4||stateno = 210&&time>=5||Prevstateno!=100&&stateno = 220&&time>=4||stateno = 400&&time>=6||stateno =410&&time>=5||Prevstateno=100&&stateno = 220&&time>=9
trigger3 = var(39) := 3
trigger4 = var(57)!=[0,1]
trigger4 = enemynear(var(58)),HitPauseTime>0
trigger4 = EnemyNear(var(58)),time <= time
trigger4 = P2bodydist X=[5,62]
trigger4 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger4 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno =410
trigger4 = var(39) := 3

[State -1, ウシウシウシッ！]
type = ChangeState
value = 3100
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(45) = 0
triggerall = var(39) = 0
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = power >= 1000
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),facing != facing
Triggerall = EnemyNear(var(58)),Vel X>=0
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Movetype = A
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) = [-60,-1]
triggerall = P2dist X > 0
Triggerall = Random <= 180
trigger1 = enemynear(var(58)),HitPauseTime<=0
trigger1 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*20
trigger1 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*20
trigger1 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger1 = stateno = 200&&time>=4||stateno = 210&&time>=5||Prevstateno!=100&&stateno = 220&&time>=4||stateno = 400&&time>=6||stateno =410&&time>=5||stateno =420&&time>=6||Prevstateno=100&&stateno = 220&&time>=9
trigger1 = var(39) := 3
trigger2 = var(57)!=[0,1]
trigger2 = enemynear(var(58)),HitPauseTime<=0
trigger2 = EnemyNear(var(58)),time <= time
trigger2 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*20
trigger2 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*20
trigger2 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger2 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno =410||stateno =420
trigger2 = var(39) := 3
trigger3 = enemynear(var(58)),HitPauseTime>0
trigger3 = P2bodydist X=[5,62]
trigger3 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger3 = stateno = 200&&time>=4||stateno = 210&&time>=5||Prevstateno!=100&&stateno = 220&&time>=4||stateno = 400&&time>=6||stateno =410&&time>=5||stateno =420&&time>=6||Prevstateno=100&&stateno = 220&&time>=9
trigger3 = var(39) := 3
trigger4 = var(57)!=[0,1]
trigger4 = enemynear(var(58)),HitPauseTime>0
trigger4 = EnemyNear(var(58)),time <= time
trigger4 = P2bodydist X=[5,62]
trigger4 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger4 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno =410||stateno =420
trigger4 = var(39) := 3

[State -1, ウシウシウシッ！]
type = ChangeState
value = 3100
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(45) = 0
triggerall = var(39) = 0
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = power >= 1000
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),facing != facing
Triggerall = EnemyNear(var(58)),Vel X>=0
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Movetype = A
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) = [-60,-1]
triggerall = P2dist X > 0
Triggerall = Random <= 180
trigger1 = enemynear(var(58)),HitPauseTime<=0
trigger1 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*20
trigger1 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*20
trigger1 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger1 = stateno = 200&&time>=4||stateno = 210&&time>=5||Prevstateno!=100&&stateno = 220&&time>=4||stateno = 400&&time>=6||stateno =410&&time>=5||Prevstateno=100&&stateno = 220&&time>=9
trigger2 = var(57)!=[0,1]
trigger2 = enemynear(var(58)),HitPauseTime<=0
trigger2 = EnemyNear(var(58)),time <= time
trigger2 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*20
trigger2 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*20
trigger2 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger2 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno =410
trigger3 = enemynear(var(58)),HitPauseTime>0
trigger3 = P2bodydist X=[5,62]
trigger3 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger3 = stateno = 200&&time>=4||stateno = 210&&time>=5||Prevstateno!=100&&stateno = 220&&time>=4||stateno = 400&&time>=6||stateno =410&&time>=5||Prevstateno=100&&stateno = 220&&time>=9
trigger4 = var(57)!=[0,1]
trigger4 = enemynear(var(58)),HitPauseTime>0
trigger4 = EnemyNear(var(58)),time <= time
trigger4 = P2bodydist X=[5,62]
trigger4 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger4 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno =410

[State -1, 絶望ォォォだねッ！]
type = ChangeState
value = 3000
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = !var(8)
triggerall = !var(13)
triggerall = power >= 1000
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),facing != facing
Triggerall = EnemyNear(var(58)),Vel X>=0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Movetype = A
triggerall = P2dist X > 0
Triggerall = Random <= 180
trigger1 = P2bodydist X<=25+EnemyNear(var(58)),Vel X*16
trigger1 = EnemyNear(var(58)),AnimTime <= -16||enemynear(var(58)),HitPauseTime >= 16||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -16
trigger1 = stateno = 200&&time>=4||stateno = 210&&time>=5||Prevstateno!=100&&stateno = 220&&time>=4||stateno = 400&&time>=6||stateno =410&&time>=5||stateno =420&&time>=6||Prevstateno=100&&stateno = 220&&time>=9
trigger1 = var(39) := 3
Trigger2 = P2bodydist X = [4,71]
trigger2 = EnemyNear(var(58)),AnimTime<=-16+(-P2bodydist X/4)||enemynear(var(58)),HitPauseTime>=16+(P2bodydist X/4)||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime<=-16+(-P2bodydist X/-4)
trigger2 = stateno = 200&&time>=4||stateno = 210&&time>=5||Prevstateno!=100&&stateno = 220&&time>=4||stateno = 400&&time>=6||stateno =410&&time>=5||stateno =420&&time>=6||Prevstateno=100&&stateno = 220&&time>=9
trigger2 = var(39) := 3
trigger3 = var(57)!=[0,1]
trigger3 = EnemyNear(var(58)),time <= time
trigger3 = P2bodydist X<=25+EnemyNear(var(58)),Vel X*16
trigger3 = EnemyNear(var(58)),AnimTime <= -16||enemynear(var(58)),HitPauseTime >= 16||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -16
trigger3 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno =410||stateno =420
trigger3 = var(39) := 3
trigger4 = var(57)!=[0,1]
trigger4 = EnemyNear(var(58)),time <= time
Trigger4 = P2bodydist X = [4,71]
trigger4 = EnemyNear(var(58)),AnimTime<=-16+(-P2bodydist X/4)||enemynear(var(58)),HitPauseTime>=16+(P2bodydist X/4)||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime<=-16+(-P2bodydist X/-4)
trigger4 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno =410||stateno =420
trigger4 = var(39) := 3
Trigger5 = P2bodydist X < 4
trigger5 = EnemyNear(var(58)),AnimTime<=-16||enemynear(var(58)),HitPauseTime>=16||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime<=-16
trigger5 = stateno = 200&&time>=4||stateno = 210&&time>=5||Prevstateno!=100&&stateno = 220&&time>=4||stateno = 400&&time>=6||stateno =410&&time>=5||stateno =420&&time>=6||Prevstateno=100&&stateno = 220&&time>=9
trigger5 = var(39) := 3
trigger6 = var(57)!=[0,1]
trigger6 = EnemyNear(var(58)),time <= time
Trigger6 = P2bodydist X < 4
trigger6 = EnemyNear(var(58)),AnimTime<=-16||enemynear(var(58)),HitPauseTime>=16||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime<=-16
trigger6 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno =410||stateno =420
trigger6 = var(39) := 3

[State -1, タンデム]
type = ChangeState
value = 3500
triggerall = var(59) = [3,4]
triggerall = var(57) = 2&&life<=lifemax/2||var(57) = 1||var(59)=4
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = !var(8) || var(0)
triggerall = !var(13)
triggerall = power >= 1000
triggerall = !numhelper(3509)
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),facing != facing
Triggerall = EnemyNear(var(58)),Vel X>=0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Movetype = A
triggerall = P2dist X+enemynear(var(58)),vel X*-9 > 0
Triggerall = Random <= 180
Trigger1 = enemynear(var(58)),Statetype = S
Trigger1 = enemynear(var(58)),Const(size.head.pos.y) <= -45
trigger1 = P2bodydist X<=40+enemynear(var(58)),vel X*6
trigger1 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
trigger1 = stateno = 200&&time>=4||stateno = 210&&time>=5||Prevstateno!=100&&stateno = 220&&time>=4||stateno = 400&&time>=6||stateno =410&&time>=5||stateno =420&&time>=6||Prevstateno=100&&stateno = 220&&time>=9
trigger2 = EnemyNear(var(58)),time <= time
Trigger2 = enemynear(var(58)),Statetype = S
Trigger2 = enemynear(var(58)),Const(size.head.pos.y) <= -45
trigger2 = P2bodydist X<=40+enemynear(var(58)),vel X*6
trigger2 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
trigger2 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno =410||stateno =420
trigger3 = P2bodydist x <= 30+enemynear(var(58)),vel X*6
trigger3 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
trigger3 = stateno = 200&&time>=4||stateno = 210&&time>=5||Prevstateno!=100&&stateno = 220&&time>=4||stateno = 400&&time>=6||stateno =410&&time>=5||stateno =420&&time>=6||Prevstateno=100&&stateno = 220&&time>=9
trigger4 = EnemyNear(var(58)),time <= time
trigger4 = P2bodydist x <= 30+enemynear(var(58)),vel X*6
trigger4 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
trigger4 = stateno = 200||stateno = 210||stateno = 220||stateno = 400||stateno =410||stateno =420

[State -1, ウシウシウシッ！]
type = ChangeState
value = 3950
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = var(31)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),facing != facing
Triggerall = EnemyNear(var(58)),Vel X>=0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Movetype = A
triggerall = P2dist X > 0
triggerall = power >= 1000
trigger1 = enemynear(var(58)),HitPauseTime<=0
trigger1 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*9
trigger1 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*9
trigger1 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
trigger1 = prevstateno!=3500&&stateno = 3501||stateno = 3700&&Time>3||stateno = 3701&&Time>3||stateno = 3702&&Time>3||stateno = 3900&&Time>4||stateno = 3901&&Time>6||stateno = 3501&&time>=9
trigger1 = var(39) := 3
trigger2 = enemynear(var(58)),HitPauseTime>0
trigger2 = P2bodydist X=[5,62]
trigger2 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
trigger2 = prevstateno!=3500&&stateno = 3501||stateno = 3700&&Time>3||stateno = 3701&&Time>3||stateno = 3702&&Time>3||stateno = 3900&&Time>4||stateno = 3901&&Time>6||stateno = 3501&&time>=9
trigger2 = var(39) := 3
trigger3 = enemynear(var(58)),Time < time
trigger3 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*9
trigger3 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*9
trigger3 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
trigger3 = prevstateno!=3500&&stateno = 3501||stateno = 3700||stateno = 3701||stateno = 3702||stateno = 3900||stateno = 3901||stateno = 3501&&time>=9
trigger3 = var(39) := 3
trigger4 = enemynear(var(58)),Time < time
trigger4 = enemynear(var(58)),HitPauseTime>0
trigger4 = P2bodydist X=[5,62]
trigger4 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
trigger4 = prevstateno!=3500&&stateno = 3501||stateno = 3700||stateno = 3701||stateno = 3702||stateno = 3900||stateno = 3901||stateno = 3501&&time>=9
trigger4 = var(39) := 3

[State -1, ウシウシウシッ！]
type = ChangeState
value = 3950
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = var(31)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),facing != facing
Triggerall = EnemyNear(var(58)),Vel X>=0
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Movetype = A
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*9)+(enemynear(var(58)),Const(Movement.Yaccel) *((9*(9-1)))/2) = [-60,-1]
triggerall = P2dist X > 0
triggerall = power >= 1000
trigger1 = enemynear(var(58)),HitPauseTime<=0
trigger1 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*9
trigger1 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*9
trigger1 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
trigger1 = prevstateno!=3500&&stateno = 3501||stateno = 3700&&Time>3||stateno = 3701&&Time>3||stateno = 3702&&Time>3||stateno = 3900&&Time>4||stateno = 3901&&Time>6||stateno = 3501&&time>=9
trigger2 = enemynear(var(58)),HitPauseTime>0
trigger2 = P2bodydist X=[5,62]
trigger2 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
trigger2 = prevstateno!=3500&&stateno = 3501||stateno = 3700&&Time>3||stateno = 3701&&Time>3||stateno = 3702&&Time>3||stateno = 3900&&Time>4||stateno = 3901&&Time>6||stateno = 3501&&time>=9
trigger3 = enemynear(var(58)),Time < time
trigger3 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*9
trigger3 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*9
trigger3 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
trigger3 = prevstateno!=3500&&stateno = 3501||stateno = 3700||stateno = 3701||stateno = 3702||stateno = 3900||stateno = 3901||stateno = 3501&&time>=9
trigger4 = enemynear(var(58)),Time < time
trigger4 = enemynear(var(58)),HitPauseTime>0
trigger4 = P2bodydist X=[5,62]
trigger4 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
trigger4 = prevstateno!=3500&&stateno = 3501||stateno = 3700||stateno = 3701||stateno = 3702||stateno = 3900||stateno = 3901||stateno = 3501&&time>=9

[State -1, 絶望ォォォだねッ！]
type = ChangeState
value = 3940
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = var(31)
triggerall = power >= 1000
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),facing != facing
Triggerall = EnemyNear(var(58)),Vel X>=0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Movetype = A
triggerall = P2dist X > 0
trigger1 = P2bodydist X<=25+EnemyNear(var(58)),Vel X*8
trigger1 = EnemyNear(var(58)),AnimTime <= -8||enemynear(var(58)),HitPauseTime >= 8||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -8
trigger1 = prevstateno!=3500&&stateno = 3501||stateno = 3700&&Time>3||stateno = 3701&&Time>3||stateno = 3702&&Time>3||stateno = 3900&&Time>4||stateno = 3901&&Time>6||stateno = 3501&&time>=9
trigger1 = var(39) := 3
Trigger2 = P2bodydist X = [3,50]
trigger2 = EnemyNear(var(58)),AnimTime<=-8+(-P2bodydist X/3)||enemynear(var(58)),HitPauseTime>=8+(P2bodydist X/3)||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime<=-8+(-P2bodydist X/3)
trigger2 = prevstateno!=3500&&stateno = 3501||stateno = 3700&&Time>3||stateno = 3701&&Time>3||stateno = 3702&&Time>3||stateno = 3900&&Time>4||stateno = 3901&&Time>6||stateno = 3501&&time>=9
trigger2 = var(39) := 3
Trigger3 = P2bodydist X < 3
trigger3 = EnemyNear(var(58)),AnimTime<=-8||enemynear(var(58)),HitPauseTime>=8||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime<=-8
trigger3 = prevstateno!=3500&&stateno = 3501||stateno = 3700&&Time>3||stateno = 3701&&Time>3||stateno = 3702&&Time>3||stateno = 3900&&Time>4||stateno = 3901&&Time>6||stateno = 3501&&time>=9
trigger3 = var(39) := 3
trigger4 = enemynear(var(58)),Time < time
trigger4 = P2bodydist X<=25+EnemyNear(var(58)),Vel X*8
trigger4 = EnemyNear(var(58)),AnimTime <= -8||enemynear(var(58)),HitPauseTime >= 8||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -8
trigger4 = prevstateno!=3500&&stateno = 3501||stateno = 3700||stateno = 3701||stateno = 3702||stateno = 3900||stateno = 3901||stateno = 3501&&time>=9
trigger4 = var(39) := 3
trigger5 = enemynear(var(58)),Time < time
trigger5 = EnemyNear(var(58)),AnimTime<=-8+(-P2bodydist X/3)||enemynear(var(58)),HitPauseTime>=8+(P2bodydist X/3)||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime<=-8+(-P2bodydist X/3)
trigger5 = prevstateno!=3500&&stateno = 3501||stateno = 3700||stateno = 3701||stateno = 3702||stateno = 3900||stateno = 3901||stateno = 3501&&time>=9
trigger5 = var(39) := 3
trigger6 = enemynear(var(58)),Time < time
Trigger6 = P2bodydist X < 3
trigger6 = prevstateno!=3500&&stateno = 3501||stateno = 3700||stateno = 3701||stateno = 3702||stateno = 3900||stateno = 3901||stateno = 3501&&time>=9
trigger6 = var(39) := 3


[State -1, ガキンチョがッ！]
type = ChangeState
value = 11100
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(39) = 0
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),AnimTime <= -15||enemynear(var(58)),HitPauseTime >= 15||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -15
triggerall = P2dist X > 0
triggerall = P2bodydist x = [25,60]
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))||stateno=5201
Trigger1 = Random <= 180
trigger1 = var(39) := 3

[State -1, 通常しゃがみ弱]
type = ChangeState
value = 400
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
trigger1 = EnemyNear(var(58)),AnimTime <= -5||enemynear(var(58)),HitPauseTime >= 5||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -5
trigger1 = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist x <= 38
Trigger1 = Random <= 180
trigger1 = var(39) := 3
trigger2 = var(57) = [1,2]
trigger2 = EnemyNear(var(58)),AnimTime <= -3||enemynear(var(58)),HitPauseTime >= 3||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -3
trigger2 = P2bodydist X + (Vel x*-3)+(Const(Movement.crouch.friction) *((3*(3-1)))/2) <= 38
trigger2 = stateno = 100 && time > 1
trigger2 = var(39) := 3

[State -1, 立ち強攻撃]
type = ChangeState
value = 220
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = S
Triggerall = enemynear(var(58)),Const(size.head.pos.y) <= -45
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
trigger1 = !var(0)&&P2bodydist x <= 45||var(0)&&P2bodydist x = [-5,40]
trigger1 = EnemyNear(var(58)),AnimTime <= -3||enemynear(var(58)),HitPauseTime >= 3||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -3
trigger1 = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = Random <= 180
trigger1 = var(39) := 3
trigger2 = !var(0)
trigger2 = var(57) = [1,2]
trigger2 = EnemyNear(var(58)),AnimTime <= -8||enemynear(var(58)),HitPauseTime >= 8||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -8
trigger2 = P2bodydist X + (Vel x*-8)+(Const(Movement.stand.friction) *((8*(8-1)))/2) <= 45
trigger2 = stateno = 100 && time > 1
trigger2 = var(39) := 3



[State -1, しゃがみ中]
type = ChangeState
value = 410
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
trigger1 = !var(0)&&P2bodydist x <= 38||var(0)&&P2bodydist x = [-5,38]
trigger1 = EnemyNear(var(58)),AnimTime <= -4||enemynear(var(58)),HitPauseTime >= 4||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -4
trigger1 = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = Random <= 180
trigger1 = var(39) := 3 
trigger2 = !var(0)
trigger2 = var(57) = [1,2]
trigger2 = EnemyNear(var(58)),AnimTime <= -6||enemynear(var(58)),HitPauseTime >= 6||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -6
trigger2 = P2bodydist X + (Vel x*-6)+(Const(Movement.crouch.friction) *((6*(6-1)))/2) <= 45
trigger2 = stateno = 100 && time > 1
trigger2 = var(39) := 3


[State -1, ダッシュ]
type = ChangeState
value = 100
triggerall = var(59) = [3,4]
triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Vel X >= 0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
trigger1 = EnemyNear(var(58)),AnimTime <= -5||enemynear(var(58)),HitPauseTime >= 5||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -5
trigger1 = P2bodydist x = [38,70]
Trigger2 = enemynear(var(58)),Statetype = S
Trigger2 = enemynear(var(58)),Const(size.head.pos.y) <= -45
trigger2 = EnemyNear(var(58)),AnimTime <= -10||enemynear(var(58)),HitPauseTime >= 10||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -10
trigger2 = P2bodydist x = [38,106]
trigger3 = EnemyNear(var(58)),AnimTime <= -8||enemynear(var(58)),HitPauseTime >= 8||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -8
trigger3 = P2bodydist x = [38,86]


[State -1,タンデム]
type = ChangeState
value = 3500
triggerall = var(59) =[3,4]
triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = !numhelper(3509)
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = power >= 1000
triggerall = !var(8) || var(0)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Vel X >= 0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
Triggerall = Random <= 180
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = EnemyNear(var(58)),AnimTime <= -10||enemynear(var(58)),HitPauseTime >= 10||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -10
trigger1 = P2bodydist x =[38,150]
trigger1 = var(39) := 3


[State -1, 通常しゃがみ強]
type = ChangeState
value = 420
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = EnemyNear(var(58)),AnimTime <= -5||enemynear(var(58)),HitPauseTime >= 5||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -5
trigger1 = P2bodydist x = [38,100]
Trigger1 = Random <= 180
trigger1 = var(39) := 3


[State -1, 通常しゃがみ強]
type = ChangeState
value = 420
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = EnemyNear(var(58)),AnimTime <= -5||enemynear(var(58)),HitPauseTime >= 5||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -5
trigger1 = P2bodydist x = [38,100]
Trigger1 = Random <= 180
trigger1 = var(39) := 3



[State -1, S立ち強攻撃]
type = ChangeState
value = 10220
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0)
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),AnimTime <= -7||enemynear(var(58)),HitPauseTime >= 7||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -7
triggerall = P2dist X > 0
triggerall = P2bodydist x != [-5,40]
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
Trigger1 = enemynear(var(58)),facing != facing
trigger1 = enemynear(var(58)),HitPauseTime <= 0
trigger1 =  P2bodydist X>=41+((fvar(10)-1)/0.02*1.35)+(enemynear(var(58)),vel X*7) 
trigger1 = P2bodydist X<=145+((fvar(10)-1)/0.02*1.35)+(enemynear(var(58)),vel X*7)
trigger1 = var(39) := 3
trigger2 = enemynear(var(58)),HitPauseTime <= 0
Trigger2 = enemynear(var(58)),facing = facing
trigger2 = P2bodydist X>=31+((fvar(10)-1)/0.02*1.35)+(enemynear(var(58)),vel X*-7) 
trigger2 = P2bodydist X<=135+((fvar(10)-1)/0.02*1.35)+(enemynear(var(58)),vel X*-7)
trigger2 = var(39) := 3
Trigger3 = enemynear(var(58)),facing != facing
trigger3 = enemynear(var(58)),HitPauseTime > 0
trigger3 =  P2bodydist X>=41+((fvar(10)-1)/0.02*1.35)
trigger3 = P2bodydist X<=145+((fvar(10)-1)/0.02*1.35)
trigger3 = var(39) := 3
trigger4 = enemynear(var(58)),HitPauseTime > 0
Trigger4 = enemynear(var(58)),facing = facing
trigger4 = P2bodydist X>=31+((fvar(10)-1)/0.02*1.35) 
trigger4 = P2bodydist X<=135+((fvar(10)-1)/0.02*1.35)
trigger4 = var(39) := 3


[State -1, S立ち中攻撃]
type = ChangeState
value = 10210
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0)
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),AnimTime <= -5||enemynear(var(58)),HitPauseTime >= 5||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -5
triggerall = P2dist X > 0
triggerall = P2bodydist x != [-5,30]
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
Trigger1 = enemynear(var(58)),facing != facing
trigger1 = enemynear(var(58)),HitPauseTime <= 0
trigger1 = P2bodydist X>=65+((fvar(10)-1)/0.02*1.35)+(enemynear(var(58)),vel X*5) 
trigger1 = P2bodydist X<=123+((fvar(10)-1)/0.02*1.35)+(enemynear(var(58)),vel X*5)
trigger1 = var(39) := 3
Trigger2 = enemynear(var(58)),facing = facing
trigger2 = enemynear(var(58)),HitPauseTime <= 0
trigger2 = P2bodydist X>=55+((fvar(10)-1)/0.02*1.35)+(enemynear(var(58)),vel X*-5) 
trigger2 = P2bodydist X<=113+((fvar(10)-1)/0.02*1.35)+(enemynear(var(58)),vel X*-5)
trigger2 = var(39) := 3
Trigger3 = enemynear(var(58)),facing != facing
trigger3 = enemynear(var(58)),HitPauseTime > 0
trigger3 = P2bodydist X>=65+((fvar(10)-1)/0.02*1.35)
trigger3 = P2bodydist X<=123+((fvar(10)-1)/0.02*1.35)
trigger3 = var(39) := 3
Trigger4 = enemynear(var(58)),facing = facing
trigger4 = enemynear(var(58)),HitPauseTime > 0
trigger4 = P2bodydist X>=55+((fvar(10)-1)/0.02*1.35)
trigger4 = P2bodydist X<=113+((fvar(10)-1)/0.02*1.35)
trigger4 = var(39) := 3



[State -1, S立ち弱攻撃]
type = ChangeState
value = 10200
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0)
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),AnimTime <= -4||enemynear(var(58)),HitPauseTime >= 4||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -4
triggerall = P2dist X > 0
triggerall = P2bodydist x != [-5,30]
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
Trigger1 = enemynear(var(58)),facing != facing
trigger1 = enemynear(var(58)),HitPauseTime <= 0
trigger1 = P2bodydist X>=31+((fvar(10)-1)/0.02*1.35)+(enemynear(var(58)),vel X*4) 
trigger1 = P2bodydist X<=97+((fvar(10)-1)/0.02*1.35)+(enemynear(var(58)),vel X*4)
trigger1 = var(39) := 3
Trigger2 = enemynear(var(58)),facing = facing
trigger2 = enemynear(var(58)),HitPauseTime <= 0
trigger2 = P2bodydist X>=21+((fvar(10)-1)/0.02*1.35)+(enemynear(var(58)),vel X*-4) 
trigger2 = P2bodydist X<=87+((fvar(10)-1)/0.02*1.35)+(enemynear(var(58)),vel X*-4)
trigger2 = var(39) := 3
Trigger3 = enemynear(var(58)),facing != facing
trigger3 = enemynear(var(58)),HitPauseTime > 0
trigger3 = P2bodydist X>=31+((fvar(10)-1)/0.02*1.35)
trigger3 = P2bodydist X<=97+((fvar(10)-1)/0.02*1.35)
trigger3 = var(39) := 3
Trigger4 = enemynear(var(58)),facing = facing
trigger4 = enemynear(var(58)),HitPauseTime > 0
trigger4 = P2bodydist X>=21+((fvar(10)-1)/0.02*1.35)
trigger4 = P2bodydist X<=87+((fvar(10)-1)/0.02*1.35)
trigger4 = var(39) := 3



[State -1, Sダッシュ立ち強攻撃]
type = ChangeState
value = 10221
triggerall = var(59) = [3,4]
triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0)
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),AnimTime <= -7||enemynear(var(58)),HitPauseTime >= 7||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -7
triggerall = P2dist X > 0
triggerall = stateno = 100 && time > 1
trigger1 = P2bodydist X + (Vel x*-7)+(Const(Movement.stand.friction) *((7*(7-1)))/2) >= 41+(enemynear(var(58)),vel X*7) 
trigger1 = P2bodydist X + (Vel x*-7)+(Const(Movement.stand.friction) *((7*(7-1)))/2) <= 145+(enemynear(var(58)),vel X*7) 
trigger1 = var(39) := 3


[State -1, Sダッシュ立ち中攻撃]
type = ChangeState
value = 10211
triggerall = var(59) = [3,4]
triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0)
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),AnimTime <= -5||enemynear(var(58)),HitPauseTime >= 5||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -5
triggerall = P2dist X > 0
triggerall = stateno = 100 && time > 1
trigger1 = P2bodydist X + (Vel x*-5)+(Const(Movement.stand.friction) *((5*(5-1)))/2) >= 25+(enemynear(var(58)),vel X*5) 
trigger1 = P2bodydist X + (Vel x*-5)+(Const(Movement.stand.friction) *((5*(5-1)))/2) <= 70+(enemynear(var(58)),vel X*5) 
trigger1 = var(39) := 3



[State -1, ダッシュ]
type = ChangeState
value = 100
triggerall = var(59) = [3,4]
triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
Triggerall = Random <= 150
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X>145+((fvar(10)-1)/0.02*1.35)
trigger1 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
trigger1 = P2bodydist X + (7.5*-9)+(Const(Movement.stand.friction) *((9*(9-1)))/2) >= 51+(enemynear(var(58)),vel X*9) 
trigger1 = P2bodydist X + (7.5*-9)+(Const(Movement.stand.friction) *((9*(9-1)))/2) <= 145+(enemynear(var(58)),vel X*9) 
trigger2 = P2bodydist X>123+((fvar(10)-1)/0.02*1.35)
trigger2 = EnemyNear(var(58)),AnimTime <= -7||enemynear(var(58)),HitPauseTime >= 7||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -7
trigger2 = P2bodydist X + (7.5*-7)+(Const(Movement.stand.friction) *((7*(7-1)))/2) >= 25+(enemynear(var(58)),vel X*7) 
trigger2 = P2bodydist X + (7.5*-7)+(Const(Movement.stand.friction) *((7*(7-1)))/2) <= 70+(enemynear(var(58)),vel X*7) 



[State -1, Sしゃがみ強]
type = ChangeState
value = 10420
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = EnemyNear(var(58)),AnimTime <= -5||enemynear(var(58)),HitPauseTime >= 5||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -5
trigger1 = P2bodydist x = [40,100]
Trigger1 = Random <= 180
trigger1 = var(39) := 3

[State -1, 蜂の巣だッ！]
type = ChangeState
value = 1000
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),Vel X = [-1,1]
triggerall = EnemyNear(var(58)),AnimTime <= -15||enemynear(var(58)),HitPauseTime >= 15||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -15
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
Triggerall = Random <= 180
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = var(57) = [1,2]
trigger1 = P2bodydist X = [75,105]
trigger1 = var(2) := 1
trigger2 = P2bodydist X = [140,165]
trigger2 = var(2) := 2

[State -1, ガキ立ち強攻撃]
type = ChangeState
value = 270
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = EnemyNear(var(58)),AnimTime <= -6||enemynear(var(58)),HitPauseTime >= 6||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -6
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
Triggerall = Random <= 180
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = (!var(0)&&(p2bodydist x =[31,85]) || (p2bodydist x = [-5,40]))

[State -1, ガキしゃがみ弱通常攻撃]
type = ChangeState
value = 450
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(0)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = EnemyNear(var(58)),AnimTime <= -3||enemynear(var(58)),HitPauseTime >= 3||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -3
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
Triggerall = Random <= 180
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 =(!var(0)&&(p2bodydist x <=43) || (p2bodydist x = [-5,40]))

[State -1, ガキンチョがッ！]
type = ChangeState
value = 11100
triggerall = var(59) =[3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemynear(var(58)),HitPauseTime <= 0
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))||stateno=5201
Triggerall = Random <= 180
trigger1 = enemynear(var(58)),facing != facing
trigger1 =  (P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),GetHitVar(Yaccel) *((15*(15-1)))/2) =[-10,5])
trigger1 = P2bodydist X >= 25+EnemyNear(var(58)),Vel X*15
trigger1 = P2bodydist X <= 60+EnemyNear(var(58)),Vel X*15
trigger2 = enemynear(var(58)),facing = facing
trigger2 =  (P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),GetHitVar(Yaccel) *((15*(15-1)))/2) =[-10,5])
trigger2 = P2bodydist X >= 15+EnemyNear(var(58)),Vel X*-15
trigger2 = P2bodydist X <= 50+EnemyNear(var(58)),Vel X*-15
trigger3 = enemynear(var(58)),facing != facing
trigger3 =  (P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),GetHitVar(Yaccel) *((20*(20-1)))/2) =[-10,5])
trigger3 = P2bodydist X >= 15+EnemyNear(var(58)),Vel X*20
trigger3 = P2bodydist X <= 50+EnemyNear(var(58)),Vel X*20
trigger4 = enemynear(var(58)),facing = facing
trigger4 =  (P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),GetHitVar(Yaccel) *((20*(20-1)))/2) =[-10,5])
trigger4 = P2bodydist X >= 15+EnemyNear(var(58)),Vel X*-20
trigger4 = P2bodydist X <= 50+EnemyNear(var(58)),Vel X*-20
trigger5 =  (P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),GetHitVar(Yaccel) *((15*(15-1)))/2) =[-10,5]) || (P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),GetHitVar(Yaccel) *((20*(20-1)))/2) =[-10,5])
trigger5 = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<= 0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
trigger5 = var(57) = 2 && (((floor(helper(21000),RootDist X) =[75,125]) && facing = 1)||((floor(helper(25000),RootDist X) = [75,125]) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist = [55,105]

[State -1, 通常立ち弱]
type = ChangeState
value = 200
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*3)+(enemynear(var(58)),Const(Movement.Yaccel) *((3*(3-1)))/2) >= -30||P2Dist Y >= -30&&enemynear(var(58)),HitPauseTime >= 3
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
trigger1 = var(0)&& (p2bodydist x = [-5,30])
trigger2 = !var(0)
trigger2 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 29+EnemyNear(var(58)),Vel X*3)||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 29+EnemyNear(var(58)),Vel X*-3)

[State -1, 通常立ち強]
type = ChangeState
value = 220
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = (!var(0)&&P2bodydist x <= 45 || (p2bodydist x = [-5,40]))
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*3)+(enemynear(var(58)),Const(Movement.Yaccel) *((3*(3-1)))/2) >= -30||P2Dist Y >= -30&&enemynear(var(58)),HitPauseTime >= 3
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
trigger1 = var(0)&& (p2bodydist x = [-5,40])
trigger2 = !var(0)
trigger2 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 45+EnemyNear(var(58)),Vel X*3)||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 45+EnemyNear(var(58)),Vel X*-3)

[State -1, 通常しゃがみ強]
type = ChangeState
value = 420
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),HitPauseTime <= 0
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*5)+(enemynear(var(58)),Const(Movement.Yaccel) *((5*(5-1)))/2) = [-5,20]
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
trigger1 = p2bodydist X >= 45
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 100+EnemyNear(var(58)),Vel X*5)||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 90+EnemyNear(var(58)),Vel X*-5)

[State -1, 蜂の巣]
type = ChangeState
value = 1000
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),Const(Movement.Yaccel) *((15*(15-1)))/2) >= -70
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 105+EnemyNear(var(58)),Vel X*15)||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 95+EnemyNear(var(58)),Vel X*-15)
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X >= 60+EnemyNear(var(58)),Vel X*15)||(EnemyNear(var(58)),facing = facing&&P2bodydist X >= 85+EnemyNear(var(58)),Vel X*-15)
trigger1 = P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),Const(Movement.Yaccel) *((15*(15-1)))/2) = [-70,30]
trigger1 = var(2) := 1
trigger2 = (EnemyNear(var(58)),facing != facing&&P2bodydist X >= 140+EnemyNear(var(58)),Vel X*15)||(EnemyNear(var(58)),facing = facing&&P2bodydist X >= 130+EnemyNear(var(58)),Vel X*-15)
trigger2 = P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),Const(Movement.Yaccel) *((15*(15-1)))/2) >= -70
trigger2 = var(2) := 2
trigger3 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 60+EnemyNear(var(58)),Vel X*15)||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 95+EnemyNear(var(58)),Vel X*-15)
trigger3 = (EnemyNear(var(58)),facing != facing&&P2bodydist X >= 45+EnemyNear(var(58)),Vel X*15)||(EnemyNear(var(58)),facing = facing&&P2bodydist X >= 85+EnemyNear(var(58)),Vel X*-15)
trigger3 = P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),Const(Movement.Yaccel) *((15*(15-1)))/2) = [-70,20]
trigger3 = var(2) := 0||1

[State -1, S立ち強]
type = ChangeState
value = 10220
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0)
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*7)+(enemynear(var(58)),Const(Movement.Yaccel) *((7*(7-1)))/2) >= -30||P2Dist Y >= -30&&enemynear(var(58)),HitPauseTime >= 7
triggerall=  (p2bodydist x != [-5,40])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
trigger1 = EnemyNear(var(58)),facing != facing
trigger1 = P2bodydist X >= 41+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*7
trigger1 = P2bodydist X <= 145+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*7
trigger2 = EnemyNear(var(58)),facing = facing
trigger2 = P2bodydist X >= 41+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*-7
trigger2 = P2bodydist X <= 135+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*-7
trigger3 = var(57) = 2 
Trigger3 = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
trigger3 =  helper(21000),RootDist X >= 115+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X >=115+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger3 =  helper(21000),RootDist X <= 190+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=190+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger4 = var(57) != 2 
Trigger4 = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
trigger4 =  frontEdgeBodyDist >= 95+((fvar(10)-1)/0.02*1.35) 
trigger4 =  frontEdgeBodyDist <= 170+((fvar(10)-1)/0.02*1.35)

[State -1, S立ち中]
type = ChangeState
value = 10210
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0)
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*5)+(enemynear(var(58)),Const(Movement.Yaccel) *((5*(5-1)))/2) >= -40||P2Dist Y >= -40&&enemynear(var(58)),HitPauseTime >= 5
triggerall=  (p2bodydist x != [-5,30])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
trigger1 = EnemyNear(var(58)),facing != facing
trigger1 = P2bodydist X >= 65+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*5
trigger1 = P2bodydist X <= 123+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*5
trigger2 = EnemyNear(var(58)),facing = facing
trigger2 = P2bodydist X >= 55+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*-5
trigger2 = P2bodydist X <= 113+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*-5
trigger3 = var(57) = 2 
Trigger3 = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
trigger3 =  helper(21000),RootDist X >= 125+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X >=125+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger3 =  helper(21000),RootDist X <= 160+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=160+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger4 = var(57) != 2 
Trigger4 = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
trigger4 =  frontEdgeBodyDist >= 105+((fvar(10)-1)/0.02*1.35) 
trigger4 =  frontEdgeBodyDist <= 140+((fvar(10)-1)/0.02*1.35)

[State -1, S立ち弱]
type = ChangeState
value = 10200
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0)
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*4)+(enemynear(var(58)),Const(Movement.Yaccel) *((4*(4-1)))/2) >= -10||P2Dist Y >= -10&&enemynear(var(58)),HitPauseTime >= 4
triggerall=  (p2bodydist x != [-5,30])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
trigger1 = EnemyNear(var(58)),facing != facing
trigger1 = P2bodydist X >= 31+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*4
trigger1 = P2bodydist X <= 97+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*4
trigger2 = EnemyNear(var(58)),facing = facing
trigger2 = P2bodydist X >= 31+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*-4
trigger2 = P2bodydist X <= 87+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*-4
trigger3 = var(57) = 2 
Trigger3 = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
trigger3 =  helper(21000),RootDist X >= 75+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X >=75+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger3 =  helper(21000),RootDist X <= 140+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=140+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger4 = var(57) != 2 
Trigger4 = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
trigger4 =  frontEdgeBodyDist <= 120+((fvar(10)-1)/0.02*1.35)
trigger4 =  frontEdgeBodyDist >= 55+((fvar(10)-1)/0.02*1.35) 

[State -1, ガキ近強攻撃]
type = ChangeState
value = 275
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*3)+(enemynear(var(58)),Const(Movement.Yaccel) *((3*(3-1)))/2) >= -60||P2Dist Y >= -60&&enemynear(var(58)),HitPauseTime >= 3
trigger1 = (p2bodydist x = [-5,30])

[State -1, ガキ立ち強攻撃]
type = ChangeState
value = 270
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*6)+(enemynear(var(58)),Const(Movement.Yaccel) *((6*(6-1)))/2) >= -40||P2Dist Y >= -40&&enemynear(var(58)),HitPauseTime >= 6
trigger1 = !var(0) 
trigger1 =  (p2bodydist x != [-5,30])
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 85+EnemyNear(var(58)),Vel X*6)||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 75+EnemyNear(var(58)),Vel X*-6)
trigger2 = var(0) 
trigger2 = (p2bodydist x = [-5,40])

[State -1, Sしゃがみ強]
type = ChangeState
value = 10420
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),HitPauseTime <= 0
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*5)+(enemynear(var(58)),Const(Movement.Yaccel) *((5*(5-1)))/2) = [-5,20]
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
trigger1 = p2bodydist X >= 40
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 100+EnemyNear(var(58)),Vel X*5)||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 90+EnemyNear(var(58)),Vel X*-5)

[State -1, 蜂の巣]
type = ChangeState
value = 1000
triggerall = var(59) = [3,4]
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = (EnemyNear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X<=0)||(EnemyNear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X>=0)
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),Const(Movement.Yaccel) *((15*(15-1)))/2) >= -70
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= 180
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X >= 140+EnemyNear(var(58)),Vel X*15)||(EnemyNear(var(58)),facing = facing&&P2bodydist X >= 130+EnemyNear(var(58)),Vel X*-15)
trigger1 = var(2) := 2

[State -1, 通常空中強攻撃]
type = ChangeState
value = 620
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(0) 
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype = A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = ctrl
triggerall = Pos Y + (Vel y*4)+(Const(Movement.Yaccel) *((4*(4-1)))/2) <= -1
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*4)+(enemynear(var(58)),Const(Movement.Yaccel) *((4*(4-1)))/2) = [-40,70]
Triggerall = Random <= 180
trigger1 = enemynear(var(58)),facing != facing
trigger1 = P2bodydist X <=60 +enemynear(var(58)),Vel X*4+Vel X*4
trigger2 = enemynear(var(58)),facing = facing
trigger2 = P2bodydist X <=60 +enemynear(var(58)),Vel X*-4+Vel X*4
trigger3 = P2bodydist X <= 60+enemynear(var(58)),Vel X*4
trigger3 =var(57) = 2 && ((floor(helper(21000),RootDist X) <= 25 && facing = -1)||(floor(helper(25000),RootDist X) <= 30 && facing = 1)) || (var(57) != 2) &&  backEdgeBodyDist <= 10

[State -1, S空中中攻撃]
type = ChangeState
value = 10610
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0) 
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype = A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = ctrl
triggerall = Pos Y + (Vel y*9)+(Const(Movement.Yaccel) *((9*(9-1)))/2) <= -1
triggerall = enemynear(var(58)),Pos y + (enemynear(var(58)),Vel y*9)+(enemynear(var(58)),Const(Movement.Yaccel) *((9*(9-1)))/2)= [-20,-1]
Triggerall = Random <= 180
trigger1 = enemynear(var(58)),facing != facing
trigger1 = P2bodydist X <=35 +enemynear(var(58)),Vel X*9+Vel X*9
trigger2 = enemynear(var(58)),facing = facing
trigger2 = P2bodydist X <=35 +enemynear(var(58)),Vel X*-9+Vel X*9
trigger3 = P2bodydist X <= 35+enemynear(var(58)),Vel X*9
trigger3 =var(57) = 2 && ((floor(helper(21000),RootDist X) <= 25 && facing = -1)||(floor(helper(25000),RootDist X) <= 30 && facing = 1)) || (var(57) != 2) &&  backEdgeBodyDist <= 10

[State -1, S空中強攻撃]
type = ChangeState
value = 10620
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0) 
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype = A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = ctrl
triggerall = Pos Y + (Vel y*8)+(Const(Movement.Yaccel) *((8*(8-1)))/2) <= -1
triggerall = enemynear(var(58)),Pos y + (enemynear(var(58)),Vel y*8)+(enemynear(var(58)),Const(Movement.Yaccel) *((8*(8-1)))/2)= [-10,-1]
Triggerall = Random <= 180
trigger1 = enemynear(var(58)),facing != facing
trigger1 = P2bodydist X <=48 +enemynear(var(58)),Vel X*8+Vel X*8
trigger2 = enemynear(var(58)),facing = facing
trigger2 = P2bodydist X <=48 +enemynear(var(58)),Vel X*-8+Vel X*8
trigger3 = P2bodydist X <= 48+enemynear(var(58)),Vel X*8
trigger3 =var(57) = 2 && ((floor(helper(21000),RootDist X) <= 25 && facing = -1)||(floor(helper(25000),RootDist X) <= 30 && facing = 1)) || (var(57) != 2) &&  backEdgeBodyDist <= 10

[State -1, 通常空中強攻撃]
type = ChangeState
value = 620
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = !var(0) 
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype = A
Triggerall = EnemyNear(var(58)),Alive
triggerall = EnemyNear(var(58)),AnimTime <= -4
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = ctrl
triggerall = Pos Y + (Vel y*4)+(Const(Movement.Yaccel) *((4*(4-1)))/2) <= -1
triggerall = P2bodyDist Y + (Vel y*-4)+(Const(Movement.Yaccel) *((4*(4-1)))/2) <= 40
Triggerall = Random <= 180
trigger1 = enemynear(var(58)),facing!=facing&&P2bodydist X<=60+enemynear(var(58)),Vel X*4+vel X*4||enemynear(var(58)),facing=facing&&P2bodydist X<=50+enemynear(var(58)),Vel X*-4+vel X*4
trigger2 = enemynear(var(58)),facing!=facing&&P2bodydist X<=60+enemynear(var(58)),Vel X*4||enemynear(var(58)),facing=facing&&P2bodydist X<=50+enemynear(var(58)),Vel X*-4
trigger2 =var(57) = 2 && ((floor(helper(21000),RootDist X) <= 25 && facing = -1)||(floor(helper(25000),RootDist X) <= 25 && facing = 1)) || (var(57) != 2) &&  backEdgeBodyDist <= 10

[State -1, S空中中攻撃]
type = ChangeState
value = 10610
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0) 
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype = A
Triggerall = EnemyNear(var(58)),Alive
triggerall = EnemyNear(var(58)),AnimTime <= -9
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = ctrl
triggerall = Pos Y + (Vel y*9)+(Const(Movement.Yaccel) *((9*(9-1)))/2) <= -1
Triggerall = Random <= 180
trigger1 = enemynear(var(58)),facing!=facing&&P2bodydist X<=35+enemynear(var(58)),Vel X*9+vel X*9||enemynear(var(58)),facing=facing&&P2bodydist X<=25+enemynear(var(58)),Vel X*-9+vel X*9
trigger2 = enemynear(var(58)),facing!=facing&&P2bodydist X<=35+enemynear(var(58)),Vel X*9||enemynear(var(58)),facing=facing&&P2bodydist X<=25+enemynear(var(58)),Vel X*-9
trigger2 =var(57) = 2 && ((floor(helper(21000),RootDist X) <= 25 && facing = -1)||(floor(helper(25000),RootDist X) <= 25 && facing = 1)) || (var(57) != 2) &&  backEdgeBodyDist <= 10


[State -1, S空中強攻撃]
type = ChangeState
value = 10620
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45) = [1,2]) || var(45) = 4
triggerall = var(0) 
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype = A
Triggerall = EnemyNear(var(58)),Alive
triggerall = EnemyNear(var(58)),AnimTime <= -8
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall = ctrl
triggerall = Pos Y + (Vel y*8)+(Const(Movement.Yaccel) *((8*(8-1)))/2) <= -1
Triggerall = Random <= 180
trigger1 = enemynear(var(58)),facing!=facing&&P2bodydist X<=48+enemynear(var(58)),Vel X*8+vel X*8||enemynear(var(58)),facing=facing&&P2bodydist X<=38+enemynear(var(58)),Vel X*-8+vel X*8
trigger2 = enemynear(var(58)),facing!=facing&&P2bodydist X<=48+enemynear(var(58)),Vel X*8||enemynear(var(58)),facing=facing&&P2bodydist X<=38+enemynear(var(58)),Vel X*-8
trigger2 =var(57) = 2 && ((floor(helper(21000),RootDist X) <= 25 && facing = -1)||(floor(helper(25000),RootDist X) <= 25 && facing = 1)) || (var(57) != 2) &&  backEdgeBodyDist <= 10

[State -1, 絶望ォォォだねッ！]
type = ChangeState
value = 3000
triggerall = var(59) = [3,4]
triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&EnemyNear(var(58)),Time <= 15
triggerall = var(49) = 1
triggerall = var(47)=[0,5]
triggerall = var(39) = 0
triggerall = !var(8)
triggerall = !var(13)
triggerall = power >= 1000
triggerall = statetype != A
triggerall = InGuardDist
Triggerall = EnemyNear(var(58)),Alive
Triggerall = (enemynear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X >= 0)||(enemynear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X <= 0)
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Movetype = A
triggerall = P2dist X > 0
Triggerall = Random <= 25
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))||stateno = 195 && time >= 20||stateno=[10900,10901]
trigger1 = enemynear(var(58)),HitPauseTime <= 0
trigger1 = P2bodydist X<=25+EnemyNear(var(58)),Vel X*16
trigger1 = EnemyNear(var(58)),AnimTime <= -16||enemynear(var(58)),HitPauseTime >= 16||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -16
trigger1 = var(39) := 3
Trigger2 = P2bodydist X = [4,71]
trigger2 = EnemyNear(var(58)),AnimTime<=-16+(-P2bodydist X/4)||enemynear(var(58)),HitPauseTime>=16+(P2bodydist X/4)||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime<=-16+(-P2bodydist X/4)
trigger2 = var(39) := 3
trigger3 = enemynear(var(58)),HitPauseTime > 0
trigger3 = P2bodydist X<=25
trigger3 = EnemyNear(var(58)),AnimTime <= -16||enemynear(var(58)),HitPauseTime >= 16||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -16
trigger3 = var(39) := 3

[State -1, ウシウシウシッ！]
type = ChangeState
value = ifelse((!var(0)),3100,3200)
triggerall = var(59) = [3,4]
triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&EnemyNear(var(58)),Time <= 15
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = var(47)=[6,11]
triggerall = !var(8)
triggerall = !var(13)
triggerall = power >= 1000
triggerall = statetype != A
triggerall = InGuarddist
Triggerall = EnemyNear(var(58)),Alive
Triggerall = (enemynear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X >= 0)||(enemynear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X <= 0)
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Movetype = A
triggerall = P2dist X > 0
Triggerall = Random <= 25
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))||stateno = 195 && time >= 20||stateno=[10900,10901]
trigger1 = enemynear(var(58)),HitPauseTime<=0
trigger1 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*20
trigger1 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*20
trigger1 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger1 = var(39) := 3
trigger2 = enemynear(var(58)),HitPauseTime>0
trigger2 = P2bodydist X>=5
trigger2 = P2bodydist X<=62
trigger2 = EnemyNear(var(58)),AnimTime <= -20||enemynear(var(58)),HitPauseTime >= 20||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -20
trigger2 = var(39) := 3

[State -1, ウシウシウシッ！]
type = ChangeState
value = ifelse((!var(0)),3100,3200)
triggerall = var(59) = [3,4]
triggerall = (var(57) = [1,2])||(var(57) != [1,2])&&EnemyNear(var(58)),Time <= 15
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),facing != facing
Triggerall = EnemyNear(var(58)),Vel X>=0
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Movetype = A
triggerall = P2dist X > 0
triggerall = power >= 1000
Triggerall = Random <= 40
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))||stateno = 195 && time >= 20||stateno=[10900,10901]
trigger1 = P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) = [-60,-1]
trigger1 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*20
trigger1 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*20
trigger2 = P2Dist Y + (enemynear(var(58)),Vel y*21)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) = [-60,-1]
trigger2 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*21
trigger2 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*21
trigger3 = P2Dist Y + (enemynear(var(58)),Vel y*22)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) = [-60,-1]
trigger3 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*22
trigger3 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*22
trigger4 = P2Dist Y + (enemynear(var(58)),Vel y*23)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) = [-60,-1]
trigger4 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*23
trigger4 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*23
trigger5 = P2Dist Y + (enemynear(var(58)),Vel y*24)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) = [-60,-1]
trigger5 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*24
trigger5 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*24
trigger6 = P2Dist Y + (enemynear(var(58)),Vel y*25)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) = [-60,-1]
trigger6 = P2bodydist X>=5+EnemyNear(var(58)),Vel X*25
trigger6 = P2bodydist X<=62+EnemyNear(var(58)),Vel X*25

[State -1,タンデム]
type = ChangeState
value = 3500
triggerall = var(59) = [3,4]
triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = var(45) = 0
triggerall = var(39) = 0
triggerall = !numhelper(3509)
triggerall = power >= 1000
triggerall = life<=lifemax/2||var(59)=4
triggerall = !var(8) || var(0)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = InGuarddist
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),facing != facing
Triggerall = enemynear(var(58)),Vel X >= 0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Movetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X+enemynear(var(58)),vel X*-9 > 0
Triggerall = Random <= 35
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))||stateno = 195 && time >= 20||stateno = 5201||stateno=[10900,10901]
Trigger1 = enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 40+enemynear(var(58)),vel X*6||P2bodydist x <= 30+enemynear(var(58)),vel X*6
trigger1 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
Trigger2 = enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 50+enemynear(var(58)),vel X*7||P2bodydist x <= 40+enemynear(var(58)),vel X*7
trigger2 = EnemyNear(var(58)),AnimTime <= -10||enemynear(var(58)),HitPauseTime >= 10||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -10
Trigger3 = enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 60+enemynear(var(58)),vel X*8||P2bodydist x <= 40+enemynear(var(58)),vel X*8
trigger3 = EnemyNear(var(58)),AnimTime <= -11||enemynear(var(58)),HitPauseTime >= 11||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -11
Trigger4= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 70+enemynear(var(58)),vel X*9||P2bodydist x <= 50+enemynear(var(58)),vel X*9
trigger4 = EnemyNear(var(58)),AnimTime <= -12||enemynear(var(58)),HitPauseTime >= 12||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -12
Trigger5= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 80+enemynear(var(58)),vel X*10||P2bodydist x <= 60+enemynear(var(58)),vel X*10
trigger5 = EnemyNear(var(58)),AnimTime <= -13||enemynear(var(58)),HitPauseTime >= 13||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -13
Trigger6= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 90+enemynear(var(58)),vel X*11||P2bodydist x <= 70+enemynear(var(58)),vel X*11
trigger6 = EnemyNear(var(58)),AnimTime <= -14||enemynear(var(58)),HitPauseTime >= 14||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -14
Trigger7= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 100+enemynear(var(58)),vel X*12||P2bodydist x <= 80+enemynear(var(58)),vel X*12
trigger7 = EnemyNear(var(58)),AnimTime <= -15||enemynear(var(58)),HitPauseTime >= 15||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -15
Trigger8= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 110+enemynear(var(58)),vel X*13||P2bodydist x <= 90+enemynear(var(58)),vel X*13
trigger8 = EnemyNear(var(58)),AnimTime <= -16||enemynear(var(58)),HitPauseTime >= 16||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -16

[State -1,ガーキャンタンデム]
type = ChangeState
value = 700
triggerall = var(59) = 4
triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = var(45) = 0
triggerall = var(39) = 0
triggerall = !numhelper(3509)
triggerall = power >= 1000
triggerall = life<=lifemax/2||var(59)=4
triggerall = var(0)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = InGuarddist
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),facing != facing
Triggerall = enemynear(var(58)),Vel X >= 0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Movetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X+enemynear(var(58)),vel X*-10 > 0
Triggerall = Random <= 280
triggerall = prevstateno != [710,711]
triggerall = ((helper(20032*(numhelper(20032)>0)),var(10)) = 0)
triggerall = (stateno = 151 || stateno = 153)
triggerall = time <= 5
Trigger1 = enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 40+enemynear(var(58)),vel X*7||P2bodydist x <= 30+enemynear(var(58)),vel X*7
trigger1 = EnemyNear(var(58)),AnimTime <= -10||enemynear(var(58)),HitPauseTime >= 10||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -10
Trigger2 = enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 50+enemynear(var(58)),vel X*8||P2bodydist x <= 40+enemynear(var(58)),vel X*8
trigger2 = EnemyNear(var(58)),AnimTime <= -11||enemynear(var(58)),HitPauseTime >= 11||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -11
Trigger3 = enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 60+enemynear(var(58)),vel X*9||P2bodydist x <= 40+enemynear(var(58)),vel X*9
trigger3 = EnemyNear(var(58)),AnimTime <= -12||enemynear(var(58)),HitPauseTime >= 12||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -12
Trigger4= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 70+enemynear(var(58)),vel X*10||P2bodydist x <= 50+enemynear(var(58)),vel X*10
trigger4 = EnemyNear(var(58)),AnimTime <= -13||enemynear(var(58)),HitPauseTime >= 13||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -13
Trigger5= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 80+enemynear(var(58)),vel X*11||P2bodydist x <= 60+enemynear(var(58)),vel X*11
trigger5 = EnemyNear(var(58)),AnimTime <= -14||enemynear(var(58)),HitPauseTime >= 14||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -14
Trigger6= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 90+enemynear(var(58)),vel X*12||P2bodydist x <= 70+enemynear(var(58)),vel X*12
trigger6 = EnemyNear(var(58)),AnimTime <= -15||enemynear(var(58)),HitPauseTime >= 15||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -15
Trigger7= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 100+enemynear(var(58)),vel X*13||P2bodydist x <= 80+enemynear(var(58)),vel X*13
trigger7 = EnemyNear(var(58)),AnimTime <= -16||enemynear(var(58)),HitPauseTime >= 16||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -16
Trigger8= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 110+enemynear(var(58)),vel X*14||P2bodydist x <= 90+enemynear(var(58)),vel X*14
trigger8 = EnemyNear(var(58)),AnimTime <= -17||enemynear(var(58)),HitPauseTime >= 17||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -17

[State -1,ガーキャンタンデム]
type = ChangeState
value = 3500
triggerall = var(59) = 4
triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = var(45) = 0
triggerall = var(39) = 0
triggerall = !numhelper(3509)
triggerall = power >= 1000
triggerall = life<=lifemax/2||var(59)=4
triggerall = !var(8) || var(0)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = InGuarddist
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),facing != facing
Triggerall = enemynear(var(58)),Vel X >= 0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Movetype = A
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = P2dist X+enemynear(var(58)),vel X*-9 > 0
Triggerall = stateno = 700 && var(0) && (var(6)&1048576)
trigger1 = enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 40+enemynear(var(58)),vel X*6||P2bodydist x <= 30+enemynear(var(58)),vel X*6
trigger1 = EnemyNear(var(58)),AnimTime <= -9||enemynear(var(58)),HitPauseTime >= 9||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -9
Trigger2 = enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 50+enemynear(var(58)),vel X*7||P2bodydist x <= 40+enemynear(var(58)),vel X*7
trigger2 = EnemyNear(var(58)),AnimTime <= -10||enemynear(var(58)),HitPauseTime >= 10||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -10
Trigger3 = enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 60+enemynear(var(58)),vel X*8||P2bodydist x <= 40+enemynear(var(58)),vel X*8
trigger3 = EnemyNear(var(58)),AnimTime <= -11||enemynear(var(58)),HitPauseTime >= 11||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -11
Trigger4= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 70+enemynear(var(58)),vel X*9||P2bodydist x <= 50+enemynear(var(58)),vel X*9
trigger4 = EnemyNear(var(58)),AnimTime <= -12||enemynear(var(58)),HitPauseTime >= 12||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -12
Trigger5= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 80+enemynear(var(58)),vel X*10||P2bodydist x <= 60+enemynear(var(58)),vel X*10
trigger5 = EnemyNear(var(58)),AnimTime <= -13||enemynear(var(58)),HitPauseTime >= 13||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -13
Trigger6= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 90+enemynear(var(58)),vel X*11||P2bodydist x <= 70+enemynear(var(58)),vel X*11
trigger6 = EnemyNear(var(58)),AnimTime <= -14||enemynear(var(58)),HitPauseTime >= 14||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -14
Trigger7= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 100+enemynear(var(58)),vel X*12||P2bodydist x <= 80+enemynear(var(58)),vel X*12
trigger7 = EnemyNear(var(58)),AnimTime <= -15||enemynear(var(58)),HitPauseTime >= 15||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -15
Trigger8= enemynear(var(58)),Statetype = S&&enemynear(var(58)),Const(size.head.pos.y) <= -45&&P2bodydist x <= 110+enemynear(var(58)),vel X*13||P2bodydist x <= 90+enemynear(var(58)),vel X*13
trigger8 = EnemyNear(var(58)),AnimTime <= -16||enemynear(var(58)),HitPauseTime >= 16||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -16


[State -1, ジャンプ・↑]
type = ChangeState
value = 44
triggerall = var(59) = [3,4]
triggerall = (var(57) = [1,2])
triggerall = (var(45)!=[1,2])&&var(45)!=4
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),hitdefAttr=SCA,AT||(var(57) =2)&&EnemyNear(var(58)),stateno = [800,810]
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = EnemyNear(var(58)),facing!=facing
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Movetype = A
triggerall = P2dist X > 0
Triggerall = Random <= 60
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))||stateno=[10900,10901]
trigger1 = P2bodydist X <= ifelse((!var(0)),40,38)
trigger1 = var(6) := 16

[State -1, ジャンプ・前]
type = ChangeState
value = 42
triggerall = var(59) = [3,4]
triggerall = (var(57) = [1,2])
triggerall = var(49) = 1
triggerall = (var(45)!=[1,2])&&var(45)!=4
triggerall = !var(8)
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),hitdefAttr=SCA,AT||(var(57) =2)&&EnemyNear(var(58)),stateno = [800,810]
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = EnemyNear(var(58)),facing!=facing
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Movetype = A
triggerall = P2dist X > 0
Triggerall = Random <= 60
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))||stateno=[10900,10901]
trigger1 = P2bodydist X >= ifelse((!var(0)),40,38)
trigger1 = var(6) := 16

[State -1, 回り込み]
type = ChangeState
value = 300
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45)!=[1,2])&&var(45)!=4
triggerall = !var(0)
triggerall = !var(56)
triggerall = !var(8)
triggerall = statetype != A
Triggerall = !(EnemyNear(var(58)),hitdefAttr=SCA,AT)&&EnemyNear(var(58)),stateno != [800,810]
triggerall = inguarddist
Triggerall = EnemyNear(var(58)),facing!=facing
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
triggerall = P2dist X > 0
Triggerall = Random <= 30
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X = [140,180]
Trigger1 = enemynear(var(58)),Movetype = A
Trigger1 = enemynear(var(58)),Animtime <= -20
trigger2 = P2bodydist X < 140
Trigger2 = enemynear(var(58)),Movetype = A
Trigger2 = enemynear(var(58)),Animtime <= -43
trigger3 = P2bodydist X != [31,120]
Trigger3 = enemynear(var(58)),Movetype != A
trigger4 = P2bodydist X > 180
Trigger4 = enemynear(var(58)),Movetype = A


[State -1, 回り込み]
type = ChangeState
value = 300
triggerall = var(59) = [3,4]
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (var(45)!=[1,2])&&var(45)!=4
triggerall = !var(0)
triggerall = !var(56)
triggerall = !var(8)
triggerall = statetype != A
Triggerall = !(EnemyNear(var(58)),hitdefAttr=SCA,AT)&&EnemyNear(var(58)),stateno != [800,810]
triggerall = inguarddist
Triggerall = EnemyNear(var(58)),facing!=facing
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
triggerall = P2dist X > 0
Triggerall = Random <= 60
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X >= 140
Trigger1 = EnemyNear(var(58)),Vel X >= 0
Trigger1 = enemynear(var(58)),Movetype = A
Trigger1 = P2Dist Y + (enemynear(var(58)),Vel y*30)+(enemynear(var(58)),Const(Movement.Yaccel) *((30*(30-1)))/2) <= -1
trigger2 = P2bodydist X >= 140
Trigger2 = EnemyNear(var(58)),Vel X < 0
Trigger2 = enemynear(var(58)),Movetype = A
trigger3 = P2bodydist X < 140
Trigger3 = P2Dist Y + (enemynear(var(58)),Vel y*30)+(enemynear(var(58)),Const(Movement.Yaccel) *((30*(30-1)))/2) <= -1
Trigger3 = enemynear(var(58)),Movetype = A
trigger4 = P2bodydist X <= 31
Trigger4 = P2Dist Y + (enemynear(var(58)),Vel y*30)+(enemynear(var(58)),Const(Movement.Yaccel) *((30*(30-1)))/2) <= -1
Trigger4 = enemynear(var(58)),Movetype != A
trigger5 = P2bodydist X >= 120
Trigger5 = EnemyNear(var(58)),Vel X >= 0
Trigger5 = P2Dist Y + (enemynear(var(58)),Vel y*30)+(enemynear(var(58)),Const(Movement.Yaccel) *((30*(30-1)))/2) <= -1
Trigger5 = enemynear(var(58)),Movetype != A
trigger6 = P2bodydist X >= 120
Trigger6 = EnemyNear(var(58)),Vel X < 0
Trigger6 = enemynear(var(58)),Movetype != A

;===========================================================================
; 差し込み
;===========================================================================

[State -1,ジャンプ・前]
type = ChangeState
value = 42
Triggerall = var(59) = [3,4]
Triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = var(41) = [0,5]
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype != A
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = enemynear(var(58)),facing != facing
triggerall = EnemyNear(var(58)),Vel X >= 0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
triggerall = EnemyNear(var(58)),AnimTime <= -28
Triggerall = EnemyNear(var(58)),MoveType = A
Triggerall = ifelse((P2dist X>0),floor(P2dist X),ceil(P2dist X)) > 0
Triggerall = Random <= 50
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = !var(0)
trigger1 = P2bodydist X = [70,160]
trigger1 = var(6) := 0||1
trigger2 = var(0)
trigger2 = P2bodydist X = [70,150]
trigger2 = var(6) := 0||1


[State -1,ダッシュ]
type = ChangeState
value = 100
Triggerall = var(59) = [3,4]
Triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = var(41) = [1,9]
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype != A
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = enemynear(var(58)),facing != facing
triggerall = EnemyNear(var(58)),Vel X >= 0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
triggerall = EnemyNear(var(58)),AnimTime <= -29
Triggerall = EnemyNear(var(58)),MoveType = A
Triggerall = ifelse((P2dist X>0),floor(P2dist X),ceil(P2dist X)) > 0
Triggerall = Random <= 50
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = !var(0)
trigger1 = P2bodydist X = [150,200]
trigger1 = var(6) := 0||1
trigger1 = var(41):=var(41)*-1
trigger2 = var(0)
trigger2 = P2bodydist X = [70,190]
trigger2 = var(6) := 0||1
trigger2 = var(41):=var(41)*-1

[State -1,しゃがみ強攻撃]
type = ChangeState
value = 420
Triggerall = var(59) = [3,4]
Triggerall = var(57) = [1,2]
triggerall = var(39) = 0
triggerall = var(49) = 1
triggerall = var(41) = [0,5]
triggerall = !var(0) 
triggerall = !var(8)
triggerall = !var(13)
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype != A
Triggerall = enemynear(var(58)),facing != facing
triggerall = EnemyNear(var(58)),Vel X >= 0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = EnemyNear(var(58)),MoveType = A
Triggerall = ifelse((P2dist X>0),floor(P2dist X),ceil(P2dist X)) > 0
Triggerall = Random <= 30
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X >= 70
trigger1 = P2bodydist X <= 100+enemynear(var(58)),Vel X*5
trigger1 = var(39) := 3

[State -1,S立ち中攻撃]
type = ChangeState
value = 10210
Triggerall = var(59) = [3,4]
Triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = var(41) = [0,5]
triggerall = var(0) 
triggerall = !var(8)
triggerall = !var(13)
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype != A
triggerall = enemynear(var(58)),numproj = 0
Triggerall = enemynear(var(58)),facing != facing
triggerall = EnemyNear(var(58)),Vel X >= 0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = EnemyNear(var(58)),MoveType = A
Triggerall = ifelse((P2dist X>0),floor(P2dist X),ceil(P2dist X)) > 0
Triggerall = Random <= 30
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = P2bodydist X >= 80
trigger1 = P2bodydist X >= 80+((fvar(10)-1)/0.02*1.35)+enemynear(var(58)),Vel X*5
trigger1 = P2bodydist X <= 123+((fvar(10)-1)/0.02*1.35)+enemynear(var(58)),Vel X*5
trigger1 = var(39) := 3

[State -1,S立ち強攻撃]
type = ChangeState
value = 10220
Triggerall = var(59) = [3,4]
Triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = var(41) = [0,5]
triggerall = var(0) 
triggerall = !var(8)
triggerall = !var(13)
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype != A
triggerall = enemynear(var(58)),numproj = 0
Triggerall = enemynear(var(58)),facing != facing
triggerall = EnemyNear(var(58)),Vel X >= 0
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = EnemyNear(var(58)),MoveType = A
Triggerall = ifelse((P2dist X>0),floor(P2dist X),ceil(P2dist X)) > 0
Triggerall = Random <= 30
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = P2bodydist X >= 80
trigger1 = P2bodydist X >= 80+((fvar(10)-1)/0.02*1.35)+enemynear(var(58)),Vel X*7
trigger1 = P2bodydist X <= 145+((fvar(10)-1)/0.02*1.35)+enemynear(var(58)),Vel X*7
trigger1 = var(39) := 3

;===========================================================================
; ガード
;===========================================================================

[State -1,ガード]
Type = ChangeState
Value = 120
TriggerAll = var(59) > 1
TriggerAll = stateNo !=[120,159]
triggerall = RoundState = 2
TriggerAll = Ctrl || (stateno=[20,22])||stateno=5900||stateno=[10900,10901]
Triggerall = (var(59)=[3,4])||random <= var(59)*50||stateno=22
trigger1 = var(57) != [1,2]
Trigger1 = InGuarddist
trigger2 = var(57) != [1,2]
trigger2 = numhelper(21474)
trigger2 = helper(21474),InGuarddist
trigger3 = var(57) = [1,2]
trigger3 = !var(13)
Trigger3 = InGuarddist
trigger4 = var(57) = [1,2]
trigger4 = !var(13)
trigger4 = numhelper(21474)
trigger4 = helper(21474),InGuarddist

[State -1, ガードキャンセル]
type = ChangeState
value = 700
triggerall = var(59) > 0
triggerall = (var(57)=[1,2])&&!var(13)||(var(57)!=[1,2])
triggerall =!(EnemyNear(var(58)),hitdefattr= SCA,HA,HP,HT)
triggerall = ((helper(20032*(numhelper(20032)>0)),var(10)) = 0)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = EnemyNear(var(58)),facing != facing
Triggerall = EnemyNear(var(58)),MoveType != H
triggerall = EnemyNear(var(58)),stateType != L
Triggerall = EnemyNear(var(58)),stateno != [120,159]
triggerall = prevstateno != [710,711]
triggerall = P2dist X > 0 
triggerall = (stateno = 151 || stateno = 153)
triggerall = time <= 5
triggerall =enemynear(var(58)),HitPauseTime>0&&P2bodydist X <= 56||enemynear(var(58)),HitPauseTime<=0&&P2bodydist X <= 56+EnemyNear(var(58)),vel X*10
Triggerall = Random <= var(59)*10||EnemyNear(var(58)),stateType = A&&Random <= var(59)*20||EnemyNear(var(58)),life<=100&&Random <= var(59)*20
trigger1 = EnemyNear(var(58)),stateType != A
trigger1 = EnemyNear(var(58)),AnimTime <= -10||enemynear(var(58)),HitPauseTime >= 10||-(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -10
Trigger2 = enemynear(var(58)),statetype = A
Trigger2 = P2dist X > 0
trigger2 = P2Dist Y + (enemynear(var(58)),Vel y*(10-enemynear(var(58)),HitPauseTime))+(enemynear(var(58)),Const(Movement.Yaccel)*(((10-enemynear(var(58)),HitPauseTime)*((10-enemynear(var(58)),HitPauseTime)-1)))/2)=[-50,10]
Trigger3 = enemynear(var(58)),statetype = A
Trigger3 = enemynear(var(58)),hitpausetime >= 10
trigger3 = P2dist Y + (enemynear(var(58)),Vel y*10)+(enemynear(var(58)),Const(Movement.Yaccel) *((10*(6-1)))/2)=[-50,10]

[State -1, ガードキャンセル]
type = ChangeState
value = 700
triggerall = var(59) = [3,4]
triggerall = numhelper(21474)
triggerall = helper(21474),var(49) = 1
triggerall = ((helper(20032*(numhelper(20032)>0)),var(10)) = 0)
triggerall = !(EnemyNear(var(58)),hitdefattr= SCA,HA,HP,HT)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = EnemyNear(var(58)),facing != facing
Triggerall = EnemyNear(var(58)),MoveType != H
triggerall = EnemyNear(var(58)),stateType != L
Triggerall = EnemyNear(var(58)),stateno != [120,159]
triggerall = prevstateno != [710,711]
triggerall = P2dist X > 0 
triggerall = (stateno = 151 || stateno = 153)
triggerall = time <= 5
triggerall =P2bodydist X > 56
Triggerall = Random <= 60
trigger1 = EnemyNear(var(58)),stateType != A
trigger1 = -(enemynear(var(58)),HitPauseTime)+EnemyNear(var(58)),Animtime <= -10
trigger1 = var(38) := enemynear(var(58)),stateno
Trigger2 = enemynear(var(58)),statetype = A
Trigger2 = P2dist X > 0
trigger2 = P2Dist Y + (enemynear(var(58)),Vel y*(10-enemynear(var(58)),HitPauseTime))+(enemynear(var(58)),Const(Movement.Yaccel)*(((10-enemynear(var(58)),HitPauseTime)*((10-enemynear(var(58)),HitPauseTime)-1)))/2)=[-50,10]
Trigger3 = enemynear(var(58)),statetype = A
Trigger3 = enemynear(var(58)),hitpausetime >= 10
trigger3 = P2dist Y + (enemynear(var(58)),Vel y*10)+(enemynear(var(58)),Const(Movement.Yaccel) *((10*(6-1)))/2)=[-50,10]

[State -1, ガードキャンセル]
type = ChangeState
value = 700
triggerall = var(59) = [1,2]
triggerall = (var(57)=[1,2])&&!var(13)||(var(57)!=[1,2])
triggerall = ((helper(20032*(numhelper(20032)>0)),var(10)) = 0)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = prevstateno != [710,711]
triggerall = EnemyNear(var(58)),stateType != A
triggerall = EnemyNear(var(58)),stateType != L
triggerall = (stateno = 151 || stateno = 153)
triggerall = time <= 5
triggerall =P2bodydist X <= 80
Trigger1 = Random <= (var(59))*7

[State -1, アドバンシングガード]
type = ChangeState
value = 710
triggerall = var(59) > 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = ((helper(20032*(numhelper(20032)>0)),var(10)) = 0)
triggerall = (var(57)=[1,2])&&!var(13)||(var(57)!=[1,2])
triggerall = !(numhelper(715))
triggerall = EnemyNear(var(58)),facing != facing
Triggerall = EnemyNear(var(58)),MoveType != H
triggerall = EnemyNear(var(58)),stateType != L
Triggerall = EnemyNear(var(58)),stateno != [120,159]
triggerall = prevstateno != [710,711]
triggerall = P2dist X > 0 
triggerall =P2bodydist X <= 150||EnemyNear(var(58)),statetype = A&&EnemyNear(var(58)),vel X > 0
triggerall = stateno = [150,153]
triggerall = time > 0
trigger1 = var(45) = 0
Trigger1 = Random <= var(59)*6
trigger2 = (stateno=150||stateno=152) && EnemyNear(var(58)),statetype != A
Trigger2 = Random <= 2
trigger3 = EnemyNear(var(58)),statetype != A
trigger3 = ((stateno=151||stateno=153)&&Time<=GetHitVar(ctrltime))
Trigger3 = Random <= 1
trigger4 = (stateno=150||stateno=152) && EnemyNear(var(58)),statetype = A
Trigger4 = Random <= 6
trigger5 = EnemyNear(var(58)),statetype = A
trigger5 = ((stateno=151||stateno=153)&&Time<=GetHitVar(ctrltime))
Trigger5 = Random <= 6

;===========================================================================
; 立ち回り
;===========================================================================

[state -1, 投げ]
type = changestate
value = 800
Triggerall = var(59) > 0 
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(39) != 1&&var(39) != 4
triggerall = !var(13)
triggerall = !fvar(7)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Movetype != H
triggerall = EnemyNear(var(58)),stateno != [150,156]
triggerall = EnemyNear(var(58)),stateno != [40,42]
triggerall = EnemyNear(var(58)),stateno != [5120,5400]
triggerall = EnemyNear(var(58)),Prevstateno != [5120,5400]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
Triggerall = P2dist X > 0
triggerall = p2bodydist x = [-23,23]
triggerall = p2statetype != A && p2statetype != L && p2movetype != H
triggerall = !((prevstateno = [100,105]) && time < 8)
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = var(57) = 2
trigger1 =FrontEdgeBodyDist <= 140
Trigger1 = BackEdgeBodyDist >= 139
Trigger1 = Random<=var(59)*60
trigger1 = var(46) :=1
trigger1 = var(39) := 4

Trigger2 = var(57) = 2
Trigger2 = BackEdgeBodyDist <= 140
Trigger2 = FrontEdgeBodyDist >= 139
Trigger2 = Random<=var(59)*60
trigger2 = var(46) :=2
trigger2 = var(39) := 4
Trigger3 = var(57) != 2
Trigger3 = Random<=var(59)*ifelse((enemynear(var(58)),stateno != [120,131]),50,70)
trigger3 = var(46) :=1
trigger3 = var(39) := 4
Trigger4 = var(57) != 2
Trigger4 = Random<=var(59)*ifelse((enemynear(var(58)),stateno != [120,131]),50,70)
trigger4 = var(46) :=2
trigger4 = var(39) := 4

[State -1, ガキ近立ち中通常]
type = ChangeState
value = 265
triggerall = var(59) > 0
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [-5,40])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [-5,30])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = !InGuarddist
trigger1 = Random <= var(59)*30
trigger2 = InGuarddist
trigger2 = Random <= 50

[State -1, ガキしゃがみ弱通常]
type = ChangeState
value = 450
triggerall = var(59) > 0
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [-5,40])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [-5,30])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = !InGuarddist
trigger1 = Random <= var(59)*30
trigger2 = InGuarddist
trigger2 = Random <= 50

[State -1, ガキ立ち強通常]
type = ChangeState
value = 270
triggerall = var(59) > 0
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [31,85])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [31,85])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = !InGuarddist
trigger1 = Random <= var(59)*30

[State -1, 立ち中通常]
type = ChangeState
value = 210
triggerall = var(59) > 0
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))||((stateno = 100 || stateno = 105) && time > 1 && (var(59)!=[3,4])&&!var(0))
trigger1 = !InGuarddist
trigger1 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [-5,20])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [-5,10])
trigger1 = Random <= var(59)*ifelse((enemynear(var(58)),Stateno!=[150,155]),50,70)
trigger1 = var(39) := 3
trigger2 = !InGuarddist
trigger2 = ((stateno = 100 || stateno = 105) && time > 1 && (var(59)!=[3,4])&&!var(0))
trigger2 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [-5,50])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [-5,40])
trigger2 = Random <= var(59)*50
trigger2 = var(39) := 3

[State -1, 立ち強通常]
type = ChangeState
value = 220
triggerall = var(59) > 0
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = S
Triggerall = enemynear(var(58)),Const(size.head.pos.y) <= -45
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))||((stateno = 100 || stateno = 105) && time > 1 && (var(59)!=[3,4])&&!var(0))
trigger1 = !var(0)
trigger1 = !InGuarddist
trigger1 = enemynear(var(58)),Stateno != [120,155]
trigger1 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x <= 45)||EnemyNear(var(58)),facing=facing&&(p2bodydist x <= 35)
trigger1 = Random <= var(59)*30
trigger1 = var(39) := 3
trigger2 = !var(0)
trigger2 = InGuarddist
trigger2 =enemynear(var(58)),Stateno != [120,155]
Trigger2 = enemynear(var(58)),Movetype != A||enemynear(var(58)),Movetype = A&&enemynear(var(58)),HitPauseTime>0
Trigger2 = !(Enemynear(var(58)),hitdefattr =SCA,HA,HP,HT)
trigger2 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x <= 45)||EnemyNear(var(58)),facing=facing&&(p2bodydist x <= 35)
trigger2 = Random <= var(59)*10
trigger2 = var(39) := 3
trigger3 = !var(0)
trigger3 = InGuarddist
trigger3 = enemynear(var(58)),HitPauseTime<=0
Trigger3 = enemynear(var(58)),Movetype = A
trigger3 = !(Enemynear(var(58)),hitdefattr =SCA,HA,HP,HT)
trigger3 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x <= 45+Enemynear(var(58)),Vel X*3)||EnemyNear(var(58)),facing=facing&&(p2bodydist x <= 35+Enemynear(var(58)),Vel X*-3)
trigger3 = Random <= var(59)*10
trigger3 = var(39) := 3
trigger4 = !var(0)
trigger4 = !InGuarddist
trigger4= EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [-5,40])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [-5,30])
trigger4 = Random <= var(59)*ifelse((enemynear(var(58)),Stateno != [120,155]),30,15)
trigger4 = var(39) := 3
trigger5 = var(0)
trigger5 = InGuarddist
Trigger5 = enemynear(var(58)),Movetype != A||enemynear(var(58)),Movetype = A&&enemynear(var(58)),HitPauseTime>0
Trigger5 = !(Enemynear(var(58)),hitdefattr =SCA,HA,HP,HT)
trigger5 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [-5,40])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [-5,30])
trigger5 = Random <= var(59)*10
trigger5 = var(39) := 3
trigger6 = var(0)
trigger6 = InGuarddist
Trigger6 = enemynear(var(58)),Movetype = A
trigger6 = enemynear(var(58)),HitPauseTime<=0
trigger6 = !(Enemynear(var(58)),hitdefattr =SCA,HA,HP,HT)
trigger6 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [-5,40])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [-5,30])
trigger6 = Random <= var(59)*10
trigger6 = var(39) := 3
trigger7 = !InGuarddist
trigger7 = ((stateno = 100 || stateno = 105) && time > 1 && (var(59)!=[3,4])&&!var(0))
trigger7 = P2bodydist X + (Vel x*-8)+(Const(Movement.stand.friction) *((8*(8-1)))/2) <= 45
trigger7 = Random <= var(59)*50
trigger7 = var(39) := 3

[State -1, しゃがみ中通常]
type = ChangeState
value = 410
triggerall = var(59) > 0
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))||((stateno = 100 || stateno = 105) && time > 1 && (var(59)!=[3,4])&&!var(0))
trigger1 = !var(0)
trigger1 = !InGuarddist
trigger1 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x <= 37)||EnemyNear(var(58)),facing=facing&&(p2bodydist x <= 27)
trigger1 = Random <= var(59)*30
trigger1 = var(39) := 3
trigger2 = !var(0)
trigger2 = InGuarddist
Trigger2 = enemynear(var(58)),Movetype != A||enemynear(var(58)),Movetype = A&&enemynear(var(58)),HitPauseTime>0&&(enemynear(var(58)),Statetype = C||!(enemynear(var(58)),Const(size.head.pos.y) <= -45))
Trigger2 = !(Enemynear(var(58)),hitdefattr =SCA,HA,HP,HT)
trigger2 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x <= 37)||EnemyNear(var(58)),facing=facing&&(p2bodydist x <= 27)
trigger2 = Random <= var(59)*10
trigger2 = var(39) := 3
trigger3 = !var(0)
trigger3 = InGuarddist
Trigger3 = enemynear(var(58)),Statetype = C||!(enemynear(var(58)),Const(size.head.pos.y) <= -45)
trigger3 = enemynear(var(58)),HitPauseTime<=0
Trigger3 = enemynear(var(58)),Movetype = A
trigger3 = !(Enemynear(var(58)),hitdefattr =SCA,HA,HP,HT)
trigger3 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x <= 37+Enemynear(var(58)),Vel X*4)||EnemyNear(var(58)),facing=facing&&(p2bodydist x <= 27+Enemynear(var(58)),Vel X*-4)
trigger3 = Random <= var(59)*10
trigger3 = var(39) := 3
trigger4 = var(59) = [3,4]
trigger4 = var(57) = [0,1]
trigger4 = !var(0)
trigger4 = !InGuardDist
Trigger4 = enemynear(var(58)),Statetype = S
Trigger4 = (enemynear(var(58)),stateno=[120,151])
trigger4 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x <= 37)||EnemyNear(var(58)),facing=facing&&(p2bodydist x <= 27)
trigger4 = Random <= 450
trigger4 = var(39) := 3
trigger5 = var(0)
trigger5 = !InGuarddist
trigger5= EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [-5,40])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [-5,30])
trigger5 = Random <= var(59)*30
trigger5 = var(39) := 3
trigger6 = var(0)
trigger6 = InGuarddist
Trigger6 = enemynear(var(58)),Statetype = C||!(enemynear(var(58)),Const(size.head.pos.y) <= -45)
Trigger6 = enemynear(var(58)),Movetype != A||enemynear(var(58)),Movetype = A&&enemynear(var(58)),HitPauseTime>0&&(enemynear(var(58)),Statetype = C||!(enemynear(var(58)),Const(size.head.pos.y) <= -45))
Trigger6 = !(Enemynear(var(58)),hitdefattr =SCA,HA,HP,HT)
trigger6 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [-5,40])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [-5,30])
trigger6 = Random <= var(59)*10
trigger6 = var(39) := 3
trigger7 = var(0)
trigger7 = InGuarddist
Trigger7 = enemynear(var(58)),Movetype = A
trigger7 = enemynear(var(58)),HitPauseTime<=0
Trigger7 = enemynear(var(58)),Statetype = C||!(enemynear(var(58)),Const(size.head.pos.y) <= -45)
trigger7 = !(Enemynear(var(58)),hitdefattr =SCA,HA,HP,HT)
trigger7 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [-5,40])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [-5,30])
trigger7 = Random <= var(59)*10
trigger7 = var(39) := 3
trigger8 = var(59) = [3,4]
trigger8= var(57) = [0,1]
trigger8 = var(0)
trigger8 = !InGuardDist
Trigger8 = enemynear(var(58)),Statetype = S
Trigger8 = (enemynear(var(58)),stateno=[120,151])
trigger8 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [-5,40])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [-5,30])
trigger8 = Random <= 450
trigger8 = var(39) := 3
trigger9 = !InGuarddist
trigger9 = ((stateno = 100 || stateno = 105) && time > 1 && (var(59)!=[3,4])&&!var(0))
trigger9 = P2bodydist X + (Vel x*-4)+(Const(Movement.crouch.friction) *((4*(4-1)))/2) <= 37
trigger9 = Random <= var(59)*50
trigger9 = var(39) := 3

[State -1, しゃがみ弱通常]
type = ChangeState
value = 400
triggerall = var(59) > 0
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = !var(8)
triggerall = !var(13)
triggerall = !InGuarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [-5,38])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [-5,28])
trigger1 = Random <= var(59)*30
trigger1 = var(39) := 3

[State -1, しゃがみ強通常]
type = ChangeState
value = 420
triggerall = var(59) > 0
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !InGuarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),Stateno != [5000,5050]
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
Triggerall = enemynear(var(58)),Stateno != [40,45]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [35,100])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [25,90])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = Random <= var(59)*ifelse((enemynear(var(58)),Stateno != [120,155]),20,10)
trigger1 = var(39) := 3
trigger2 = var(59) = [3,4]
trigger2 = var(57) = [0,1]
Trigger2 = enemynear(var(58)),Statetype = S
Trigger2 = (enemynear(var(58)),stateno=[120,151])
trigger2 = Random <= 450
trigger2 = var(39) := 3

[State -1, 立ち弱通常]
type = ChangeState
value = 200
triggerall = var(59) = [1,2]
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !var(13)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [-5,30])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [-5,20])
trigger1 = Random <= var(59)*ifelse((!Inguarddist),30,10)

[State -1, Sしゃがみ弱]
type = ChangeState
value = 10400
triggerall = var(59) > 0
triggerall = var(57)= 2&&enemynear(var(58)),Stateno < 200000||var(57)!= 2
triggerall = var(39) = 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = numhelper(10010)
triggerall = !Inguarddist&&!(helper(10010),Inguarddist)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno != [200060,200064]
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = (p2bodydist x != [-5,40])
triggerall = P2bodydist X >= 5+((fvar(10)-1)/0.02*1.35)
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 61+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 51+((fvar(10)-1)/0.02*1.35))
trigger1 = Random <= var(59)*30
trigger1 = var(39) := 3
trigger2 = var(59) = [3,4]
trigger2 = var(57) = [0,1]
trigger2 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 61+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 51+((fvar(10)-1)/0.02*1.35))
Trigger2 = enemynear(var(58)),Statetype = S
Trigger2 = (enemynear(var(58)),stateno=[120,151])
trigger2 = Random <= 450
trigger2 = var(39) := 3

[State -1, S立ち弱]
type = ChangeState
value = 10200
triggerall = var(59) > 0
triggerall = var(39) = 0
triggerall = var(57)= 2&&enemynear(var(58)),Stateno < 200000||var(57)!= 2
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),Stateno != [200060,200064]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = (p2bodydist x != [-5,30])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = !InGuarddist
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X >= 31+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X >= 31+((fvar(10)-1)/0.02*1.35))
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 97+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 87+((fvar(10)-1)/0.02*1.35))
trigger1 = Random <= var(59)*30
trigger1 = var(39) := 3
trigger2 = InGuarddist
Trigger2 = enemynear(var(58)),Movetype != A||enemynear(var(58)),Movetype = A&&enemynear(var(58)),HitPauseTime>0
Trigger2 = !(Enemynear(var(58)),hitdefattr =SCA,HA,HP,HT)
trigger2 = (EnemyNear(var(58)),facing != facing&&P2bodydist X >= 31+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing =facing&&P2bodydist X >= 31+((fvar(10)-1)/0.02*1.35))
trigger2 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 97+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 87+((fvar(10)-1)/0.02*1.35))
trigger2 = Random <= var(59)*10
trigger2 = var(39) := 3
trigger3 = InGuarddist
trigger3 = enemynear(var(58)),HitPauseTime<=0
Trigger3 = enemynear(var(58)),Movetype = A
trigger3 = !(Enemynear(var(58)),hitdefattr =SCA,HA,HP,HT)
trigger3 = (EnemyNear(var(58)),facing != facing&&P2bodydist X >= 31+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*4)||(EnemyNear(var(58)),facing =facing&&P2bodydist X >= 31+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*-4)
trigger3 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 97+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*4)||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 87+((fvar(10)-1)/0.02*1.35)+EnemyNear(var(58)),Vel X*-4)
trigger3 = Random <= var(59)*10
trigger3 = var(39) := 3

[State -1, S立ち中]
type = ChangeState
value = 10210
triggerall = var(59) > 0
triggerall = var(57)= 2&&enemynear(var(58)),Stateno < 200000||var(57)!= 2
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = var(0)
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno != [200060,200064]
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = (p2bodydist x != [-5,30])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = numhelper(10010)
trigger1 = !Inguarddist&&!(helper(10010),Inguarddist)
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X >= 65+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X >= 55+((fvar(10)-1)/0.02*1.35))
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 123+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 113+((fvar(10)-1)/0.02*1.35))
trigger1 = Random <= var(59)*20
trigger1 = var(39) := 3
trigger2 = var(59) = [1,2]
trigger2 = InGuarddist
Trigger2 = enemynear(var(58)),Movetype = A
trigger2 = (EnemyNear(var(58)),facing != facing&&P2bodydist X >= 65+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X >= 55+((fvar(10)-1)/0.02*1.35))
trigger2 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 123+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 113+((fvar(10)-1)/0.02*1.35))
trigger2 = Random <= 30/var(59)
trigger2 = var(39) := 3

[State -1, S立ち強]
type = ChangeState
value = 10220
triggerall = var(59) > 0
triggerall = var(39) = 0
triggerall = var(57)= 2&&enemynear(var(58)),Stateno < 200000||var(57)!= 2
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno != [200060,200064]
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = (p2bodydist x != [-5,40])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = numhelper(10010)
trigger1 = !Inguarddist&&!(helper(10010),Inguarddist)
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X >= 80+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X >= 70+((fvar(10)-1)/0.02*1.35))
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 145+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 135+((fvar(10)-1)/0.02*1.35))
trigger1 = Random <= var(59)*30
trigger1 = var(39) := 3
trigger2 = var(59) = [1,2]
trigger2 = InGuarddist
Trigger2 = enemynear(var(58)),Movetype = A
trigger2 = (EnemyNear(var(58)),facing != facing&&P2bodydist X >= 80+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X >= 70+((fvar(10)-1)/0.02*1.35))
trigger2 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 145+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 135+((fvar(10)-1)/0.02*1.35))
trigger2 = Random
trigger2 = Random <= 30/var(59)
trigger2 = var(39) := 3

[State -1, S前押し立ち中]
type = ChangeState
value = 10212
triggerall = var(59) > 0
triggerall = var(39) = 0
triggerall = var(57)= 2&&enemynear(var(58)),Stateno < 200000||var(57)!= 2
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno != [200060,200064]
Triggerall = enemynear(var(58)),Stateno != [5000,5050]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = numhelper(10010)
triggerall = !Inguarddist&&!(helper(10010),Inguarddist)
triggerall = (p2bodydist x != [-5,40])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = enemynear(var(58)),Stateno != [5120,5400]
Trigger1 = EnemyNear(var(58)),facing!=facing&&(enemynear(var(58)),Vel X =[0,3])||EnemyNear(var(58)),facing=facing&&enemynear(var(58)),Vel X =[-3,0]
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X >= 50+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X >= 40+((fvar(10)-1)/0.02*1.35))
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 110+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 90+((fvar(10)-1)/0.02*1.35))
trigger1 = Random <= var(59)*20
trigger1 = var(39) := 3
Trigger2 = enemynear(var(58)),Stateno = 5120
Trigger2 = enemynear(var(58)),Vel X = [-2,2]
Trigger2 = enemynear(var(58)),Animtime = [-10,-5]
trigger2 = (EnemyNear(var(58)),facing != facing&&P2bodydist X >= 70+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X >= 50+((fvar(10)-1)/0.02*1.35))
trigger2 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 110+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 90+((fvar(10)-1)/0.02*1.35))
trigger2 = Random <= var(59)*30
trigger2 = var(39) := 3
trigger3 = var(59) = [3,4]
trigger3 = var(57) = [0,1]
Trigger3 = enemynear(var(58)),Statetype = C
Trigger3 = (enemynear(var(58)),stateno=[120,155])
trigger3 = (EnemyNear(var(58)),facing != facing&&P2bodydist X >= 60+((fvar(10)-1)/0.02*1.35))||(EnemyNear(var(58)),facing = facing&&P2bodydist X >= 41+((fvar(10)-1)/0.02*1.35))
trigger3 = P2bodydist X <= 90+((fvar(10)-1)/0.02*1.35)
trigger3 = Random <= 200
trigger3 = var(39) := 3

[State -1, Sしゃがみ強]
type = ChangeState
value = 10420
triggerall = var(59) > 0
triggerall = var(57)= 2&&enemynear(var(58)),Stateno < 200000||var(57)!= 2
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = var(0)
triggerall = !var(8)
triggerall = !InGuarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno != [200060,200064]
Triggerall = enemynear(var(58)),Stateno != [5120,5400]
Triggerall = enemynear(var(58)),Stateno != [5000,5050]
Triggerall = enemynear(var(58)),Stateno != [40,45]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = EnemyNear(var(58)),facing!=facing&&(p2bodydist x = [50,100])||EnemyNear(var(58)),facing=facing&&(p2bodydist x = [40,90])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = Random <= var(59)*ifelse((enemynear(var(58)),Stateno != [120,155]),20,10)
trigger1 = var(39) := 3
trigger2 = var(59) = [3,4]
trigger2 = var(57) = [0,1]
Trigger2 = enemynear(var(58)),Statetype = S
Trigger2 = (enemynear(var(58)),stateno=[120,151])
trigger2 = Random <= 450
trigger2 = var(39) := 3

[State -1, Sダッシュ立ち強攻撃]
type = ChangeState
value = 10221
triggerall = var(59) = [3,4]
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !InGuarddist
Triggerall = enemynear(var(58)),statetype != A
Triggerall = enemynear(var(58)),statetype != L
Triggerall = enemynear(var(58)),stateno != [5120,5400]
trigger1 = stateno = 100 && time > 1
trigger1 = var(39) := 3


[State -1, Stand ON]
type = ChangeState
value = 10900
triggerall = var(59) = [3,4]
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = fvar(2) >= 88
triggerall = !InGuarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = random <= 10
Trigger1 = enemynear(var(58)),statetype = A
trigger1 = enemynear(var(58)),Movetype = H
trigger2 = P2bodydist X >= 50
Trigger2 = enemynear(var(58)),statetype != A
Trigger2 = enemynear(var(58)),statetype = L || enemynear(var(58)),Stateno = [5120,5400]
trigger3 = P2bodydist X >= 50
Trigger3 = enemynear(var(58)),statetype != A
Trigger3 = enemynear(var(58)),statetype != L 
trigger3 = enemynear(var(58)),Stateno != [5120,5400]
trigger4 = P2bodydist X >= 80
Trigger4 = enemynear(var(58)),statetype = A
Trigger4 = EnemyNear(var(58)),facing!=facing&&enemynear(var(58)),Vel X <=0||EnemyNear(var(58)),facing=facing&&enemynear(var(58)),Vel X >=0

[State -1, Stand ON]
type = ChangeState
value = 10900
triggerall = var(59) = [1,2]
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = random <= 1

[State -1, Stand OFF]
type = ChangeState
value = 900
triggerall = var(59) = [3,4]
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(48)
triggerall = !InGuarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = stateno != 10900
trigger1 = fvar(2) <= 44
trigger1 = random <= 200
trigger2 = var(59) = 3
trigger2 = fvar(2) > 44
trigger2 = random <= 10

[State -1, Stand OFF]
type = ChangeState
value = 900
triggerall = var(59) = [1,2]
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(48)
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = P2dist X > 0
triggerall = stateno != 10900
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = random <= 1

[State -1, 蜂の巣近]
type = ChangeState
value = 1000
triggerall = var(59) = [3,4]
triggerall = var(57)=2&&EnemyNear(var(58)),life >1||var(57)!=[2,3]
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !InGuarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),stateno != [40,50]
Triggerall = enemynear(var(58)),Anim != 5300
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X = [60,70]
trigger1 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 3)|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X >= 0)
trigger1 = enemynear(var(58)),Statetype != A&&enemynear(var(58)),stateno = 5120
trigger1 = random <= var(59)*10
trigger1 = var(2) := 0||1
trigger2 = P2bodydist X = [60,70]
trigger2 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 3)|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X >= 0)
Trigger2 = enemynear(var(58)),Statetype = L
trigger2 = enemynear(var(58)),stateno = [5100,5110]
trigger2 = random <= var(59)*10
trigger2 = var(2) := 0||1
trigger3 = P2bodydist X = [60,70]
Trigger3 = enemynear(var(58)),Statetype = L
trigger3 = enemynear(var(58)),stateno != [5100,5110]
trigger3 = random <= var(59)*10
trigger3 = var(2) := 0||1
trigger4 = var(59) = [1,2]
Trigger4 = enemynear(var(58)),Statetype != L
Trigger4 = enemynear(var(58)),Statetype != A
Trigger4 = enemynear(var(58)),facing != facing&&enemynear(var(58)),Movetype != A&&enemynear(var(58)),Numproj=0||enemynear(var(58)),facing = facing
trigger4 = P2bodydist X = [30,70]
trigger4 = random <= var(59)*10
trigger4 = var(2) := 0||1

[State -1, 蜂の巣中]
type = ChangeState
value = 1000
triggerall = var(59) = [3,4]
triggerall = var(57)=2&&EnemyNear(var(58)),life >1||var(57)!=[2,3]
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !InGuarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),stateno != [40,50]
Triggerall = enemynear(var(58)),Anim != 5300
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X = [71,120]
trigger1 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 3)|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X >= 0)
trigger1 = enemynear(var(58)),Statetype != A&&enemynear(var(58)),stateno = 5120
trigger1 = random <= var(59)*10
trigger1 = var(2) := 1
trigger2 = P2bodydist X = [71,120]
trigger2 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 3)|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X >= 0)
Trigger2 = enemynear(var(58)),Statetype = L
trigger2 = enemynear(var(58)),stateno = [5100,5110]
trigger2 = random <= var(59)*10
trigger2 = var(2) := 1
trigger3 = P2bodydist X = [71,120]
trigger3 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 3)|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X >= 0)
Trigger3 = enemynear(var(58)),Statetype = L
trigger3 = enemynear(var(58)),stateno != [5100,5110]
trigger3 = random <= var(59)*10
trigger3 = var(2) := 1
trigger4 = var(57) !=[2,3]
Trigger4 = enemynear(var(58)),Statetype != A
Trigger4 = enemynear(var(58)),Statetype != L
Trigger4 = enemynear(var(58)),facing != facing&&enemynear(var(58)),Movetype = H&&enemynear(var(58)),Numproj=0||enemynear(var(58)),facing = facing
trigger4 = enemynear(var(58)),stateno != [5120,5400]
trigger4 = P2bodydist X = [80,120]
trigger4 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 3)|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X >= 0)
trigger4 = random <= 40
trigger4 = var(2) := 1
trigger5 = var(59) = [1,2]
Trigger5 = enemynear(var(58)),Statetype != A
Trigger5 = enemynear(var(58)),Statetype != L
trigger5 = enemynear(var(58)),stateno != [5120,5400]
trigger5 = P2bodydist X = [80,120]
trigger5 = random <= var(59)*10
trigger5 = var(2) := 1

[State -1, 蜂の巣遠]
type = ChangeState
value = 1000
triggerall = var(59) = [3,4]
triggerall =var(57)=2&&EnemyNear(var(58)),life >1||var(57)!=[2,3]
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !InGuarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),stateno != [40,50]
Triggerall = enemynear(var(58)),Anim != 5300
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X = [121,250]
trigger1 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 3)|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X >= 0)
trigger1 = enemynear(var(58)),Statetype != A&&enemynear(var(58)),stateno = 5120
trigger1 = random <= var(59)*10
trigger1 = var(2) := 2
trigger2 = P2bodydist X = [121,250]
trigger2 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 3)|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X >= 0)
Trigger2 = enemynear(var(58)),Statetype = L
trigger2 = enemynear(var(58)),stateno = [5100,5110]
trigger2 = random <= var(59)*10
trigger2 = var(2) := 2
trigger3 = P2bodydist X = [121,250]
trigger3 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 3)|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X >= 0)
Trigger3 = enemynear(var(58)),Statetype = L
trigger3 = enemynear(var(58)),stateno != [5100,5110]
trigger3 = random <= var(59)*10
trigger3 = var(2) := 2
Trigger4 = enemynear(var(58)),Statetype != A
Trigger4 = enemynear(var(58)),Statetype != L
Trigger4 = enemynear(var(58)),facing != facing&&enemynear(var(58)),Movetype != A&&enemynear(var(58)),Numproj=0||enemynear(var(58)),facing = facing
trigger4 = enemynear(var(58)),stateno != [5120,5400]
trigger4 = (var(57)=[2,3])&&(P2bodydist X =[150,250])|| (var(57)!=[2,3])&&(P2bodydist X =[120,250])
trigger4 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 2)|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X >= 0)
trigger4 = random <= ifelse((var(57)=[2,3]),30,80)
trigger4 = var(2) := 2
trigger5 = var(59) = [1,2]
Trigger5 = enemynear(var(58)),Statetype != A
Trigger5 = enemynear(var(58)),Statetype != L
trigger5 = enemynear(var(58)),stateno != [5120,5400]
trigger5 = P2bodydist X = [121,250]
trigger5 = random <= var(59)*10
trigger5 = var(2) := 2


[State -1,  絶望ォォォだねッ！]
type = ChangeState
value = 3000
triggerall = var(59) = [1,2]
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !var(13)
triggerall = Power >= 1000
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = enemynear(var(58)),stateno != [5120,5400]
triggerall = P2dist X > 0
trigger1 = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X <= 50
Trigger1 = Random <= 5

[State -1, ウシウシウシッ！]
type = ChangeState
value = ifelse((!var(0)),3100,3200)
triggerall = var(59) = [1,2]
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !var(13)
triggerall = Power >= 1000
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = enemynear(var(58)),stateno != [5120,5400]
triggerall = P2dist X > 0
trigger1 = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X <= 62
Trigger1 = Random <= 5

[State -1, ガキンチョがッ！]
type = ChangeState
value = 1100
triggerall = var(59) = [1,2]
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !InGuarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = P2dist X > 0
triggerall = P2bodydist X <= 124
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = enemynear(var(58)),stateno = [5100,5120]
trigger1 = random <= 20
trigger2 = enemynear(var(58)),stateno != [5100,5120]
trigger2 = random <= 1

[State -1, Sガキンチョがッ！]
type = ChangeState
value = 11100
triggerall = (var(59) > 0)
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = !InGuarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = (var(59) = [1,2])
trigger1 = P2bodydist X = [25,60]
trigger1 = enemynear(var(58)),stateno = 5120&&enemynear(var(58)),Animtime >= -15
trigger1 = random <= 20
trigger2 = (var(59) = [1,2])
trigger2 = P2bodydist X = [25,60]
trigger2 = enemynear(var(58)),stateno != [5100,5120]
trigger2 = random <= 1
trigger3 = (var(59) = [3,4])&&(var(57)=[0,1])&&enemynear(var(58)),facing=facing
trigger3 = p2bodydist x >= 15+enemynear(var(58)),vel X*(-15+enemynear(var(58)),HitPauseTime)
trigger3 = p2bodydist x <= 60+enemynear(var(58)),vel X*(-15+enemynear(var(58)),HitPauseTime)
trigger3 = enemynear(var(58)),Movetype = A
trigger3 = random <= 120

[State -1,挑発]
type = ChangeState
value = 195
triggerall = var(59) > 0
triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = numhelper(21474)
triggerall = !InGuarddist&& !(helper(21474),InGuarddist)
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),Anim != 5300
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = P2dist X > 0
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = var(59) = 3
trigger1 = var(57) = 2
trigger1 = numpartner = 0
trigger1 = P2bodydist X >= 170
trigger1 = life >= lifemax / 2
trigger1 = enemynear(var(58)),numproj = 0
trigger1 = enemynear(var(58)),life <= enemynear(var(58)),lifemax / 3
trigger1 = enemynear(var(58)),life <= lifemax / 3
trigger1 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 2)|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X >= 2)
Trigger1 = enemynear(var(58)),Movetype != A
trigger1 = RAndom <= 10
trigger2 = var(59) = 2
trigger2 = P2bodydist X >= 150||enemynear(var(58)),statetype = L
trigger2 = RAndom <= 1
trigger3 = var(59) = 1
trigger3 = RAndom <= 10

[state -1, ガキンチョがッ！]
type = changestate
value = 1100
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = alive
triggerall = !Inguarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
triggerall = (enemynear(var(58)),stateno!=[5120,5400])&&enemynear(var(58)),Vel Y != 0||(enemynear(var(58)),stateno=5210&&!(enemynear(var(58)),ctrl=0))&&enemynear(var(58)),Vel Y != 0||enemynear(var(58)),stateno=5201
triggerall =  (P2Dist Y + (enemynear(var(58)),Vel y*24)+(enemynear(var(58)),GetHitVar(Yaccel) *((24*(24-1)))/2) =[-80,5]) || (P2Dist Y + (enemynear(var(58)),Vel y*27)+(enemynear(var(58)),GetHitVar(Yaccel) *((27*(27-1)))/2) =[-20,5])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1 = enemynear(var(58)),facing = facing
trigger1 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger1 = P2bodydist X <= 30+enemynear(var(58)),Vel x*-24||P2bodydist X <= 70+enemynear(var(58)),Vel x*-27
trigger2 = enemynear(var(58)),facing = facing
trigger2 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger2 = var(57) = 2 && (((floor(helper(21000),RootDist X) <=120) && facing = 1)||((floor(helper(25000),RootDist X) <= 120) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist <= 100
trigger3 = enemynear(var(58)),facing != facing
trigger3 = enemynear(var(58)),stateno=5210&&(!enemynear(var(58)),ctrl=0)&&enemynear(var(58)),Vel Y != 0||enemynear(var(58)),stateno=5201
trigger3 = P2bodydist X <= 40+enemynear(var(58)),Vel x*24||P2bodydist X <= 80+enemynear(var(58)),Vel x*27
trigger3 = enemynear(var(58)),Vel X <= 0
trigger4 = enemynear(var(58)),facing = facing
trigger4 = enemynear(var(58)),stateno=5210&&(!enemynear(var(58)),ctrl=0)&&enemynear(var(58)),Vel Y != 0||enemynear(var(58)),stateno=5201
trigger4 = P2bodydist X <= 30+enemynear(var(58)),Vel x*-24||P2bodydist X <= 70+enemynear(var(58)),Vel x*-27
trigger5 = enemynear(var(58)),stateno=5210&&(!enemynear(var(58)),ctrl=0)&&enemynear(var(58)),Vel Y != 0||enemynear(var(58)),stateno=5201
trigger5 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
trigger5 = var(57) = 2 && (((floor(helper(21000),RootDist X) <=120) && facing = 1)||((floor(helper(25000),RootDist X) <= 120) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist <= 100

[state -1, ガキンチョがッ！]
type = changestate
value = 11100
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = alive
triggerall = !Inguarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
triggerall = (enemynear(var(58)),stateno!=[5120,5400])&&enemynear(var(58)),Vel Y != 0||(enemynear(var(58)),stateno=5210&&!(enemynear(var(58)),ctrl=0))&&enemynear(var(58)),Vel Y != 0||enemynear(var(58)),stateno=5201
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1 = enemynear(var(58)),facing = facing
trigger1 =  (P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),GetHitVar(Yaccel) *((15*(15-1)))/2) =[-10,5])
trigger1 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger1 = P2bodydist X >= 15+EnemyNear(var(58)),Vel X*-15
trigger1 = P2bodydist X <= 50+EnemyNear(var(58)),Vel X*-15
trigger2 = enemynear(var(58)),facing = facing
trigger2 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger2 =  (P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),GetHitVar(Yaccel) *((20*(20-1)))/2) =[-10,5])
trigger2 = P2bodydist X >= 15+EnemyNear(var(58)),Vel X*-20
trigger2 = P2bodydist X <= 50+EnemyNear(var(58)),Vel X*-20
trigger3 = enemynear(var(58)),facing = facing
trigger3 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger3 =  (P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),GetHitVar(Yaccel) *((15*(15-1)))/2) =[-10,5]) || (P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),GetHitVar(Yaccel) *((20*(20-1)))/2) =[-10,5])
trigger3 = var(57) = 2 && (((floor(helper(21000),RootDist X) =[75,125]) && facing = 1)||((floor(helper(25000),RootDist X) = [75,125]) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist = [55,105]
trigger4 = enemynear(var(58)),Vel X <= 0
Trigger4 = EnemyNear(var(58)),Movetype=I
trigger4 = enemynear(var(58)),facing != facing
trigger4 =  (P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),GetHitVar(Yaccel) *((15*(15-1)))/2) =[-10,5])
trigger4 = enemynear(var(58)),stateno=5210&&enemynear(var(58)),vel Y >= -3||enemynear(var(58)),stateno=5201||EnemyNear(var(58)),Movetype=I&&!(EnemyNear(var(58)),ctrl)&&enemynear(var(58)),vel Y >= -3
trigger4 = P2bodydist X >= 25+EnemyNear(var(58)),Vel X*15
trigger4 = P2bodydist X <= 60+EnemyNear(var(58)),Vel X*15
trigger5 = enemynear(var(58)),Vel X <= 0
Trigger5 = EnemyNear(var(58)),Movetype=I||(enemynear(var(58)),stateno=[5201,5210])&&EnemyNear(var(58)),Movetype=H
trigger5 = enemynear(var(58)),facing != facing
trigger5 =  (P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),GetHitVar(Yaccel) *((20*(20-1)))/2) =[-10,5])
trigger5 = enemynear(var(58)),stateno=5210&&enemynear(var(58)),vel Y >= -3||enemynear(var(58)),stateno=5201||EnemyNear(var(58)),Movetype=I&&!(EnemyNear(var(58)),ctrl)&&enemynear(var(58)),vel Y >= -3
trigger5 = P2bodydist X >= 25+EnemyNear(var(58)),Vel X*20
trigger5 = P2bodydist X <= 60+EnemyNear(var(58)),Vel X*20
trigger6 = enemynear(var(58)),Vel X <= 0
Trigger6 = EnemyNear(var(58)),Movetype=I||(enemynear(var(58)),stateno=[5201,5210])&&EnemyNear(var(58)),Movetype=H
trigger6 = enemynear(var(58)),facing != facing
trigger6 =  (P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),GetHitVar(Yaccel) *((15*(15-1)))/2) =[-10,5]) || (P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),GetHitVar(Yaccel) *((20*(20-1)))/2) =[-10,5])
trigger6 = enemynear(var(58)),stateno=5210&&enemynear(var(58)),vel Y >= -3||enemynear(var(58)),stateno=5201||EnemyNear(var(58)),Movetype=I&&!(EnemyNear(var(58)),ctrl)&&enemynear(var(58)),vel Y >= -3
trigger6 = var(57) = 2 && (((floor(helper(21000),RootDist X) =[75,125]) && facing = 1)||((floor(helper(25000),RootDist X) = [75,125]) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist = [55,105]

[state -1, ガキ近立ち強通常]
type = changestate
value = 275
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = alive
triggerall = !Inguarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])||(enemynear(var(58)),stateno=5210&&enemynear(var(58)),time>=13)
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*3)+(enemynear(var(58)),Const(Movement.Yaccel) *((3*(3-1)))/2) >= -60||P2Dist Y >= -60&&enemynear(var(58)),HitPauseTime >= 3
triggerall = (p2bodydist x = [-5,30])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1 = enemynear(var(58)),facing = facing
trigger1 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger2 = !Inguarddist
Trigger2 = enemynear(var(58)),vel Y >= -3
trigger2 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X < 0)|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X > 0)
Trigger2 = EnemyNear(var(58)),Movetype=I

[State -1, ガキ立ち強攻撃]
type = ChangeState
value = 270
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = var(13)
triggerall = !Inguarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = (enemynear(var(58)),stateno!=[5120,5400])||(enemynear(var(58)),stateno=5210&&enemynear(var(58)),time>=9)
triggerall = P2dist X > 0
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*6)+(enemynear(var(58)),Const(Movement.Yaccel) *((6*(6-1)))/2) >= -40||P2Dist Y >= -40&&enemynear(var(58)),HitPauseTime >= 6
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1 = !var(0) 
trigger1 =  (p2bodydist x != [-5,30])
trigger1 = enemynear(var(58)),facing = facing
trigger1 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger1 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 85+EnemyNear(var(58)),Vel X*6)||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 75+EnemyNear(var(58)),Vel X*-6)
trigger2 = !var(0) 
trigger2 =  p2bodydist x != [-5,30]
Trigger2 = enemynear(var(58)),vel Y >= -3
trigger2 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X < 0)|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X > 0)
trigger2 = (EnemyNear(var(58)),facing != facing&&P2bodydist X <= 85+EnemyNear(var(58)),Vel X*6)||(EnemyNear(var(58)),facing = facing&&P2bodydist X <= 75+EnemyNear(var(58)),Vel X*-6)
Trigger2 = EnemyNear(var(58)),Movetype=I
trigger3 = var(0) 
trigger3 = (p2bodydist x = [-5,40])
trigger3 = enemynear(var(58)),facing = facing
trigger3 = !Inguarddist
trigger3 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger4 = var(0) 
trigger4 = (p2bodydist x = [-5,40])
Trigger4 = enemynear(var(58)),vel Y >= -3
trigger4 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X < 0)|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X > 0)
Trigger4 = EnemyNear(var(58)),Movetype=I

[state -1, 近立ち弱]
type = changestate
value = 200
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !var(13)
triggerall = alive
triggerall = !Inguarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])||(enemynear(var(58)),stateno=5210&&enemynear(var(58)),time>=13)
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*3)+(enemynear(var(58)),Const(Movement.Yaccel) *((3*(3-1)))/2) >= -30||P2Dist Y >= -30&&enemynear(var(58)),HitPauseTime >= 3
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*60
trigger1 = var(0)&& (p2bodydist x = [-5,20])
trigger1 = enemynear(var(58)),facing = facing
trigger1 = EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger2 = var(0)
trigger2 = enemynear(var(58)),Movetype = I
trigger2 = (enemynear(var(58)),facing != facing&&(p2bodydist x = [-5,30]))|| (enemynear(var(58)),facing = facing&&(p2bodydist x = [-5,20]))
trigger3 = !var(0)
trigger3 = enemynear(var(58)),facing = facing
trigger3 = EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger3 = P2bodydist X <= 19+EnemyNear(var(58)),Vel X*-3
trigger4 = !var(0)
Trigger4 = EnemyNear(var(58)),Movetype=I
trigger4 = (enemynear(var(58)),facing != facing&&P2bodydist X <= 29+EnemyNear(var(58)),Vel X*3)|| (enemynear(var(58)),facing = facing&&P2bodydist X <= 19+EnemyNear(var(58)),Vel X*-3)

[state -1, 立ち強]
type = changestate
value = 220
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !var(13)
triggerall = alive
triggerall = !Inguarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])||(enemynear(var(58)),stateno=5210&&enemynear(var(58)),time>=13)
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*3)+(enemynear(var(58)),Const(Movement.Yaccel) *((3*(3-1)))/2) >= -30||P2Dist Y >= -30&&enemynear(var(58)),HitPauseTime >= 3
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*60
trigger1 = var(0)&& (p2bodydist x = [-5,30])
trigger1 = enemynear(var(58)),facing = facing
trigger1 = EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger2 = var(0)
trigger2 = enemynear(var(58)),Movetype = I
trigger2 = (enemynear(var(58)),facing != facing&&(p2bodydist x = [-5,40]))|| (enemynear(var(58)),facing = facing&&(p2bodydist x = [-5,30]))
trigger3 = !var(0)
trigger3 = enemynear(var(58)),facing = facing
trigger3 = EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger3 = P2bodydist X <= 45+EnemyNear(var(58)),Vel X*-3
trigger4 = !var(0)
Trigger4 = EnemyNear(var(58)),Movetype=I
trigger4 = (enemynear(var(58)),facing != facing&&P2bodydist X <= 45+EnemyNear(var(58)),Vel X*3)|| (enemynear(var(58)),facing = facing&&P2bodydist X <= 35+EnemyNear(var(58)),Vel X*-3)
Trigger5 = EnemyNear(var(58)),Movetype=I
trigger5 = (!var(0)&&p2bodydist x <= 45 || (p2bodydist x = [-5,40]))
trigger5 = var(57) = 2 && (((floor(helper(21000),RootDist X) <= 105) && facing = 1)||((floor(helper(25000),RootDist X) <=105) && facing = -1)) || (var(57) != 2) && frontEdgeBodyDist <= 85


[state -1, しゃがみ立ち中]
type = changestate
value = 10410
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = alive
triggerall = numhelper(10010)
triggerall = !Inguarddist&&!(helper(10010),Inguarddist)
Triggerall = Statetype != A
triggerall = enemynear(var(58)),Movetype = I
Triggerall = EnemyNear(var(58)),Vel X >= 0
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*6)+(enemynear(var(58)),Const(Movement.Yaccel) *((6*(6-1)))/2) = [-60,-1]
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = (p2bodydist x != [-5,40])
Triggerall = Random <= var(59)*60
trigger1 = enemynear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X >= 0||enemynear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X <= 0
trigger1 = P2bodydist X >= 20+EnemyNear(var(58)),Vel X*ifelse((enemynear(var(58)),facing != facing),6,-6)+((fvar(10)-1)/0.02*1.35)
trigger1 = P2bodydist X <= 53+EnemyNear(var(58)),Vel X*ifelse((enemynear(var(58)),facing != facing),6,-6)+((fvar(10)-1)/0.02*1.35)
trigger2 = enemynear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X >= 0||enemynear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X <= 0
trigger2 = P2bodydist X >= 20+EnemyNear(var(58)),Vel X*ifelse((enemynear(var(58)),facing != facing),7,-7)+((fvar(10)-1)/0.02*1.35)
trigger2 = P2bodydist X <= 53+EnemyNear(var(58)),Vel X*ifelse((enemynear(var(58)),facing != facing),7,-7)+((fvar(10)-1)/0.02*1.35)
trigger3 = enemynear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X >= 0||enemynear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X <= 0
trigger3 = P2bodydist X >= 20+EnemyNear(var(58)),Vel X*ifelse((enemynear(var(58)),facing != facing),8,-8)+((fvar(10)-1)/0.02*1.35)
trigger3 = P2bodydist X <= 53+EnemyNear(var(58)),Vel X*ifelse((enemynear(var(58)),facing != facing),8,-8)+((fvar(10)-1)/0.02*1.35)
trigger4 = enemynear(var(58)),facing = facing
trigger4 = EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger4 = P2bodydist X >= 20+(EnemyNear(var(58)),Vel X)*-6+((fvar(10)-1)/0.02*1.35)
trigger4 = P2bodydist X <= 53+(EnemyNear(var(58)),Vel X)*-6+((fvar(10)-1)/0.02*1.35)
trigger5 = enemynear(var(58)),facing = facing
trigger5 = EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger5 = var(57) = 2 
trigger5 =  helper(21000),RootDist X <= 90+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=90+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger6 = enemynear(var(58)),facing = facing
trigger6 = EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger6 = var(57) != 2 
trigger6 =  frontEdgeBodyDist <= 70+((fvar(10)-1)/0.02*1.35)
Trigger7 = enemynear(var(58)),vel Y >= -3
trigger7 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
Trigger7 = EnemyNear(var(58)),Movetype=I
trigger7 = enemynear(var(58)),facing != facing&&P2bodydist X >= 20+EnemyNear(var(58)),Vel X*6+((fvar(10)-1)/0.02*1.35)||enemynear(var(58)),facing = facing&&P2bodydist X >= 10+EnemyNear(var(58)),Vel X*-6+((fvar(10)-1)/0.02*1.35)
trigger7 = enemynear(var(58)),facing != facing&&P2bodydist X <= 53+EnemyNear(var(58)),Vel X*6+((fvar(10)-1)/0.02*1.35)||enemynear(var(58)),facing = facing&&P2bodydist X <= 53+EnemyNear(var(58)),Vel X*-6+((fvar(10)-1)/0.02*1.35)
trigger8 = var(57) = 2 
Trigger8 = enemynear(var(58)),vel Y >= -3
trigger8 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
Trigger8 = EnemyNear(var(58)),Movetype=I
trigger8 =  helper(21000),RootDist X <= 90+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=90+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger9 = var(57) != 2 
Trigger9 = enemynear(var(58)),vel Y >= -3
trigger9 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
Trigger9 = EnemyNear(var(58)),Movetype=I
trigger9 =  frontEdgeBodyDist <= 70+((fvar(10)-1)/0.02*1.35)

[state -1, S立ち強]
type = changestate
value = 10220
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = alive
triggerall = numhelper(10010)
triggerall = !Inguarddist&&!(helper(10010),Inguarddist)
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])||(enemynear(var(58)),stateno=5210&&enemynear(var(58)),time>=9)
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*7)+(enemynear(var(58)),Const(Movement.Yaccel) *((7*(7-1)))/2) >= -50||P2Dist Y >= -30&&enemynear(var(58)),HitPauseTime >= 7
triggerall = (p2bodydist x != [-5,40])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1 = enemynear(var(58)),facing = facing
trigger1 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger1 = P2bodydist X >= 41+EnemyNear(var(58)),Vel X*-7+((fvar(10)-1)/0.02*1.35)
trigger1 = P2bodydist X <= 135+EnemyNear(var(58)),Vel X*-7+((fvar(10)-1)/0.02*1.35)
trigger2 = enemynear(var(58)),facing = facing
trigger2 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger2 = var(57) = 2 
trigger2 =  helper(21000),RootDist X >= 115+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X >=115+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger2 =  helper(21000),RootDist X <= 190+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=190+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger3 = enemynear(var(58)),facing = facing
trigger3 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger3 = var(57) != 2 
trigger3 =  frontEdgeBodyDist >= 95+((fvar(10)-1)/0.02*1.35) 
trigger3 =  frontEdgeBodyDist <= 170+((fvar(10)-1)/0.02*1.35)
Trigger4 = enemynear(var(58)),vel Y >= -3
trigger4 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
Trigger4 = EnemyNear(var(58)),Movetype=I
trigger4 = enemynear(var(58)),facing != facing&&P2bodydist X >= 70+EnemyNear(var(58)),Vel X*7+((fvar(10)-1)/0.02*1.35)||enemynear(var(58)),facing = facing&&P2bodydist X >= 60+EnemyNear(var(58)),Vel X*-7+((fvar(10)-1)/0.02*1.35)
trigger4 = enemynear(var(58)),facing != facing&&P2bodydist X <= 135+EnemyNear(var(58)),Vel X*7+((fvar(10)-1)/0.02*1.35)||enemynear(var(58)),facing = facing&&P2bodydist X <= 125+EnemyNear(var(58)),Vel X*-7+((fvar(10)-1)/0.02*1.35)
trigger5 = var(57) = 2 
Trigger5 = enemynear(var(58)),vel Y >= -3
trigger5 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
Trigger5 = EnemyNear(var(58)),Movetype=I
trigger5 =  helper(21000),RootDist X >= 115+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X >=115+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger5 =  helper(21000),RootDist X <= 190+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=190+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger6 = var(57) != 2 
Trigger6 = enemynear(var(58)),vel Y >= -3
trigger6 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
Trigger6 = EnemyNear(var(58)),Movetype=I
trigger6 =  frontEdgeBodyDist >= 95+((fvar(10)-1)/0.02*1.35) 
trigger6 =  frontEdgeBodyDist <= 170+((fvar(10)-1)/0.02*1.35)
trigger7 = P2Dist Y + (enemynear(var(58)),Vel y*7)+(enemynear(var(58)),Const(Movement.Yaccel) *((7*(7-1)))/2) >= -30||P2Dist Y >= -30&&enemynear(var(58)),HitPauseTime >= 7
trigger7 = enemynear(var(58)),facing != facing
trigger7 = enemynear(var(58)),Vel X > 0
Trigger7 = EnemyNear(var(58)),Vel Y > 0
Trigger7 = EnemyNear(var(58)),Movetype=I
trigger7 = P2bodydist X >= 90+EnemyNear(var(58)),Vel X*7
trigger7 = P2bodydist X >= 41+EnemyNear(var(58)),Vel X*7+((fvar(10)-1)/0.02*1.35)
trigger7 = P2bodydist X <= 145+EnemyNear(var(58)),Vel X*7+((fvar(10)-1)/0.02*1.35)

[state -1, S立ち中]
type = changestate
value = 10210
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = alive
triggerall = numhelper(10010)
triggerall = !Inguarddist&&!(helper(10010),Inguarddist)
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])||(enemynear(var(58)),stateno=5210&&enemynear(var(58)),time>=11)
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*5)+(enemynear(var(58)),Const(Movement.Yaccel) *((5*(5-1)))/2) >= -60||P2Dist Y >= -40&&enemynear(var(58)),HitPauseTime >= 5
triggerall = (p2bodydist x != [-5,30])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1 = enemynear(var(58)),facing = facing
trigger1 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger1 = P2bodydist X >= 65+EnemyNear(var(58)),Vel X*-5+((fvar(10)-1)/0.02*1.35)
trigger1 = P2bodydist X <= 123+EnemyNear(var(58)),Vel X*-5+((fvar(10)-1)/0.02*1.35)
trigger2 = enemynear(var(58)),facing = facing
trigger2 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger2 = var(57) = 2 
trigger2 =  helper(21000),RootDist X >= 125+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X >=125+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger2 =  helper(21000),RootDist X <= 160+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=160+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger3 = enemynear(var(58)),facing = facing
trigger3 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger3 = var(57) != 2 
trigger3 =  frontEdgeBodyDist >= 105+((fvar(10)-1)/0.02*1.35) 
trigger3 =  frontEdgeBodyDist <= 140+((fvar(10)-1)/0.02*1.35)
Trigger4 = enemynear(var(58)),vel Y >= -3
trigger4 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
Trigger4 = EnemyNear(var(58)),Movetype=I
trigger4 = enemynear(var(58)),facing != facing&&P2bodydist X >= 65+EnemyNear(var(58)),Vel X*5+((fvar(10)-1)/0.02*1.35)||enemynear(var(58)),facing = facing&&P2bodydist X >= 55+EnemyNear(var(58)),Vel X*-5+((fvar(10)-1)/0.02*1.35)
trigger4 = enemynear(var(58)),facing != facing&&P2bodydist X <= 123+EnemyNear(var(58)),Vel X*5+((fvar(10)-1)/0.02*1.35)||enemynear(var(58)),facing = facing&&P2bodydist X <= 113+EnemyNear(var(58)),Vel X*-5+((fvar(10)-1)/0.02*1.35)
trigger5 = var(57) = 2 
Trigger5 = enemynear(var(58)),vel Y >= -3
trigger5 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
trigger5 =  helper(21000),RootDist X >= 125+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X >=125+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger5 =  helper(21000),RootDist X <= 160+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=160+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger6 = var(57) != 2 
Trigger6 = enemynear(var(58)),vel Y >= -3
trigger6 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
Trigger6 = EnemyNear(var(58)),Movetype=I
trigger6 =  frontEdgeBodyDist >= 105+((fvar(10)-1)/0.02*1.35) 
trigger6 =  frontEdgeBodyDist <= 140+((fvar(10)-1)/0.02*1.35)
trigger7 = P2Dist Y + (enemynear(var(58)),Vel y*5)+(enemynear(var(58)),Const(Movement.Yaccel) *((5*(5-1)))/2) >= -40||P2Dist Y >= -40&&enemynear(var(58)),HitPauseTime >= 5
trigger7 = enemynear(var(58)),facing != facing
trigger7 = enemynear(var(58)),Vel X > 0
Trigger7 = EnemyNear(var(58)),Vel Y > 0
Trigger7 = EnemyNear(var(58)),Movetype=I
trigger7 = P2bodydist X >= 80+EnemyNear(var(58)),Vel X*5
trigger7 = P2bodydist X >= 65+EnemyNear(var(58)),Vel X*5+((fvar(10)-1)/0.02*1.35)
trigger7 = P2bodydist X <= 123+EnemyNear(var(58)),Vel X*5+((fvar(10)-1)/0.02*1.35)


[state -1, S立ち弱]
type = changestate
value = 10200
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = alive
triggerall = numhelper(10010)
triggerall = !Inguarddist&&!(helper(10010),Inguarddist)
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])||(enemynear(var(58)),stateno=5210&&enemynear(var(58)),time>=12)
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*4)+(enemynear(var(58)),Const(Movement.Yaccel) *((4*(4-1)))/2) >= -10||P2Dist Y >= -10&&enemynear(var(58)),HitPauseTime >= 4
triggerall = (p2bodydist x != [-5,30])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1 = enemynear(var(58)),facing = facing
trigger1 = enemynear(var(58)),Movetype = I||EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger1 = P2bodydist X >= 31+EnemyNear(var(58)),Vel X*-4+((fvar(10)-1)/0.02*1.35)
trigger1 = P2bodydist X <= 97+EnemyNear(var(58)),Vel X*-4+((fvar(10)-1)/0.02*1.35)
trigger2 = enemynear(var(58)),facing = facing
trigger2 = EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger2 = var(57) = 2 
trigger2 =  helper(21000),RootDist X >= 75+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X >=75+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger2 =  helper(21000),RootDist X <= 140+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=140+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger3 = enemynear(var(58)),facing = facing
trigger3 = EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger3 = var(57) != 2 
trigger3 =  frontEdgeBodyDist <= 120+((fvar(10)-1)/0.02*1.35)
trigger3 =  frontEdgeBodyDist >= 55+((fvar(10)-1)/0.02*1.35) 
Trigger4 = enemynear(var(58)),vel Y >= -3
trigger4 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
Trigger4 = EnemyNear(var(58)),Movetype=I
trigger4 = enemynear(var(58)),facing != facing&&P2bodydist X >= 31+EnemyNear(var(58)),Vel X*4+((fvar(10)-1)/0.02*1.35)||enemynear(var(58)),facing = facing&&P2bodydist X >= 31+EnemyNear(var(58)),Vel X*-4+((fvar(10)-1)/0.02*1.35)
trigger4 = enemynear(var(58)),facing != facing&&P2bodydist X <= 97+EnemyNear(var(58)),Vel X*4+((fvar(10)-1)/0.02*1.35)||enemynear(var(58)),facing = facing&&P2bodydist X <= 87+EnemyNear(var(58)),Vel X*-4+((fvar(10)-1)/0.02*1.35)
trigger5 = var(57) = 2 
Trigger5 = enemynear(var(58)),vel Y >= -3
trigger5 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
trigger5 =  helper(21000),RootDist X >= 75+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X >=75+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger5 =  helper(21000),RootDist X <= 140+((fvar(10)-1)/0.02*1.35) && facing = 1||helper(25000),RootDist X <=140+((fvar(10)-1)/0.02*1.35) && facing = -1
trigger6 = var(57) != 2 
Trigger6 = enemynear(var(58)),vel Y >= -3
trigger6 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
Trigger6 = EnemyNear(var(58)),Movetype=I
trigger6 =  frontEdgeBodyDist <= 120+((fvar(10)-1)/0.02*1.35)
trigger6 =  frontEdgeBodyDist >= 55+((fvar(10)-1)/0.02*1.35) 
trigger7 = enemynear(var(58)),facing != facing
trigger7 = enemynear(var(58)),Vel X > 0
Trigger7 = EnemyNear(var(58)),Vel Y > 0
Trigger7 = EnemyNear(var(58)),Movetype=I
trigger7 = P2bodydist X >= 31+EnemyNear(var(58)),Vel X*4+((fvar(10)-1)/0.02*1.35)
trigger7 = P2bodydist X <= 97+EnemyNear(var(58)),Vel X*4+((fvar(10)-1)/0.02*1.35)

[state -1, しゃがみ中]
type = changestate
value = 410
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (!var(0)&&P2bodydist X <= 37 || (p2bodydist x = [-5,40]))
triggerall = !var(8)
triggerall = alive
triggerall = !Inguarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*5)+(enemynear(var(58)),Const(Movement.Yaccel) *((5*(5-1)))/2) >= -5
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1= enemynear(var(58)),stateno=5201

[state -1, 通常しゃがみ強]
type = changestate
value = 420
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = alive
triggerall = !Inguarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),Vel Y != 0
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*5)+(enemynear(var(58)),Const(Movement.Yaccel) *((5*(5-1)))/2) = [-5,20]
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1 = enemynear(var(58)),stateno!=[5120,5400]
trigger1 = enemynear(var(58)),facing = facing
trigger1 = EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger1 = P2bodydist X <= 100+EnemyNear(var(58)),Vel X*-5+((fvar(10)-1)/0.02*1.35)
trigger2 = enemynear(var(58)),stateno!=[5120,5400]
Trigger2 = enemynear(var(58)),vel Y >= -3
trigger2 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
Trigger2 = EnemyNear(var(58)),Movetype=I&&enemynear(var(58)),ctrl=0
trigger2 = enemynear(var(58)),facing != facing&&P2bodydist X <= 100+EnemyNear(var(58)),Vel X*5||enemynear(var(58)),facing = facing&&P2bodydist X <= 90+EnemyNear(var(58)),Vel X*-5
trigger3 = enemynear(var(58)),stateno=5201
trigger3 = P2Dist Y + (enemynear(var(58)),Vel y*6)+(enemynear(var(58)),Const(Movement.Yaccel) *((6*(6-1)))/2) >= -5
trigger3 = enemynear(var(58)),facing != facing&&P2bodydist X <= 100||enemynear(var(58)),facing = facing&&P2bodydist X <=90

[state -1, Sしゃがみ強]
type = changestate
value = 10420
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = alive
triggerall = !Inguarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),Vel Y != 0
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*5)+(enemynear(var(58)),Const(Movement.Yaccel) *((5*(5-1)))/2) = [-5,20]
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1 = enemynear(var(58)),stateno!=[5120,5400]
trigger1 = enemynear(var(58)),facing = facing
trigger1 = EnemyNear(var(58)),Movetype = A&&EnemyNear(var(58)),Time >= 10
trigger1 = P2bodydist X <= 100+EnemyNear(var(58)),Vel X*-5+((fvar(10)-1)/0.02*1.35)
trigger2 = enemynear(var(58)),stateno!=[5120,5400]
Trigger2 = enemynear(var(58)),vel Y >= -3
trigger2 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X <= 0)|| (enemynear(var(58)),facing = facing)
Trigger2 = EnemyNear(var(58)),Movetype=I&&enemynear(var(58)),ctrl=0
trigger2 = enemynear(var(58)),facing != facing&&P2bodydist X <= 100+EnemyNear(var(58)),Vel X*5||enemynear(var(58)),facing = facing&&P2bodydist X <= 90+EnemyNear(var(58)),Vel X*-5
trigger3 = enemynear(var(58)),stateno=5201
trigger3 = P2Dist Y + (enemynear(var(58)),Vel y*6)+(enemynear(var(58)),Const(Movement.Yaccel) *((6*(6-1)))/2) >= -5
trigger3 = enemynear(var(58)),facing != facing&&P2bodydist X <= 100||enemynear(var(58)),facing = facing&&P2bodydist X <=90

[state -1, S立ち強]
type = changestate
value = 10220
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = alive
triggerall = numhelper(10010)
triggerall = !Inguarddist&&!(helper(10010),Inguarddist)
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*8)+(enemynear(var(58)),Const(Movement.Yaccel) *((8*(8-1)))/2) >= -5
triggerall = (p2bodydist x >= 80)
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1= enemynear(var(58)),stateno=5201
trigger1 = P2bodydist X >= 41+((fvar(10)-1)/0.02*1.35)
trigger1 = P2bodydist X <= 145+((fvar(10)-1)/0.02*1.35)

[state -1, S立ち中]
type = changestate
value = 10210
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = alive
triggerall = numhelper(10010)
triggerall = !Inguarddist&&!(helper(10010),Inguarddist)
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*6)+(enemynear(var(58)),Const(Movement.Yaccel) *((6*(6-1)))/2) >= -5
triggerall = (p2bodydist x >=50)
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1= enemynear(var(58)),stateno=5201
trigger1 = P2bodydist X >= 65+((fvar(10)-1)/0.02*1.35)
trigger1 = P2bodydist X <= 123+((fvar(10)-1)/0.02*1.35)

[state -1, 立ち弱]
type = changestate
value = 200
Triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (!var(0)&&p2bodydist x <=30 || (p2bodydist x = [-5,30]))
triggerall = !var(8)
triggerall = !var(13)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = P2bodydist Y >= -50
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = Random <= ifelse((!Inguarddist),10,5)

[state -1, 立ち弱]
type = changestate
value = 220
Triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = (!var(0)&&p2bodydist x <=40 || (p2bodydist x = [-5,40]))
triggerall = !var(8)
triggerall = !var(13)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = P2bodydist Y >= -50
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = Random <= ifelse((!Inguarddist),10,5)

[State -1, ウシウシウシッ！]
type = ChangeState
value = ifelse((!var(0)),3100,3200)
triggerall = var(59) = [1,2]
triggerall = var(57)>= 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !var(13)
triggerall = Power >= 1000
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = P2bodydist Y >= -100
triggerall = P2bodydist X <= 70
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = enemynear(var(58)),facing != facing&&EnemyNear(var(58)),Vel X>=0||enemynear(var(58)),facing = facing&&EnemyNear(var(58)),Vel X<=0
Trigger1 = Random <= 5

[state -1, ガキンチョがッ！]
type = changestate
value = 1100
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Vel Y != 0
Triggerall = enemynear(var(58)),Statetype = A
triggerall = enemynear(var(58)),HitPauseTime <= 0
triggerall = EnemyNear(var(58)),Movetype = A && EnemyNear(var(58)),Time >= 15||EnemyNear(var(58)),Movetype = I && EnemyNear(var(58)),ctrl = 0
Triggerall = EnemyNear(var(58)),vel X = [-2,1]
triggerall = (enemynear(var(58)),stateno!=[5120,5400])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1 =  (P2Dist Y + (enemynear(var(58)),Vel y*24)+(enemynear(var(58)),GetHitVar(Yaccel) *((24*(24-1)))/2) =[-80,5])
trigger1 = EnemyNear(var(58)),facing!=facing&&P2bodydist X <= 30+enemynear(var(58)),Vel x*24||EnemyNear(var(58)),facing=facing&&P2bodydist X <= 30+enemynear(var(58)),Vel x*-24
trigger2 =  (P2Dist Y + (enemynear(var(58)),Vel y*27)+(enemynear(var(58)),GetHitVar(Yaccel) *((27*(27-1)))/2) =[-20,5])
trigger2 =EnemyNear(var(58)),facing!=facing&&P2bodydist X <= 60+enemynear(var(58)),Vel x*27||EnemyNear(var(58)),facing=facing&&P2bodydist X <= 60+enemynear(var(58)),Vel x*-27

[state -1, ガキンチョがッ！]
type = changestate
value = 11100
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Vel Y != 0
Triggerall = enemynear(var(58)),Statetype = A
triggerall = enemynear(var(58)),HitPauseTime <= 0
triggerall = EnemyNear(var(58)),Movetype = A && EnemyNear(var(58)),Time >= 15||EnemyNear(var(58)),Movetype = I && EnemyNear(var(58)),ctrl = 0
Triggerall = EnemyNear(var(58)),vel X = [-2,1]
triggerall = (enemynear(var(58)),stateno!=[5120,5400])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1 =  (P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),GetHitVar(Yaccel) *((15*(15-1)))/2) =[-10,5])
trigger1 = EnemyNear(var(58)),facing!=facing
trigger1 = P2bodydist X >= 25+EnemyNear(var(58)),Vel X*15
trigger1 = P2bodydist X <= 60+EnemyNear(var(58)),Vel X*15
trigger2 =  (P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),GetHitVar(Yaccel) *((20*(20-1)))/2) =[-10,5])
trigger2 = EnemyNear(var(58)),facing!=facing
trigger2 = (P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),GetHitVar(Yaccel) *((20*(20-1)))/2) =[-10,5])
trigger2 = P2bodydist X >= 25+EnemyNear(var(58)),Vel X*20
trigger2 = P2bodydist X <= 60+EnemyNear(var(58)),Vel X*20
trigger3 =  (P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),GetHitVar(Yaccel) *((15*(15-1)))/2) =[-10,5]) 
trigger3 = EnemyNear(var(58)),facing=facing
trigger3 = P2bodydist X >= 15+EnemyNear(var(58)),Vel X*-15
trigger3 = P2bodydist X <= 50+EnemyNear(var(58)),Vel X*-15
trigger4 =  (P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),GetHitVar(Yaccel) *((20*(20-1)))/2) =[-10,5])
trigger4 = EnemyNear(var(58)),facing=facing
trigger4 = P2bodydist X >= 15+EnemyNear(var(58)),Vel X*-20
trigger4 = P2bodydist X <= 50+EnemyNear(var(58)),Vel X*-20

[state -1, ガキ近立ち強通常]
type = changestate
value = 275
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = var(13)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])
triggerall = (p2bodydist x = [-5,30])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
Trigger1 = EnemyNear(var(58)),vel X = [-2,1]
trigger1 = EnemyNear(var(58)),Movetype = A && EnemyNear(var(58)),Time >= 15
trigger1 = P2Dist Y + (enemynear(var(58)),Vel y*3)+(enemynear(var(58)),Const(Movement.Yaccel) *((3*(3-1)))/2) >= -60||P2Dist Y >= -60&&enemynear(var(58)),HitPauseTime >= 3
trigger2 = !Inguarddist
trigger2 = (EnemyNear(var(58)),stateno=[5000,5071]) ||(EnemyNear(var(58)),stateno=[120,155])
trigger2 = P2bodydist Y >= -80

[state -1, ガキ立ち強通常]
type = changestate
value = 270
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = var(13)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = EnemyNear(var(58)),vel X = [-2,1]
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = EnemyNear(var(58)),Movetype = A && EnemyNear(var(58)),Time >= 15
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*6)+(enemynear(var(58)),Const(Movement.Yaccel) *((6*(6-1)))/2) >= -40||P2Dist Y >= -40&&enemynear(var(58)),HitPauseTime >= 6
Triggerall = Random <= var(59)*50
trigger1 = var(0) 
trigger1 = (p2bodydist x = [-5,40])
trigger2 = !var(0) 
trigger2 = (p2bodydist x = [31,85])

[state -1, ガキ立ち弱通常]
type = changestate
value = 250
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = var(13)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])
triggerall = (!var(0)&&p2bodydist x <= 32 || (p2bodydist x = [-5,30]))
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
Trigger1 = EnemyNear(var(58)),vel X = [-2,1]
trigger1 = EnemyNear(var(58)),Movetype = A && EnemyNear(var(58)),Time >= 15
trigger1 = P2Dist Y + (enemynear(var(58)),Vel y*3)+(enemynear(var(58)),Const(Movement.Yaccel) *((3*(3-1)))/2) >= -40||P2Dist Y >= -40&&enemynear(var(58)),HitPauseTime >= 3
trigger2 = !Inguarddist
trigger2 = (EnemyNear(var(58)),stateno=[5000,5071]) ||(EnemyNear(var(58)),stateno=[120,155])
trigger2 = P2bodydist Y >= -60

[state -1, 立ち弱通常]
type = changestate
value = 200
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !var(13)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])
triggerall =  (!var(0)&&p2bodydist x <=30  || (p2bodydist x = [-5,30]))
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
Trigger1 = EnemyNear(var(58)),vel X = [-2,1]
trigger1 = EnemyNear(var(58)),Movetype = A && EnemyNear(var(58)),Time >= 15
trigger1 = P2Dist Y + (enemynear(var(58)),Vel y*3)+(enemynear(var(58)),Const(Movement.Yaccel) *((3*(3-1)))/2) >= -30||P2Dist Y >= -30&&enemynear(var(58)),HitPauseTime >= 3
trigger2 = !Inguarddist
trigger2 = (EnemyNear(var(58)),stateno=[5000,5071]) ||(EnemyNear(var(58)),stateno=[120,155])
trigger2 = P2bodydist Y >= -50

[state -1, 立ち強通常]
type = changestate
value = 220
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !var(13)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = EnemyNear(var(58)),vel X = [-2,1]
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])
triggerall =  (!var(0)&&p2bodydist x <=45  || (p2bodydist x = [-5,40]))
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1 = EnemyNear(var(58)),Movetype = A && EnemyNear(var(58)),Time >= 15
trigger1 = P2Dist Y + (enemynear(var(58)),Vel y*3)+(enemynear(var(58)),Const(Movement.Yaccel) *((3*(3-1)))/2) >= -30||P2Dist Y >= -30&&enemynear(var(58)),HitPauseTime >= 3

[state -1, しゃがみ強通常]
type = changestate
value = 420
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(8)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Vel Y != 0
triggerall = enemynear(var(58)),HitPauseTime <= 0
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = EnemyNear(var(58)),vel X = [-2,1]
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])
triggerall = p2bodydist x =[45,100] 
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1 = EnemyNear(var(58)),Movetype = A && EnemyNear(var(58)),Time >= 15
trigger1 =  P2Dist Y + (enemynear(var(58)),Vel y*5)+(enemynear(var(58)),Const(Movement.Yaccel) *((5*(5-1)))/2) = [-5,10]

[state -1, Sしゃがみ中]
type = changestate
value = 10410
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])
triggerall =  (p2bodydist x != [-5,40])
triggerall = P2bodydist X >= 20+EnemyNear(var(58)),Vel X*6+((fvar(10)-1)/0.02*1.35)
triggerall = P2bodydist X <= 53+EnemyNear(var(58)),Vel X*6+((fvar(10)-1)/0.02*1.35)
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
Trigger1 = EnemyNear(var(58)),vel X = [-2,1]
trigger1 = EnemyNear(var(58)),Movetype = A && EnemyNear(var(58)),Time >= 15
trigger1 = (P2Dist Y + (enemynear(var(58)),Vel y*6)+(enemynear(var(58)),Const(Movement.Yaccel) *((6*(6-1)))/2) = [-60,-1])||P2Dist Y >= -60&&enemynear(var(58)),HitPauseTime >= 6
trigger2 = var(57) != [2,3]
trigger2 = numhelper(10010)
trigger2 = !Inguarddist&&!(helper(10010),Inguarddist)
trigger2 = EnemyNear(var(58)),Vel Y = [-4,4]
trigger2 = (EnemyNear(var(58)),stateno=[5000,5071]) ||(EnemyNear(var(58)),stateno=[120,155])
trigger2 = P2bodydist Y = [-70,-10]

[state -1, S立ち強]
type = changestate
value = 10220
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Vel Y != 0
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])
triggerall =  (p2bodydist x != [-5,40])
triggerall = P2bodydist X >= 41+EnemyNear(var(58)),Vel X*-7+((fvar(10)-1)/0.02*1.35)
triggerall = P2bodydist X <= 145+EnemyNear(var(58)),Vel X*-7+((fvar(10)-1)/0.02*1.35)
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
Trigger1 = EnemyNear(var(58)),vel X = [-2,1]
trigger1 = EnemyNear(var(58)),Movetype = A && EnemyNear(var(58)),Time >= 15
trigger1 = P2Dist Y + (enemynear(var(58)),Vel y*7)+(enemynear(var(58)),Const(Movement.Yaccel) *((7*(7-1)))/2) >= -30||P2Dist Y >= -30&&enemynear(var(58)),HitPauseTime >= 7

[state -1, S立ち中]
type = changestate
value = 10210
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])
triggerall =  (p2bodydist x != [-5,30])
triggerall = P2bodydist X >= 65+EnemyNear(var(58)),Vel X*-5+((fvar(10)-1)/0.02*1.35)
triggerall = P2bodydist X <= 123+EnemyNear(var(58)),Vel X*-5+((fvar(10)-1)/0.02*1.35)
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
Trigger1 = EnemyNear(var(58)),vel X = [-2,1]
trigger1 = EnemyNear(var(58)),Movetype = A && EnemyNear(var(58)),Time >= 15
trigger1 = P2Dist Y + (enemynear(var(58)),Vel y*5)+(enemynear(var(58)),Const(Movement.Yaccel) *((5*(5-1)))/2) >= -40||P2Dist Y >= -40&&enemynear(var(58)),HitPauseTime >= 5

[state -1, S立ち弱]
type = changestate
value = 10200
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Vel Y != 0
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])
triggerall =  (p2bodydist x != [-5,30])
triggerall = P2bodydist X >= 31+((fvar(10)-1)/0.02*1.35)
triggerall = P2bodydist X <= 97+((fvar(10)-1)/0.02*1.35)
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
Trigger1 = EnemyNear(var(58)),vel X = [-2,1]
trigger1 = EnemyNear(var(58)),Movetype = A && EnemyNear(var(58)),Time >= 15
trigger1 = P2Dist Y + (enemynear(var(58)),Vel y*4)+(enemynear(var(58)),Const(Movement.Yaccel) *((4*(4-1)))/2) >= -10||P2Dist Y >= -10&&enemynear(var(58)),HitPauseTime >= 4

[state -1, Sしゃがみ強]
type = changestate
value = 10420
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
triggerall = !var(8)
triggerall = alive
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),HitPauseTime <= 0
Triggerall = enemynear(var(58)),Vel Y != 0
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = EnemyNear(var(58)),vel X = [-2,1]
Triggerall = enemynear(var(58)),Stateno < 200000
triggerall = (enemynear(var(58)),stateno!=[5120,5400])
triggerall = p2bodydist x =[41,100] 
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Triggerall = Random <= var(59)*50
trigger1 = EnemyNear(var(58)),Movetype = A && EnemyNear(var(58)),Time >= 15
trigger1 =  P2Dist Y + (enemynear(var(58)),Vel y*5)+(enemynear(var(58)),Const(Movement.Yaccel) *((5*(5-1)))/2) = [-5,10]

[State -1, 蜂の巣遠]
type = ChangeState
value = 1000
triggerall = var(59) = [3,4]
triggerall = var(57)=2&&EnemyNear(var(58)),life >1||var(57)!=[2,3]
triggerall = var(49) = 1
triggerall = !var(8)
triggerall = !InGuarddist
triggerall = roundstate = 2
triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype = A
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),Anim != 5300
triggerall = P2dist X > 0
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),Const(Movement.Yaccel) *((15*(15-1)))/2) >= -70
triggerall = P2bodydist X = [140,250]
triggerall = ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
triggerall = random <= 30
Trigger1 = enemynear(var(58)),facing != facing
Trigger1 = enemynear(var(58)),Movetype != A
trigger1 = enemynear(var(58)),Vel X <= 0
trigger1 = var(2) := 2
Trigger2 = enemynear(var(58)),facing = facing
trigger2 = enemynear(var(58)),Vel X >= 0
trigger2 = var(2) := 2


[State -1,後退]
Type = ChangeState
Value = 20
Triggerall = var(59) > 0
Triggerall = statetype != A && !ishelper
Triggerall = stateno != [100,105]
triggerall = stateno != 21
triggerall = Roundstate = 2
trigger1 = EnemyNear(var(58)),Movetype = A
trigger1 = EnemyNear(var(58)),Statetype = A
trigger1 = numhelper(21474)
trigger1 = !InGuardDist&& !(helper(21474),InGuarddist)||var(45) != 0
trigger1 = P2dist X <= 0
Trigger1 = stateno = 140||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))||stateno=52&&ctrl
trigger2 = P2dist X <= 0
trigger2 = EnemyNear(var(58)),Movetype = A
trigger2 = EnemyNear(var(58)),Statetype != A
trigger2 = EnemyNear(var(58)),facing != facing
trigger2 = numhelper(21474)
trigger2 = !InGuarddist&& !(helper(21474),InGuarddist)
Trigger2 = stateno = 140||stateno=52&&ctrl
trigger3 = P2dist X <= 0
trigger3 = numhelper(21474)
trigger3 = !InGuarddist&& !(helper(21474),InGuarddist)
trigger3 = ctrl
trigger3 = stateno = 140||(stateno=[10,14])||stateno=52&&ctrl
trigger4 = P2dist X <= 0
trigger4 = EnemyNear(var(58)),Movetype = A
trigger4 = EnemyNear(var(58)),Statetype != A
trigger4 = EnemyNear(var(58)),facing = facing&&var(54) != 0
Trigger4 = stateno = [120,140]


[State -1,前進]
Type = ChangeState
value = 21
Triggerall = var(59) > 0
Triggerall = var(57) >= 0
Triggerall = var(49) = 1
triggerall = numhelper(21474)
triggerall = !InGuarddist&& !(helper(21474),InGuarddist)||var(13)&&var(57)=[1,2]
Triggerall = statetype != A
Triggerall = P2dist X > 0
triggerall = stateno != 21
triggerall = P2bodydist X > 5
Triggerall = frontedgebodydist > 0
Triggerall = Ctrl||stateno=20||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))||stateno=22
trigger1 = var(39) = 0||enemynear(var(58)),statetype = A||(enemynear(var(58)),stateno = [5100,5110])||var(39) = [3,4]
Trigger1 =(EnemyNear(var(58)),stateno !=[200060,200063])||var(59)=[1,2]
trigger1 = (enemynear(var(58)),facing != facing&&P2bodydist X = [6,65])|| (enemynear(var(58)),facing = facing&&P2bodydist X = [6,55])
Trigger1 = (enemynear(var(58)),stateno != [5100,5400])
Trigger1 = random <= 80
trigger2 = (enemynear(var(58)),facing != facing&&P2bodydist X = [53,150])|| (enemynear(var(58)),facing = facing&&P2bodydist X = [43,140])
Trigger2 = random <= 170
Trigger3 = enemynear(var(58)),statetype != L
Trigger3 = (enemynear(var(58)),stateno != [5100,5400])
trigger3 = (enemynear(var(58)),facing != facing&&P2bodydist X > 150)|| (enemynear(var(58)),facing = facing&&P2bodydist X > 140)
Trigger3 = random <= ifelse((enemynear(var(58)),facing!=facing),230,290)
Trigger4 = enemynear(var(58)),statetype = L || (enemynear(var(58)),stateno = [5100,5400])
trigger4 = (enemynear(var(58)),facing != facing&&P2bodydist X > 150)|| (enemynear(var(58)),facing = facing&&P2bodydist X > 140)
Trigger4 = random <= ifelse((enemynear(var(58)),facing!=facing),230,290)
trigger5 = stateno = 22
trigger5 = Backedgebodydist <= 0

[State -1,後退]
Type = ChangeState
value = 22
Triggerall = var(59) > 0
Triggerall = var(57) >= 0
Triggerall = var(49) = 1
triggerall = numhelper(21474)
triggerall = !InGuarddist&& !(helper(21474),InGuarddist)||var(13)&&var(57)=[1,2]
Triggerall = statetype != A
Triggerall = P2dist X > 0
triggerall = stateno != 22
Triggerall = Backedgebodydist > 0
Triggerall = Ctrl||(stateno=[20,21])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
Trigger1 = enemynear(var(58)),Anim != 5300
trigger1 = EnemyNear(var(58)),stateno <200000||var(59)=[1,2]
trigger1 = enemynear(var(58)),stateno != [5000,5050]
trigger1 = (enemynear(var(58)),facing != facing&&P2bodydist X= [0,150])|| (enemynear(var(58)),facing = facing&&P2bodydist X = [0,140])
Trigger1 = random <= ifelse((enemynear(var(58)),facing!=facing),10,1)
Trigger2 = enemynear(var(58)),Anim != 5300
trigger2 = EnemyNear(var(58)),stateno <200000||var(59)=[1,2]
Trigger2 = random <= ifelse((enemynear(var(58)),facing!=facing),10,1)
trigger2 = (enemynear(var(58)),facing != facing&&P2bodydist X > 150)|| (enemynear(var(58)),facing = facing&&P2bodydist X > 140)
Trigger2 = enemynear(var(58)),facing!=facing
trigger2 = random <= 5
Trigger3 = var(59) > 1
Trigger3 = P2bodydist X <= 60
trigger3 = EnemyNear(var(58)),stateno <200000||var(59)=[1,2]
Trigger3 = enemynear(var(58)),Anim != 5300
Trigger3 = (enemynear(var(58)),stateno = [5100,5400])||(enemynear(var(58)),stateno = 1525)
Trigger3 = random <= 200
Trigger4 = var(59) > 1
Trigger4 = P2bodydist X <= 60
Trigger4 = enemynear(var(58)),statetype = L&&(enemynear(var(58)),stateno != [5100,5400])&&EnemyNear(var(58)),stateno <200000||(EnemyNear(var(58)),stateno =[200060,200063])
Trigger4 = random <= 200
trigger5 = var(57) = [0,1]
trigger5 = EnemyNear(var(58)),stateno <200000||var(59)=[1,2]
Trigger5 = enemynear(var(58)),statetype = A
Trigger5 = enemynear(var(58)),Movetype = H
trigger5 = P2bodydist X <= 20
Trigger5 = random <= 200
Trigger6 = var(59) = [3,4]
Trigger6 = P2bodydist X <= 80
trigger6 = EnemyNear(var(58)),stateno <200000||var(59)=[1,2]
Trigger6 = (var(39) = [1,2])||var(39) = 4
Trigger6= enemynear(var(58)),statetype != A
trigger6 = (enemynear(var(58)),stateno != [5100,5101])&&(enemynear(var(58)),stateno !=5110)&&(enemynear(var(58)),stateno !=5120)
Trigger7 = var(59) = [3,4]
Trigger7 = enemynear(var(58)),statetype = A
trigger7 = enemynear(var(58)),Movetype = I
trigger7 = enemynear(var(58)),facing=facing
trigger7 = enemynear(var(58)),Vel X<=0
Trigger7 = P2bodydist X <= 10
Trigger7 = random <= 70

[State -1,バックステップ]
Type = ChangeState
value = 105
Triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = alive
Triggerall = Statetype != A
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),facing != facing
Triggerall = enemynear(var(58)),Anim != 5300
Triggerall = enemynear(var(58)),stateno != [5296,5299]
triggerall = Backedgebodydist > 0
triggerall = P2dist X > 0
triggerall=Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = !Inguarddist
trigger1 = enemynear(var(58)),Movetype != A
trigger1 = P2bodydist X <= 70
trigger1 = random <= 10

[State -1, ダッシュ]
type = ChangeState
value = 100
triggerall = var(59) = [3,4]
triggerall = var(57) = [1,2]
triggerall = var(49) = 1
triggerall = var(39) = 0
triggerall = var(0)
triggerall = !var(8)
triggerall = !var(13)||var(57) != 2
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !InGuarddist
Triggerall = enemynear(var(58)),Movetype != A&&enemynear(var(58)),Numproj=0||enemynear(var(58)),facing=facing
Triggerall = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X<=3)||(enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X>=0)||(enemynear(var(58)),stateno=[100,101])||(enemynear(var(58)),Anim=[20,21])
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Statetype != A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Stateno < 200000
Triggerall = enemynear(var(58)),Anim != 40
Triggerall = enemynear(var(58)),Stateno != [5120,5999]
triggerall = EnemyNear(var(58)),Prevstateno != [5050,5110]
triggerall = P2dist X > 0
triggerall = Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X =[160,230]
trigger1 = random <= 50

[State -1,ダッシュ]
Type = ChangeState
value = 100
Triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = alive
Triggerall = Statetype != A
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = EnemyNear(var(58)),Alive
Triggerall = enemynear(var(58)),Anim != 5300
Triggerall = enemynear(var(58)),stateno != [5296,5299]
triggerall = Backedgebodydist > 0
triggerall = P2dist X > 0
triggerall=Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = !Inguarddist
trigger1 = enemynear(var(58)),Movetype != A
trigger1 = P2bodydist X >= 100
trigger1 = random <= 10

[State -1, SonD弱]
type = ChangeState
value = 10201
triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !Inguarddist
triggerall = statetype != A
Triggerall = enemynear(var(58)),statetype != A
Triggerall = enemynear(var(58)),statetype != L
Triggerall = enemynear(var(58)),stateno != [5120,5400]
triggerall = var(0)
triggerall = !var(8)
triggerall = P2dist X > 0
triggerall = (stateno = 100 || stateno = 105) && time > 1
trigger1 = P2bodydist X + (Vel x*-4)+(Const(Movement.stand.friction) *((4*(4-1)))/2) >= 31+(enemynear(var(58)),vel X*4) 
trigger1 = P2bodydist X + (Vel x*-4)+(Const(Movement.stand.friction) *((4*(4-1)))/2) <= 97+(enemynear(var(58)),vel X*4) 

[State -1, SonD中]
type = ChangeState
value = 10211
triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !Inguarddist
triggerall = statetype != A
Triggerall = enemynear(var(58)),statetype != A
Triggerall = enemynear(var(58)),statetype != L
Triggerall = enemynear(var(58)),stateno != [5120,5400]
triggerall = var(0)
triggerall = !var(8)
triggerall = P2dist X > 0
triggerall = (stateno = 100 || stateno = 105) && time > 1
trigger1 = P2bodydist X + (Vel x*-5)+(Const(Movement.stand.friction) *((5*(5-1)))/2) >= 65+(enemynear(var(58)),vel X*5) 
trigger1 = P2bodydist X + (Vel x*-5)+(Const(Movement.stand.friction) *((5*(5-1)))/2) <= 123+(enemynear(var(58)),vel X*5) 

[State -1, SonD強]
type = ChangeState
value = 10221
triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !Inguarddist
triggerall = statetype != A
Triggerall = enemynear(var(58)),statetype != A
Triggerall = enemynear(var(58)),statetype != L
Triggerall = enemynear(var(58)),stateno != [5120,5400]
triggerall = var(0)
triggerall = !var(8)
triggerall = P2dist X > 0
triggerall = (stateno = 100 || stateno = 105) && time > 1
trigger1 = P2bodydist X + (Vel x*-7)+(Const(Movement.stand.friction) *((7*(7-1)))/2) >= 41+(enemynear(var(58)),vel X*7) 
trigger1 = P2bodydist X + (Vel x*-7)+(Const(Movement.stand.friction) *((7*(7-1)))/2) <= 145+(enemynear(var(58)),vel X*7) 


[State -1,小ジャンプ・上]
type = ChangeState
value = 44
Triggerall = var(59) = [3,4]
Triggerall = var(57) = 2||var(57) = 1
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = alive
triggerall = !InGuarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),statetype != L
triggerall = enemynear(var(58)),Statetype != A
triggerall = enemynear(var(58)),Movetype != A
Triggerall = enemynear(var(58)),Anim != 5300
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = (enemynear(var(58)),stateno != [5120,5400])
Triggerall = enemynear(var(58)),stateno != [5000,5050]
Triggerall = enemynear(var(58)),stateno != [5296,5299]
triggerall = enemynear(var(58)),Stateno != [40,50]
Triggerall = P2dist X > 0
triggerall=Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = var(57) = 1
trigger1= enemynear(var(58)),facing=facing
Trigger1 = (enemynear(var(58)),stateno = [120,155])
trigger1 = P2bodydist X<=30
trigger1 = random <= 100
trigger1 = var(6) := 16

[State -1,小ジャンプ・前]
type = ChangeState
value = 42
Triggerall = var(59) = [3,4]
Triggerall = var(57) = 2||var(57) = 1
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = alive
triggerall = !InGuarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),statetype != L
triggerall = enemynear(var(58)),Statetype != A
triggerall = enemynear(var(58)),Movetype != A||enemynear(var(58)),facing = facing
Triggerall = enemynear(var(58)),Anim != 5300
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = (enemynear(var(58)),stateno != [5120,5400])
Triggerall = enemynear(var(58)),stateno != [5000,5050]
Triggerall = enemynear(var(58)),stateno != [5296,5299]
triggerall = enemynear(var(58)),Stateno != [40,50]
Triggerall = P2dist X > 0
triggerall = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X = [-1,3])|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X = [-3,1])
triggerall = enemynear(var(58)),facing!=facing&&(P2bodydist X=[120,170])||enemynear(var(58)),facing=facing&&(P2bodydist X=[80,120])
triggerall = random <= 50
triggerall=Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = enemynear(var(58)),statetype != L
Trigger1 = (enemynear(var(58)),stateno != [5100,5400])
trigger1 = var(6) := 16
Trigger2 = enemynear(var(58)),stateno = 5120&& enemynear(var(58)),Animtime = [-27,-17]
trigger2 = var(6) := 16

[State -1,小ジャンプ・後ろ]
type = ChangeState
value = 43
Triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = alive
triggerall = !InGuarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),Statetype != A
triggerall = enemynear(var(58)),Movetype != A
triggerall = enemynear(var(58)),numproj = 0
Triggerall = enemynear(var(58)),Anim != 5300
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = enemynear(var(58)),stateno != [5000,5050]
Triggerall = enemynear(var(58)),stateno != [5296,5299]
triggerall = enemynear(var(58)),Stateno != [40,50]
triggerall = var(57) = 2 && ((floor(helper(21000),RootDist X) >= 100 && facing = -1)||(floor(helper(25000),RootDist X) >= 100 && facing = 1)) || (var(57) != 2) && backEdgeBodyDist >= 175
Triggerall = P2dist X > 0
triggerall = random <= 50
triggerall=Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = enemynear(var(58)),statetype != L
Trigger1 = (enemynear(var(58)),stateno != [5100,5400])
trigger1 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X = [1,6])|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X = [-6,-1])
trigger1 = enemynear(var(58)),facing!=facing&&(P2bodydist X=[50,80])
trigger1 = var(6) := 16
trigger2 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X = [-1,3])|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X = [-3,1])
trigger2 = (enemynear(var(58)),stateno = [5100,5110])||(enemynear(var(58)),stateno = 5120)&&enemynear(var(58)),Animtime <= -10
trigger2 = P2bodydist X<=60
trigger2 = var(6) :=16
trigger3 = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X = [-1,3])|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X = [-3,1])
trigger3 = (enemynear(var(58)),stateno = [5121,5400])||EnemyNear(var(58)),statetype != A&&EnemyNear(var(58)),prevstateno = [5050,5110]
trigger3 = P2bodydist X<=60
trigger3 = var(6) :=16

[State -1,小ジャンプ・↑]
type = ChangeState
value = 44
Triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = alive
triggerall = !InGuarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),facing!=facing
triggerall = enemynear(var(58)),Statetype = A
triggerall = enemynear(var(58)),Movetype != A
triggerall = enemynear(var(58)),numproj = 0
Triggerall = enemynear(var(58)),Anim != 5300
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = enemynear(var(58)),stateno != [5000,5050]
Triggerall = enemynear(var(58)),stateno != [5296,5299]
triggerall = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X = [1,6])|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X = [-6,-1])
Triggerall = P2dist X > 0
triggerall = random <= 40
triggerall=Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X>=40+enemynear(var(58)),Vel X*13
trigger1 = P2bodydist X<=60+enemynear(var(58)),Vel X*13
trigger1 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*13)+(enemynear(var(58)),Const(Movement.Yaccel) *((13*(13-1)))/2) <= -5
trigger1 =P2Dist Y + (enemynear(var(58)),Vel y*13)+(enemynear(var(58)),Const(Movement.Yaccel) *((13*(13-1)))/2) = [-40,-5]
trigger1 = var(6) :=16
trigger2 = P2bodydist X>=40+enemynear(var(58)),Vel X*14
trigger2 = P2bodydist X<=60+enemynear(var(58)),Vel X*14
trigger2 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*14)+(enemynear(var(58)),Const(Movement.Yaccel) *((14*(14-1)))/2) <= -5
trigger2 =P2Dist Y + (enemynear(var(58)),Vel y*14)+(enemynear(var(58)),Const(Movement.Yaccel) *((14*(14-1)))/2) = [-40,-5]
trigger2 = var(6) :=16
trigger3 = P2bodydist X>=40+enemynear(var(58)),Vel X*15
trigger3 = P2bodydist X<=60+enemynear(var(58)),Vel X*15
trigger3 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),Const(Movement.Yaccel) *((15*(15-1)))/2) <= -5
trigger3 =P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),Const(Movement.Yaccel) *((15*(15-1)))/2) = [-40,-5]
trigger3 = var(6) :=16
trigger4 = P2bodydist X>=40+enemynear(var(58)),Vel X*16
trigger4 = P2bodydist X<=60+enemynear(var(58)),Vel X*16
trigger4 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*16)+(enemynear(var(58)),Const(Movement.Yaccel) *((16*(16-1)))/2) <= -5
trigger4 =P2Dist Y + (enemynear(var(58)),Vel y*16)+(enemynear(var(58)),Const(Movement.Yaccel) *((16*(16-1)))/2) = [-40,-5]
trigger4 = var(6) :=16
trigger5 = P2bodydist X>=40+enemynear(var(58)),Vel X*17
trigger5 = P2bodydist X<=60+enemynear(var(58)),Vel X*17
trigger5 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*17)+(enemynear(var(58)),Const(Movement.Yaccel) *((17*(17-1)))/2) <= -5
trigger5 =P2Dist Y + (enemynear(var(58)),Vel y*17)+(enemynear(var(58)),Const(Movement.Yaccel) *((17*(17-1)))/2) = [-40,-5]
trigger5 = var(6) :=16
trigger6 = P2bodydist X>=40+enemynear(var(58)),Vel X*18
trigger6 = P2bodydist X<=60+enemynear(var(58)),Vel X*18
trigger6 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*18)+(enemynear(var(58)),Const(Movement.Yaccel) *((18*(18-1)))/2) <= -5
trigger6 =P2Dist Y + (enemynear(var(58)),Vel y*18)+(enemynear(var(58)),Const(Movement.Yaccel) *((18*(18-1)))/2) = [-40,-5]
trigger6 = var(6) :=16
trigger7 = P2bodydist X>=40+enemynear(var(58)),Vel X*19
trigger7 = P2bodydist X<=60+enemynear(var(58)),Vel X*19
trigger7 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*19)+(enemynear(var(58)),Const(Movement.Yaccel) *((19*(19-1)))/2) <= -5
trigger7 =P2Dist Y + (enemynear(var(58)),Vel y*19)+(enemynear(var(58)),Const(Movement.Yaccel) *((19*(19-1)))/2) = [-40,-5]
trigger7 = var(6) :=16
trigger8 = P2bodydist X>=40+enemynear(var(58)),Vel X*20
trigger8 = P2bodydist X<=60+enemynear(var(58)),Vel X*20
trigger8 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) <= -5
trigger8 =P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) = [-40,-5]
trigger8 = var(6) :=16

[State -1,小ジャンプ・後ろ]
type = ChangeState
value = 43
Triggerall = var(59) =[3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = alive
triggerall = !InGuarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),facing!=facing
triggerall = enemynear(var(58)),Statetype = A
triggerall = enemynear(var(58)),Movetype != A
triggerall = enemynear(var(58)),numproj = 0
Triggerall = enemynear(var(58)),Anim != 5300
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = enemynear(var(58)),stateno != [5000,5050]
Triggerall = enemynear(var(58)),stateno != [5296,5299]
triggerall = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X = [1,6])|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X = [-6,-1])
triggerall = var(57) = 2 && ((floor(helper(21000),RootDist X) >= 100 && facing = -1)||(floor(helper(25000),RootDist X) >= 100 && facing = 1)) || (var(57) != 2) && backEdgeBodyDist >= 175
Triggerall = P2dist X > 0
triggerall = random <= 40
triggerall=Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X>=40+enemynear(var(58)),Vel X*13+(-2.4)*4
trigger1 = P2bodydist X<=60+enemynear(var(58)),Vel X*13+(-2.4)*4
trigger1 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*13)+(enemynear(var(58)),Const(Movement.Yaccel) *((13*(13-1)))/2) <= -5
trigger1 =P2Dist Y + (enemynear(var(58)),Vel y*13)+(enemynear(var(58)),Const(Movement.Yaccel) *((13*(13-1)))/2) = [-40,-5]
trigger1 = var(6) :=16
trigger2 = P2bodydist X>=40+enemynear(var(58)),Vel X*14+(-2.4)*5
trigger2 = P2bodydist X<=60+enemynear(var(58)),Vel X*14+(-2.4)*5
trigger2 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*14)+(enemynear(var(58)),Const(Movement.Yaccel) *((14*(14-1)))/2) <= -5
trigger2 =P2Dist Y + (enemynear(var(58)),Vel y*14)+(enemynear(var(58)),Const(Movement.Yaccel) *((14*(14-1)))/2) = [-40,-5]
trigger2 = var(6) :=16
trigger3 = P2bodydist X>=40+enemynear(var(58)),Vel X*15+(-2.4)*6
trigger3 = P2bodydist X<=60+enemynear(var(58)),Vel X*15+(-2.4)*6
trigger3 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),Const(Movement.Yaccel) *((15*(15-1)))/2) <= -5
trigger3 =P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),Const(Movement.Yaccel) *((15*(15-1)))/2) = [-40,-5]
trigger3 = var(6) :=16
trigger4 = P2bodydist X>=40+enemynear(var(58)),Vel X*16+(-2.4)*7
trigger4 = P2bodydist X<=60+enemynear(var(58)),Vel X*16+(-2.4)*7
trigger4 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*16)+(enemynear(var(58)),Const(Movement.Yaccel) *((16*(16-1)))/2) <= -5
trigger4 =P2Dist Y + (enemynear(var(58)),Vel y*16)+(enemynear(var(58)),Const(Movement.Yaccel) *((16*(16-1)))/2) = [-40,-5]
trigger4 = var(6) :=16
trigger5 = P2bodydist X>=40+enemynear(var(58)),Vel X*17+(-2.4)*8
trigger5 = P2bodydist X<=60+enemynear(var(58)),Vel X*17+(-2.4)*8
trigger5 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*17)+(enemynear(var(58)),Const(Movement.Yaccel) *((17*(17-1)))/2) <= -5
trigger5 =P2Dist Y + (enemynear(var(58)),Vel y*17)+(enemynear(var(58)),Const(Movement.Yaccel) *((17*(17-1)))/2) = [-40,-5]
trigger5 = var(6) :=16
trigger6 = P2bodydist X>=40+enemynear(var(58)),Vel X*18+(-2.4)*9
trigger6 = P2bodydist X<=60+enemynear(var(58)),Vel X*18+(-2.4)*9
trigger6 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*18)+(enemynear(var(58)),Const(Movement.Yaccel) *((18*(18-1)))/2) <= -5
trigger6 =P2Dist Y + (enemynear(var(58)),Vel y*18)+(enemynear(var(58)),Const(Movement.Yaccel) *((18*(18-1)))/2) = [-40,-5]
trigger6 = var(6) :=16
trigger7 = P2bodydist X>=40+enemynear(var(58)),Vel X*19+(-2.4)*10
trigger7 = P2bodydist X<=60+enemynear(var(58)),Vel X*19+(-2.4)*10
trigger7 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*19)+(enemynear(var(58)),Const(Movement.Yaccel) *((19*(19-1)))/2) <= -5
trigger7 =P2Dist Y + (enemynear(var(58)),Vel y*19)+(enemynear(var(58)),Const(Movement.Yaccel) *((19*(19-1)))/2) = [-40,-5]
trigger7 = var(6) :=16
trigger8 = P2bodydist X>=40+enemynear(var(58)),Vel X*20+(-2.4)*11
trigger8 = P2bodydist X<=60+enemynear(var(58)),Vel X*20+(-2.4)*11
trigger8 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) <= -5
trigger8 =P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) =[-40,-5]
trigger8 = var(6) :=16


[State -1,ジャンプ・↑]
type = ChangeState
value = 44
Triggerall = var(59) =[3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = alive
triggerall = !InGuarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),facing!=facing
triggerall = enemynear(var(58)),Statetype = A
triggerall = enemynear(var(58)),Movetype != A
triggerall = enemynear(var(58)),numproj = 0
Triggerall = enemynear(var(58)),Anim != 5300
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = enemynear(var(58)),stateno != [5000,5050]
Triggerall = enemynear(var(58)),stateno != [5296,5299]
triggerall = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X = [1,6])|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X = [-6,-1])
Triggerall = P2dist X > 0
triggerall = random <= 40
triggerall=Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X>=40+enemynear(var(58)),Vel X*13
trigger1 = P2bodydist X<=60+enemynear(var(58)),Vel X*13
trigger1 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*13)+(enemynear(var(58)),Const(Movement.Yaccel) *((13*(13-1)))/2) <= -5
trigger1 =P2Dist Y + (enemynear(var(58)),Vel y*13)+(enemynear(var(58)),Const(Movement.Yaccel) *((13*(13-1)))/2) = [-60,-30]
trigger1 = var(6) :=0||1
trigger2 = P2bodydist X>=40+enemynear(var(58)),Vel X*14
trigger2 = P2bodydist X<=60+enemynear(var(58)),Vel X*14
trigger2 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*14)+(enemynear(var(58)),Const(Movement.Yaccel) *((14*(14-1)))/2) <= -5
trigger2 =P2Dist Y + (enemynear(var(58)),Vel y*14)+(enemynear(var(58)),Const(Movement.Yaccel) *((14*(14-1)))/2) =[-60,-30]
trigger2 = var(6) :=0||1
trigger3 = P2bodydist X>=40+enemynear(var(58)),Vel X*15
trigger3 = P2bodydist X<=60+enemynear(var(58)),Vel X*15
trigger3 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),Const(Movement.Yaccel) *((15*(15-1)))/2) <= -5
trigger3 =P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),Const(Movement.Yaccel) *((15*(15-1)))/2) =[-60,-30]
trigger3 = var(6) :=0||1
trigger4 = P2bodydist X>=40+enemynear(var(58)),Vel X*16
trigger4 = P2bodydist X<=60+enemynear(var(58)),Vel X*16
trigger4 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*16)+(enemynear(var(58)),Const(Movement.Yaccel) *((16*(16-1)))/2) <= -5
trigger4 =P2Dist Y + (enemynear(var(58)),Vel y*16)+(enemynear(var(58)),Const(Movement.Yaccel) *((16*(16-1)))/2) = [-60,-30]
trigger4 = var(6) :=0||1
trigger5 = P2bodydist X>=40+enemynear(var(58)),Vel X*17
trigger5 = P2bodydist X<=60+enemynear(var(58)),Vel X*17
trigger5 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*17)+(enemynear(var(58)),Const(Movement.Yaccel) *((17*(17-1)))/2) <= -5
trigger5 =P2Dist Y + (enemynear(var(58)),Vel y*17)+(enemynear(var(58)),Const(Movement.Yaccel) *((17*(17-1)))/2) = [-60,-30]
trigger5 = var(6) :=0||1
trigger6 = P2bodydist X>=40+enemynear(var(58)),Vel X*18
trigger6 = P2bodydist X<=60+enemynear(var(58)),Vel X*18
trigger6 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*18)+(enemynear(var(58)),Const(Movement.Yaccel) *((18*(18-1)))/2) <= -5
trigger6 =P2Dist Y + (enemynear(var(58)),Vel y*18)+(enemynear(var(58)),Const(Movement.Yaccel) *((18*(18-1)))/2) = [-60,-30]
trigger6 = var(6) :=0||1
trigger7 = P2bodydist X>=40+enemynear(var(58)),Vel X*19
trigger7 = P2bodydist X<=60+enemynear(var(58)),Vel X*19
trigger7 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*19)+(enemynear(var(58)),Const(Movement.Yaccel) *((19*(19-1)))/2) <= -5
trigger7 =P2Dist Y + (enemynear(var(58)),Vel y*19)+(enemynear(var(58)),Const(Movement.Yaccel) *((19*(19-1)))/2) = [-60,-30]
trigger7 = var(6) :=0||1
trigger8 = P2bodydist X>=40+enemynear(var(58)),Vel X*20
trigger8 = P2bodydist X<=60+enemynear(var(58)),Vel X*20
trigger8 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) <= -5
trigger8 =P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) = [-60,-30]
trigger8 = var(6) :=0||1

[State -1,ジャンプ・後ろ]
type = ChangeState
value = 43
triggerall = var(59) = [3,4]
Triggerall = var(57) = 2
triggerall = var(49) = 1
triggerall = !var(0)
triggerall = alive
triggerall = !InGuarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = enemynear(var(58)),facing!=facing
triggerall = enemynear(var(58)),Statetype = A
triggerall = enemynear(var(58)),Movetype != A
triggerall = enemynear(var(58)),numproj = 0
Triggerall = enemynear(var(58)),Anim != 5300
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = enemynear(var(58)),stateno != [5000,5050]
Triggerall = enemynear(var(58)),stateno != [5296,5299]
triggerall = (enemynear(var(58)),facing != facing&&enemynear(var(58)),Vel X = [1,6])|| (enemynear(var(58)),facing = facing&&enemynear(var(58)),Vel X = [-6,-1])
triggerall = var(57) = 2 && ((floor(helper(21000),RootDist X) >= 100 && facing = -1)||(floor(helper(25000),RootDist X) >= 100 && facing = 1)) || (var(57) != 2) && backEdgeBodyDist >= 175
Triggerall = P2dist X > 0
triggerall = random <= 40
triggerall=Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X>=40+enemynear(var(58)),Vel X*13+(-2.4)*4
trigger1 = P2bodydist X<=60+enemynear(var(58)),Vel X*13+(-2.4)*4
trigger1 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*13)+(enemynear(var(58)),Const(Movement.Yaccel) *((13*(13-1)))/2) <= -5
trigger1 =P2Dist Y + (enemynear(var(58)),Vel y*13)+(enemynear(var(58)),Const(Movement.Yaccel) *((13*(13-1)))/2) = [-60,-30]
trigger1 = var(6) :=0||1
trigger2 = P2bodydist X>=40+enemynear(var(58)),Vel X*14+(-2.4)*5
trigger2 = P2bodydist X<=60+enemynear(var(58)),Vel X*14+(-2.4)*5
trigger2 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*14)+(enemynear(var(58)),Const(Movement.Yaccel) *((14*(14-1)))/2) <= -5
trigger2 =P2Dist Y + (enemynear(var(58)),Vel y*14)+(enemynear(var(58)),Const(Movement.Yaccel) *((14*(14-1)))/2) = [-60,-30]
trigger2 = var(6) :=0||1
trigger3 = P2bodydist X>=40+enemynear(var(58)),Vel X*15+(-2.4)*6
trigger3 = P2bodydist X<=60+enemynear(var(58)),Vel X*15+(-2.4)*6
trigger3 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),Const(Movement.Yaccel) *((15*(15-1)))/2) <= -5
trigger3 =P2Dist Y + (enemynear(var(58)),Vel y*15)+(enemynear(var(58)),Const(Movement.Yaccel) *((15*(15-1)))/2) = [-60,-30]
trigger3 = var(6) :=0||1
trigger4 = P2bodydist X>=40+enemynear(var(58)),Vel X*16+(-2.4)*7
trigger4 = P2bodydist X<=60+enemynear(var(58)),Vel X*16+(-2.4)*7
trigger4 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*16)+(enemynear(var(58)),Const(Movement.Yaccel) *((16*(16-1)))/2) <= -5
trigger4 =P2Dist Y + (enemynear(var(58)),Vel y*16)+(enemynear(var(58)),Const(Movement.Yaccel) *((16*(16-1)))/2) = [-60,-30]
trigger4 = var(6) :=0||1
trigger5 = P2bodydist X>=40+enemynear(var(58)),Vel X*17+(-2.4)*8
trigger5 = P2bodydist X<=60+enemynear(var(58)),Vel X*17+(-2.4)*8
trigger5 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*17)+(enemynear(var(58)),Const(Movement.Yaccel) *((17*(17-1)))/2) <= -5
trigger5 =P2Dist Y + (enemynear(var(58)),Vel y*17)+(enemynear(var(58)),Const(Movement.Yaccel) *((17*(17-1)))/2) = [-60,-30]
trigger5 = var(6) :=0||1
trigger6 = P2bodydist X>=40+enemynear(var(58)),Vel X*18+(-2.4)*9
trigger6 = P2bodydist X<=60+enemynear(var(58)),Vel X*18+(-2.4)*9
trigger6 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*18)+(enemynear(var(58)),Const(Movement.Yaccel) *((18*(18-1)))/2) <= -5
trigger6 =P2Dist Y + (enemynear(var(58)),Vel y*18)+(enemynear(var(58)),Const(Movement.Yaccel) *((18*(18-1)))/2) = [-60,-30]
trigger6 = var(6) :=0||1
trigger7 = P2bodydist X>=40+enemynear(var(58)),Vel X*19+(-2.4)*10
trigger7 = P2bodydist X<=60+enemynear(var(58)),Vel X*19+(-2.4)*10
trigger7 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*19)+(enemynear(var(58)),Const(Movement.Yaccel) *((19*(19-1)))/2) <= -5
trigger7 =P2Dist Y + (enemynear(var(58)),Vel y*19)+(enemynear(var(58)),Const(Movement.Yaccel) *((19*(19-1)))/2) =[-60,-30]
trigger7 = var(6) :=0||1
trigger8 = P2bodydist X>=40+enemynear(var(58)),Vel X*20+(-2.4)*11
trigger8 = P2bodydist X<=60+enemynear(var(58)),Vel X*20+(-2.4)*11
trigger8 =enemynear(var(58)),pos y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) <= -5
trigger8 =P2Dist Y + (enemynear(var(58)),Vel y*20)+(enemynear(var(58)),Const(Movement.Yaccel) *((20*(20-1)))/2) = [-60,-30]
trigger8 = var(6) :=0||1

[State -1,ジャンプ・上]
type = ChangeState
value = 44
Triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = alive
triggerall = !InGuarddist
Triggerall = Statetype != A
Triggerall = EnemyNear(var(58)),Alive
triggerall = EnemyNear(var(58)),stateno <200000
triggerall = enemynear(var(58)),Movetype != A
Triggerall = P2dist X > 0
triggerall=Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = P2bodydist X = [30,80]
trigger1 = var(59)=2&&random<=20||var(59)=1&&command = "holdup"
trigger1 = var(6) :=16

[State -1,ジャンプ・前]
type = ChangeState
value = 42
Triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = alive
triggerall = !InGuarddist
Triggerall = Statetype != A
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = EnemyNear(var(58)),Alive
Triggerall = P2dist X > 0
triggerall = var(59)=2&&random<=20||var(59)=1&&command = "holdfwd"
triggerall=Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = enemynear(var(58)),statetype != A
trigger1 = P2bodydist X = [60,150]
trigger1 = var(6) :=16
trigger2 = enemynear(var(58)),statetype != A
trigger2 = P2bodydist X = [100,180]
trigger2 = var(6) :=0||1
trigger3 = P2bodydist X = [100,180]
trigger3 = enemynear(var(58)),statetype = A
trigger3 = enemynear(var(58)),Movetype != A
trigger3 = var(6) :=0||1

[State -1,小ジャンプ・後ろ]
type = ChangeState
value = 43
Triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = alive
triggerall = !InGuarddist
Triggerall = Statetype != A
triggerall = EnemyNear(var(58)),stateno <200000
Triggerall = EnemyNear(var(58)),Alive
Triggerall = P2dist X > 0
triggerall = var(59)=2&&random<=20||var(59)=1&&command = "holdfwd"
triggerall=Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = enemynear(var(58)),statetype != A
trigger1 = P2bodydist X = [40,80]
trigger1 = var(6) :=16
trigger2 = enemynear(var(58)),statetype != A
trigger2 = P2bodydist X = [40,80]
trigger2 = var(6) :=0||1
trigger3 = P2bodydist X <= 100
trigger3 = enemynear(var(58)),statetype = A
trigger3 = enemynear(var(58)),Movetype != A
trigger3 = var(6) :=0||1

[State -1, 回り込み]
type = ChangeState
value =300
Triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
Triggerall = var(49) = 1
triggerall = !var(0)
triggerall = !var(56)
triggerall = !var(8)
triggerall = alive
Triggerall = statetype != A
Triggerall = EnemyNear(var(58)),Alive
Triggerall = EnemyNear(var(58)),facing != facing
Triggerall = enemynear(var(58)),Movetype != H
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),stateno != [5120,5400]
triggerall = P2dist X > 0
triggerall=Ctrl||(stateno=[20,22])||(stateno=[120,131])||(prevstateno != [710,711])&&((stateno=151||stateno=153)&&Time>GetHitVar(ctrltime))
trigger1 = var(59) = 2
Trigger1 = EnemyNear(var(58)),Vel X >= -3
trigger1 = Random <= 1
trigger2 = var(59) = 1
trigger2 = Random <= 10

;===========================================================================
; 空中立ち回り
;===========================================================================

[State -1,空中通常強攻撃]
type = ChangeState
value = 620
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(0) 
triggerall = !var(8)
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype = A
Triggerall = enemynear(var(58)),statetype != L
triggerall = (enemynear(var(58)),stateno != [5120,5400])&&(enemynear(var(58)),stateno <= 200000)
Triggerall = P2dist X > 0
triggerall = ctrl
triggerall = Pos Y + (Vel y*5)+(Const(Movement.Yaccel) *((5*(5-1)))/2) <= -1
Trigger1 = enemynear(var(58)),statetype = A
Trigger1 = enemynear(var(58)),Movetype = A&&enemynear(var(58)),time >= 15||(enemynear(var(58)),stateno=[5000,5071])||(enemynear(var(58)),stateno=[4000,4001])
trigger1 = P2Dist Y + (enemynear(var(58)),Vel y*4)+(enemynear(var(58)),Const(Movement.Yaccel) *((4*(4-1)))/2) = [-40,70]
trigger1=enemynear(var(58)),facing!=facing&&P2bodydist X<=60+enemynear(var(58)),Vel X*4+vel X*4||enemynear(var(58)),facing=facing&&P2bodydist X<=50+enemynear(var(58)),Vel X*-4+vel X*4
Trigger2 = enemynear(var(58)),Movetype = A&&enemynear(var(58)),time >= 15||(enemynear(var(58)),stateno=[5000,5071])
trigger2 = Vel Y >= -10
Trigger2 = enemynear(var(58)),statetype != A
trigger2 = (Pos Y + (Vel y*5)+(Const(Movement.Yaccel) *((5*(5-1)))/2) = [-30,-10])&&random<=250||(Pos Y + (Vel y*5)+(Const(Movement.Yaccel) *((5*(5-1)))/2) = [-10,-1])
trigger2 = enemynear(var(58)),facing!=facing&&P2bodydist X<=60+vel X*5||enemynear(var(58)),facing=facing&&P2bodydist X<=50+vel X*5

[State -1,通常弱攻撃]
type = ChangeState
value = 600
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype = A
triggerall = Vel Y >= -10
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
triggerall = (enemynear(var(58)),stateno != [5120,5400])
Triggerall = P2dist X > 0
triggerall = ctrl
triggerall=enemynear(var(58)),facing!=facing&&P2bodydist X<=32+enemynear(var(58)),Vel X*4+vel X*4||enemynear(var(58)),facing=facing&&P2bodydist X<=22+enemynear(var(58)),Vel X*-4+vel X*4
Trigger1 = enemynear(var(58)),Movetype = A&&enemynear(var(58)),time >= 15
trigger1 = (Pos Y + (Vel y*4)+(Const(Movement.Yaccel) *((4*(4-1)))/2) = [-10,-1])

[State -1,空中S中攻撃]
type = ChangeState
value = 10610
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0) 
triggerall = !var(8)
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype = A
Triggerall = enemynear(var(58)),statetype != L
triggerall = (enemynear(var(58)),stateno != [5120,5400])
Triggerall = P2dist X > 0
triggerall = ctrl
triggerall = Pos Y + (Vel y*10)+(Const(Movement.Yaccel) *((10*(10-1)))/2) <= -1
Trigger1 = enemynear(var(58)),statetype = A
Trigger1 = enemynear(var(58)),Movetype = A&&enemynear(var(58)),time >= 15||(enemynear(var(58)),stateno=[5000,5071])||(enemynear(var(58)),stateno=[4000,4001])
trigger1 = enemynear(var(58)),Pos y + (enemynear(var(58)),Vel y*9)+(enemynear(var(58)),Const(Movement.Yaccel) *((9*(9-1)))/2)= [-20,5]
trigger1=enemynear(var(58)),facing!=facing&&P2bodydist X<=35+enemynear(var(58)),Vel X*9+vel X*9||enemynear(var(58)),facing=facing&&P2bodydist X<=25+enemynear(var(58)),Vel X*-9+vel X*9
Trigger2 = enemynear(var(58)),Movetype = A&&enemynear(var(58)),time >= 15||(enemynear(var(58)),stateno=[5000,5071])
Trigger2 = enemynear(var(58)),statetype != A
trigger2 = Vel Y >= -10
trigger2 = (Pos Y + (Vel y*10)+(Const(Movement.Yaccel) *((10*(10-1)))/2) = [-90,-10])&&random<=250||(Pos Y + (Vel y*10)+(Const(Movement.Yaccel) *((10*(10-1)))/2) = [-10,-1])
trigger2 = enemynear(var(58)),facing!=facing&&P2bodydist X<=35+vel X*10||enemynear(var(58)),facing=facing&&P2bodydist X<=25+vel X*10

[State -1,空中S強攻撃]
type = ChangeState
value = 10620
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0) 
triggerall = !var(8)
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype = A
triggerall = Vel Y >= -10
Triggerall = enemynear(var(58)),statetype != L
Triggerall = enemynear(var(58)),statetype != A
triggerall = (enemynear(var(58)),stateno != [5120,5400])
Triggerall = P2dist X > 0
triggerall = ctrl
triggerall = Pos Y + (Vel y*9)+(Const(Movement.Yaccel) *((9*(9-1)))/2) <= -1
Trigger1 = enemynear(var(58)),Movetype = A&&enemynear(var(58)),time >= 15||(enemynear(var(58)),stateno=[5000,5071])
Trigger1 = enemynear(var(58)),statetype != A
trigger1 = (Pos Y + (Vel y*9)+(Const(Movement.Yaccel) *((9*(9-1)))/2) = [-60,-10])&&random<=250||(Pos Y + (Vel y*9)+(Const(Movement.Yaccel) *((9*(9-1)))/2) = [-10,-1])
trigger1 = enemynear(var(58)),facing!=facing&&P2bodydist X<=48+vel X*9||enemynear(var(58)),facing=facing&&P2bodydist X<=38+vel X*9

[State -1,空中通常強攻撃]
type = ChangeState
value = 620
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(0) 
triggerall = !var(8)
triggerall = !InGuarddist
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype = A
Triggerall = enemynear(var(58)),Statetype = A
triggerall = (enemynear(var(58)),stateno != [5120,5400])&&(enemynear(var(58)),stateno <= 200000)||enemynear(var(58)),stateno = 5210 && enemynear(var(58)),time >= 12
Triggerall = P2dist X > 0
triggerall = ctrl
triggerall = Pos Y + (Vel y*4)+(Const(Movement.Yaccel) *((4*(4-1)))/2) <= -1
triggerall = P2Dist Y + (enemynear(var(58)),Vel y*4)+(enemynear(var(58)),Const(Movement.Yaccel) *((4*(4-1)))/2) = [-40,70]
trigger1=enemynear(var(58)),facing!=facing&&P2bodydist X<=60+enemynear(var(58)),Vel X*4+vel X*4||enemynear(var(58)),facing=facing&&P2bodydist X<=50+enemynear(var(58)),Vel X*-4+vel X*4

[State -1,空中通常強攻撃]
type = ChangeState
value = 620
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(0) 
triggerall = !var(8)
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype = A
triggerall = Vel Y >= -10
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
triggerall = (enemynear(var(58)),stateno != [5120,5400])&&(enemynear(var(58)),stateno < 200000)
Triggerall = P2dist X > 0
triggerall = ctrl
triggerall=enemynear(var(58)),facing!=facing&&P2bodydist X<=60+enemynear(var(58)),Vel X*5+vel X*5||enemynear(var(58)),facing=facing&&P2bodydist X<=50+enemynear(var(58)),Vel X*-5+vel X*5
trigger1 = !InGuarddist
trigger1 = (Pos Y + (Vel y*5)+(Const(Movement.Yaccel) *((5*(5-1)))/2) = [-30,-10])&&random<=180||(Pos Y + (Vel y*5)+(Const(Movement.Yaccel) *((5*(5-1)))/2) = [-10,-1])
trigger2 = enemynear(var(58)),Movetype = A
trigger2 = enemynear(var(58)),Time <= 5
trigger2 = (Pos Y + (Vel y*5)+(Const(Movement.Yaccel) *((5*(5-1)))/2) = [-50,-1])&&random<=100
trigger3 = enemynear(var(58)),Movetype = A
trigger3 = enemynear(var(58)),statetype = C
trigger3 = (Pos Y + (Vel y*5)+(Const(Movement.Yaccel) *((5*(5-1)))/2) = [-30,-1])

[State -1,通常弱攻撃]
type = ChangeState
value = 600
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype = A
triggerall = Vel Y >= -10
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
triggerall = (enemynear(var(58)),stateno != [5120,5400])
Triggerall = P2dist X > 0
triggerall = ctrl
triggerall=enemynear(var(58)),facing!=facing&&P2bodydist X<=32+enemynear(var(58)),Vel X*4+vel X*4||enemynear(var(58)),facing=facing&&P2bodydist X<=22+enemynear(var(58)),Vel X*-4+vel X*4
trigger1 = enemynear(var(58)),Movetype = A
trigger1 = enemynear(var(58)),Time <= 5
trigger1 = (Pos Y + (Vel y*4)+(Const(Movement.Yaccel) *((4*(4-1)))/2) = [-50,-1])&&random<=100
trigger2 = enemynear(var(58)),Movetype = A
trigger2 = enemynear(var(58)),statetype = C
trigger2 = (Pos Y + (Vel y*4)+(Const(Movement.Yaccel) *((4*(4-1)))/2) = [-30,-1])

[State -1,通常弱攻撃]
type = ChangeState
value = 600
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype = A
triggerall = Vel Y >= -10
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
triggerall = (enemynear(var(58)),stateno != [5120,5400])
Triggerall = P2dist X <= 0
triggerall = (Pos Y + (Vel y*4)+(Const(Movement.Yaccel) *((4*(4-1)))/2) = [-70,-1])
triggerall = ctrl
Trigger1 = enemynear(var(58)),Movetype != A
trigger1=P2bodydist X>=-25+vel X*4
Trigger2 = enemynear(var(58)),Movetype != A
trigger2=P2bodydist X<=0+vel X*4
Trigger3 = enemynear(var(58)),Movetype = A
trigger3=P2bodydist X>=-25+(vel X*4)+enemynear(var(58)),vel X*4
Trigger4 = enemynear(var(58)),Movetype = A
trigger4=P2bodydist X<=0+(vel X*4)+enemynear(var(58)),vel X*4

[State -1,空中S中攻撃]
type = ChangeState
value = 10610
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0) 
triggerall = !var(8)
triggerall = !InGuarddist
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype = A
triggerall = Vel Y >= -10
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
triggerall = (enemynear(var(58)),stateno != [5120,5400])||enemynear(var(58)),stateno = 5120&&enemynear(var(58)),Animtime >= -7
Triggerall = P2dist X > 0
triggerall = ctrl
trigger1 = (Pos Y + (Vel y*10)+(Const(Movement.Yaccel) *((10*(10-1)))/2) = [-90,-10])&&random<=150||(Pos Y + (Vel y*10)+(Const(Movement.Yaccel) *((10*(10-1)))/2) = [-10,-1])
trigger1 = enemynear(var(58)),facing!=facing&&P2bodydist X<=35+vel X*10||enemynear(var(58)),facing=facing&&P2bodydist X<=25+vel X*10


[State -1,空中S強攻撃]
type = ChangeState
value = 10620
Triggerall = var(59) = [3,4]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0) 
triggerall = !var(8)
triggerall = !InGuarddist
Triggerall = Roundstate = 2
triggerall = alive
triggerall = Vel Y >= -10
Triggerall = Statetype = A
Triggerall = enemynear(var(58)),Statetype != L
Triggerall = enemynear(var(58)),Statetype != A
triggerall = (enemynear(var(58)),stateno != [5120,5400])||enemynear(var(58)),stateno = 5120&&enemynear(var(58)),Animtime >= -5
Triggerall = P2dist X > 0
triggerall = ctrl
trigger1 = (Pos Y + (Vel y*9)+(Const(Movement.Yaccel) *((9*(9-1)))/2) = [-70,-10])&&random<=150||(Pos Y + (Vel y*9)+(Const(Movement.Yaccel) *((9*(9-1)))/2) = [-10,-1])
trigger1=enemynear(var(58)),facing!=facing&&P2bodydist X<=48+vel X*9||enemynear(var(58)),facing=facing&&P2bodydist X<=38+vel X*9

[State -1,空中弱パンチ]
type = ChangeState
value = 600
Triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype = A
Triggerall = P2dist X > 0
triggerall = P2bodydist X <= 50
triggerall = ctrl
triggerall = !InGuarddist&&random <= var(59)*100||InGuarddist&&random <= 20/var(59)
Trigger1 = enemynear(var(58)),Statetype = A
trigger1 = P2bodydist Y = [-20,50]
Trigger2 = enemynear(var(58)),Statetype != A
trigger2 = vel Y >= 0
trigger2 = P2bodydist Y <= 60

[State -1,空中弱パンチ]
type = ChangeState
value = 610
Triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(0)
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype = A
Triggerall = P2dist X > 0
triggerall = P2bodydist X <= 60
triggerall = ctrl
triggerall = !InGuarddist&&random <= var(59)*100||InGuarddist&&random <= 20/var(59)
Trigger1 = enemynear(var(58)),Statetype = A
trigger1 = P2bodydist Y = [-60,20]
Trigger2 = enemynear(var(58)),Statetype != A
trigger2 = vel Y >= 0
trigger2 = P2bodydist Y <= 60

[State -1,空中弱パンチ]
type = ChangeState
value = 620
Triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = !var(0)
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype = A
Triggerall = P2dist X > 0
triggerall = P2bodydist X <= 80
triggerall = ctrl
triggerall = !InGuarddist&&random <= var(59)*100||InGuarddist&&random <= 20/var(59)
Trigger1 = enemynear(var(58)),Statetype = A
trigger1 = P2bodydist Y = [-40,70]
Trigger2 = enemynear(var(58)),Statetype != A
trigger2 = vel Y >= 0
trigger2 = P2bodydist Y <= 70

[State -1,空中弱パンチ]
type = ChangeState
value = 10610
Triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype = A
Triggerall = P2dist X > 0
triggerall = P2bodydist X <= 50
triggerall = ctrl
triggerall = !InGuarddist&&random <= var(59)*100||InGuarddist&&random <= 20/var(59)
Trigger1 = enemynear(var(58)),Statetype != A

[State -1,空中弱パンチ]
type = ChangeState
value = 10620
Triggerall = var(59) = [1,2]
Triggerall = var(57) >= 0
triggerall = var(49) = 1
triggerall = var(0)
Triggerall = Roundstate = 2
triggerall = alive
Triggerall = Statetype = A
Triggerall = P2dist X > 0
triggerall = P2bodydist X <= 60
triggerall = ctrl
triggerall = !InGuarddist&&random <= var(59)*100||InGuarddist&&random <= 20/var(59)
Trigger1 = enemynear(var(58)),Statetype != A

;===========================================================================
;AI起動用ヘルパー(CPU起動)
;===========================================================================
[StateDef 11000]
anim=0
ctrl=0

[State 825]
type = assertspecial
Trigger1 = 1
flag = invisible
flag2= noshadow

[State 825]
type = nothitby
Trigger1 = 1
value = SCA

[State 10000,間違いで本体が来たら立ちへ移行]
type=selfstate
Trigger1=!ishelper
value=0

[State 10000,プレイヤー判定]
type=varset
Trigger1=command="a"&&root,command="a"
Trigger2=command="b"&&root,command="b"
Trigger3=command="c"&&root,command="c"
Trigger4=command="x"&&root,command="x"
Trigger5=command="y"&&root,command="y"
Trigger6=command="z"&&root,command="z"
Trigger7=command="start"&&root,command="start"
var(59)=-1

[State 10000,プレイヤー判定]
type=parentvarset
Trigger1=command="a"&&root,command="a"
Trigger2=command="b"&&root,command="b"
Trigger3=command="c"&&root,command="c"
Trigger4=command="x"&&root,command="x"
Trigger5=command="y"&&root,command="y"
Trigger6=command="z"&&root,command="z"
Trigger7=command="start"&&root,command="start"
var(59)=-1

[State 10000,立ったら消失]
Type = DestroySelf
TriggerAll = isHelper
Trigger1 = root,var(59)!=0||var(59)=-1
Trigger2=command="a"&&root,command="a"
Trigger3=command="b"&&root,command="b"
Trigger4=command="c"&&root,command="c"
Trigger5=command="x"&&root,command="x"
Trigger6=command="y"&&root,command="y"
Trigger7=command="z"&&root,command="z"
Trigger8=command="start"&&root,command="start"

[State 10000,ﾌﾗｸﾞON]
type=varset
Triggerall=var(59)!=-1
Trigger1=root,command="a"
Trigger2=root,command="b"
Trigger3=root,command="c"
Trigger4=root,command="x"
Trigger5=root,command="y"
Trigger6=root,command="z"
Trigger7=root,command="start"
var(59)=1

;===========================================================================
;画面左右端判定ヘルパー
;===========================================================================
;ステージ右端検出用
[Statedef 21000]
Type = A
Ctrl = 0
Anim = 0
Velset = -10,0
Movetype = I
Physics = N
Sprpriority = 1

[State 20000]
type = assertspecial
Trigger1 = 1
flag = invisible
flag2= noshadow

[State 20000]
type = nothitby
Trigger1 = 1
value = SCA

[State 20000,間違いで本体が来たら立ちへ移行]
type=selfstate
Trigger1=!ishelper
value=0

[State 21000]
type = Projectile
Trigger1 = time = 0
velocity = -10,0
projID = 21001
projhits = 9999
projpriority = 9999
projanim = 0
offset = 0,0
projstagebound = 0
Projedgebound = 100000
projremove = 0
Projremovetime = -1
supermovetime = 9999
pausemovetime = 9999

[State 21000]
type = velset
Trigger1 = Root,NumProjID(21001) = 0
Trigger1 = time > 0
x = 0
y = 0

;ステージ左端検出用
[Statedef 25000]
Type = A
Ctrl = 0
Anim = 0
Velset = -10,0
Movetype = I
Physics = N
Sprpriority = 1

[State 25000]
type = assertspecial
Trigger1 = 1
flag = invisible
flag2= noshadow

[State 25000]
type = nothitby
Trigger1 = 1
value = SCA

[State 25000,間違いで本体が来たら立ちへ移行]
type=selfstate
Trigger1=!ishelper
value=0

[State 25000]
type = Projectile
Trigger1 = time = 0
velocity = -10,0
projID = 20002
projhits = 9999
projpriority = 9999
projanim = 0
offset = 0,0
projstagebound = 0
Projedgebound = 100000
projremove = 0
Projremovetime = -1
supermovetime = 9999
pausemovetime = 9999

[State 25000]
type = velset
Trigger1 = Root,NumProjID(20002) = 0
Trigger1 = time > 0
x = 0
y = 0

