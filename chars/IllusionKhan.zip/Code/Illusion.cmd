[Remap]
x = x      ;�w�{�^���̓��͔�������ۂɉ����{�^���Ɋ��蓖�Ă�B
y = y      ;�x�{�^���@�@�@�@�@�@�@�@�@�V
z = z      ;�y�{�^���@�@�@�@�@�@�@�@�@�V
a = a      ;�`�{�^���@�@�@�@�@�@�@�@�@�V
b = b      ;�a�{�^���@�@�@�@�@�@�@�@�@�V
c = c      ;�b�{�^���@�@�@�@�@�@�@�@�@�V
s = s      ;�X�^�[�g�{�^���@�@�@�@�@�@�V

;-| Default Values |-------------------------------------------------------
[Defaults]
command.time = 16
command.buffer.time = 2
;-| ���K�E�Z |-----------------------------------------------------------------
[Command]
name = "spinspin"
command = ~D,DF,F,D,DF,F,a
time = 30
buffer.time = 5
[Command]
name = "spinspin"
command = ~D,DF,F,D,DF,F,~a
time = 30
buffer.time = 5
[Command]
name = "236aa"
command = ~D,DF,F,x+y
time = 16
buffer.time = 5
[Command]
name = "236aa"
command = ~D,DF,F,y+z
time = 16
buffer.time = 5
[Command]
name = "236aa"
command = ~D,DF,F,x+z
time = 16
buffer.time = 5
[Command]
name = "214aa"
command = ~D,DB,B,x+y
time = 16
buffer.time = 5
[Command]
name = "214aa"
command = ~D,DB,B,y+z
time = 16
buffer.time = 5
[Command]
name = "214aa"
command = ~D,DB,B,x+z
time = 16
buffer.time = 5
[command]
name = "28aa"
command = ~30$D, $U, x+y
time = 30
buffer.time = 5
[command]
name = "28aa"
command = ~30$D, $U, y+z
time = 30
buffer.time = 5
[command]
name = "28aa"
command = ~30$D, $U, x+z
time = 30
buffer.time = 5
[command]
name = "28aa"
command = ~30$D, $U, b
time = 30
buffer.time = 5
[command]
name = "28aa"
command = ~30$D, $U, ~b
time = 30
buffer.time = 5
[Command]
name = "dem"
command = ~D,DB,B,a
time = 16
buffer.time = 5
[Command]
name = "dem"
command = ~D,DB,B,~a
time = 16
buffer.time = 5
;------------------------------------------------------------------------------
;-| �K�E�Z |-------------------------------------------------------------------
[Command]
name = "46x"
command = ~25$B,$F, x
time = 12
buffer.time = 5

[Command]
name = "46x"
command = ~25$B,$F,~x
time = 12
buffer.time = 5

[Command]
name = "46y"
command = ~25$B,$F, y
time = 12
buffer.time = 5

[Command]
name = "46y"
command = ~25$B,$F, ~y
time = 12
buffer.time = 5

[Command]
name = "46z"
command = ~25$B,$F, z
time = 12
buffer.time = 5

[Command]
name = "46z"
command = ~25$B,$F, ~z
time = 12
buffer.time = 5

[Command]
name = "46b"
command = ~25$B,$F, b
time = 12
buffer.time = 5

[Command]
name = "46b"
command = ~25$B,$F, ~b
time = 12
buffer.time = 5

[Command]
name = "623x"
command = ~F,D,DF,x
time = 12
buffer.time = 5

[Command]
name = "623x"
command = ~F,D,DF,~x
time = 12
buffer.time = 5

[Command]
name = "623y"
command = ~F,D,DF,y
time = 12
buffer.time = 5

[Command]
name = "623y"
command = ~F,D,DF,~y
time = 12
buffer.time = 5

[Command]
name = "623z"
command = ~F,D,DF,z
time = 12
buffer.time = 5

[Command]
name = "623z"
command = ~F,D,DF,~z
time = 12
buffer.time = 5

[Command]
name = "623b"
command = ~F,D,DF,b
time = 12
buffer.time = 5

[Command]
name = "623b"
command = ~F,D,DF,~b
time = 12
buffer.time = 5

[Command]
name = "623a"
command = ~B,D,DB,a
time = 15
buffer.time = 5
[Command]
name = "623a"
command = ~B,D,DB,~a
time = 15
buffer.time = 5
[Command]
name = "22a"
command = ~D, D, a 
time = 15
buffer.time = 5
[Command]
name = "22a"
command = ~D, D, ~a 
time = 15
buffer.time = 5
[Command]
name = "214x"
command = ~D, DB, B, x
time = 12
buffer.time = 5
[Command]
name = "214x"
command = ~D, DB, B, ~x
time = 12
buffer.time = 5
[Command]
name = "214y"
command = ~D, DB, B, y
time = 12
buffer.time = 5
[Command]
name = "214y"
command = ~D, DB, B, ~y
time = 12
buffer.time = 5
[Command]
name = "214z"
command = ~D, DB, B, z
time = 12
buffer.time = 5
[Command]
name = "214z"
command = ~D, DB, B, ~z
time = 12
buffer.time = 5
[Command]
name = "214b"
command = ~D, DB, B, b
time = 12
buffer.time = 5
[Command]
name = "214b"
command = ~D, DB, B, ~b
time = 12
buffer.time = 5
[Command]
name = "Sonattack"
command = ~D,DF,F,a
time = 12
buffer.time = 5
[Command]
name = "Sonattack"
command = ~D,DF,F,~a
time = 12
buffer.time = 5
[Command]
name = "236b"
command = ~D,DF,F,b
time = 12
buffer.time = 5
[Command]
name = "236b"
command = ~D,DF,F,~b
time = 12
buffer.time = 5
[Command]
name = "214b"
command = ~D,DB,B,b
time = 12
buffer.time = 5
[Command]
name = "214b"
command = ~D,DB,B,~b
time = 12
buffer.time = 5

;------------------------------------------------------------------------------
;-| �L�[�Q��A������ |---------------------------------------------------------

[Command]
name = "FF"
command = F,F
time = 10


[Command]
name = "BB"
command = B,B
time = 10

[Command]
name = "longjump"
command = $D, $U
time = 10

;------------------------------------------------------------------------------
;-| �������� |-----------------------------------------------------------------

[Command]
name = "recovery" ;�K�{�R�}���h��
command = a+b
time = 1

[Command]
name = "recovery" ;�K�{�R�}���h��
command = x+y
time = 1

;------------------------------------------------------------------------------
;-| �����L�[�{�{�^�� |---------------------------------------------------------

[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;------------------------------------------------------------------------------
;-| �{�^���P�� |---------------------------------------------------------------

[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

[Command]
name = "xy"
command = x+y
time = 1

[Command]
name = "yz"
command = y+z
time = 1

[Command]
name = "xz"
command = x+z
time = 1

[Command]
name = "xyz"
command = x+y+z
time = 1
;---------------------------
[Command]
name = "hold_a"
command = /a

;------------------------------------------------------------------------------
;-| �����L�[ |-----------------------------------------------------------------

[Command]
name = "holdfwd"   ;�K�{�R�}���h��
command = /$F
time = 1

[Command]
name = "holdback"  ;�K�{�R�}���h��
command = /$B
time = 1

[Command]
name = "holdup"    ;�K�{�R�}���h��
command = /$U
time = 1

[Command]
name = "holddown"  ;�K�{�R�}���h��
command = /$D
time = 1

;---------------------------
[command]
name="fwd"
command=F
time=1
[command]
name="back"
command=B
time=1
[command]
name="up"
command=U
time=1
[command]
name="down"
command=D
time=1

[Statedef -1]

;==============================================================================
;Illusion Clone System

[State Ctrl Checker (for Clone System)]
type = VarSet
triggerall = var(28) = 0
trigger1 = roundstate = 2 && ctrl
v = 27   
value = 1
ignorehitpause = 1

[State -1, Distorted Clone Type 1] ;Tick Throw Setup (W/ Uppercut Anti-Air)
type = Helper
triggerall = var(47)<=0
triggerall = var(28) = 0
triggerall = var(29) <= 0
triggerall = var(40)>=715
triggerall = numhelper(6660) = 0
triggerall = Var(59) = 0
triggerall = statetype != A && movetype != H
triggerall = stateno != 300 || (stateno != [800,852]) || (stateno != [1200,1230]) || (stateno = [3000,3999])
trigger1 = command = "c" && command != "holddown" && command != "holdfwd" && command != "holdback"
trigger1 = var(27) = 1
trigger1 = ctrl || (stateno = [195,299]) || (stateno = [301,499]) || (stateno = [1000,1199]) || (stateno = [1300,1599])
ID = 6660
helpertype = player
name = "Khan Clone #1"
pos = 0,0;-330, 0
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)
postype = p1
ownpal = 1
stateno = 6660
ignorehitpause = 1
pausemovetime = 20+(var(47)=[0,420])*(9999999999)
[State -1, Distorted Clone Type 2] ;Grounded Spinny Funny
type = Helper
triggerall = var(47)<=0
triggerall = var(28) = 0
triggerall = var(29) <= 0
triggerall = var(40)>=715
triggerall = numhelper(6660) = 0
triggerall = Var(59) = 0
triggerall = statetype != A && movetype != H
triggerall = stateno != 300 || (stateno != [800,852]) || (stateno != [1200,1230]) || (stateno = [3000,3999])
trigger1 = command = "c" && command = "holddown" && command != "holdfwd" && command != "holdback"
trigger1 = roundstate = 2
trigger1 = ctrl || (stateno = [195,299]) || (stateno = [301,499]) || (stateno = [1000,1199]) || (stateno = [1300,1599])
ID = 6660
helpertype = player
name = "Khan Clone #2"
pos = 0,0;-330, 0
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)
postype = p1
ownpal = 1
stateno = 6661
ignorehitpause = 1
pausemovetime = 20+(var(47)=[0,420])*(9999999999)
[State -1, Distorted Clone Type 3] ;Demon Slayer Slash / Uppercut combo
type = Helper
triggerall = var(47)<=0
triggerall = var(28) = 0
triggerall = var(29) <= 0
triggerall = var(40)>=715
triggerall = numhelper(6660) = 0
triggerall = Var(59) = 0
triggerall = stateno != 300 || (stateno != [800,852]) || (stateno != [1200,1230]) || (stateno = [3000,3999])
triggerall = statetype != A && movetype != H
trigger1 = command = "c" && command != "holddown" && command = "holdfwd" && command != "holdback"
trigger1 = roundstate = 2
trigger1 = ctrl || (stateno = [195,299]) || (stateno = [301,499]) || (stateno = [1000,1199]) || (stateno = [1300,1599])
ID = 6660
helpertype = player
name = "Khan Clone #3"
pos = 0,0;-330, 0
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)
postype = p1
ownpal = 1
stateno = 6662
ignorehitpause = 1
pausemovetime = 20+(var(47)=[0,420])*(9999999999)
[State -1, Distorted Clone Type 4] ;Basic Jump In Combo
type = Helper
triggerall = var(47)<=0
triggerall = var(28) = 0
triggerall = var(29) <= 0
triggerall = var(40)>=715
triggerall = numhelper(6660) = 0
triggerall = Var(59) = 0
triggerall = statetype != A && movetype != H
triggerall = stateno != 300 || (stateno != [800,852]) || (stateno != [1200,1230]) || (stateno = [3000,3999])
trigger1 = command = "c" && command != "holddown" && command != "holdfwd" && command = "holdback"
trigger1 = var(27) = 1
trigger1 = ctrl || (stateno = [195,299]) || (stateno = [301,499]) || (stateno = [1000,1199]) || (stateno = [1300,1599])
ID = 6660
helpertype = player
name = "Khan Clone #4"
pos = 0,0;-330, 0
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)
postype = p1
ownpal = 1
stateno = 6663
ignorehitpause = 1
pausemovetime = 20+(var(47)=[0,420])*(9999999999)
;----------------------------
;AI Versions
[State -1, Distorted Clone Type 1] ;Tick Throw Setup (W/ Uppercut Anti-Air)
type = Helper
triggerall = var(28) = 0
triggerall = var(29) <= 0
triggerall = var(40)>=715
triggerall = numhelper(6660) = 0
triggerall = Var(59) != 0
triggerall = statetype != A && movetype != H
triggerall = stateno != 300 || (stateno != [800,852]) || (stateno != [1200,1230]) ;|| (stateno = [3000,3999])
triggerall=var(41)>2
trigger1=playerid(var(8)),statetype!=l
trigger1=playerid(var(8)),movetype!=a
trigger1=gametime%10=0&&random<=300
trigger1 = floor(fvar(39))>=-30&&floor(fvar(38))>=50&&floor(fvar(38))<=150
trigger1 = var(27) = 1
trigger1 = ctrl|| (stateno = [1000,1199]) || (stateno = [1300,1599])
ID = 6660
helpertype = player
name = "Khan Clone #1"
pos = 0,0;-330, 0
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)
postype = p1
ownpal = 1
stateno = 6660+random%2*2
ignorehitpause = 1
pausemovetime = 20+(var(47)=[0,420])*(9999999999)

[State -1, Distorted Clone Type 1] ;Tick Throw Setup (W/ Uppercut Anti-Air)
type = Helper
triggerall = var(28) = 0
triggerall = var(29) <= 0
triggerall = var(40)>=715
triggerall = numhelper(6660) = 0
triggerall = Var(59) != 0
triggerall = statetype != A && movetype != H
triggerall = stateno != 300 || (stateno != [800,852]) || (stateno != [1200,1230]) ;|| (stateno = [3000,3999])
triggerall=var(41)>1
trigger1=gametime%5=0&&random<=300
trigger1 = moveguarded
trigger1 = var(27) = 1
trigger1 = ctrl || (stateno = [200,299]) || (stateno = [301,499]) || (stateno = [1000,1199]) || (stateno = [1300,1599])
ID = 6660
helpertype = player
name = "Khan Clone #1"
pos = 0,0;-330, 0
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)
postype = p1
ownpal = 1
stateno = 6660+random%2*2
ignorehitpause = 1
pausemovetime = 20+(var(47)=[0,420])*(9999999999)

[State -1, Distorted Clone Type 2 AI] ;Grounded Spinny Funny
type = Helper
triggerall=alive&&roundstate=2
triggerall = var(28) = 0
triggerall = var(29) <= 0
triggerall = var(40)>=715
triggerall = numhelper(6660) = 0
triggerall = Var(59) != 0
triggerall = statetype != A && movetype != H
triggerall = stateno != 300 || (stateno != [800,852]) || (stateno != [1200,1230]) ;|| (stateno = [3000,3999])
trigger1 = movecontact
trigger1 = var(53)=6
trigger1 = roundstate = 2
trigger1 = stateno=400
ID = 6660
helpertype = player
name = "Khan Clone #2"
pos = 0,0;-330, 0
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)
postype = p1
ownpal = 1
stateno = 6661
ignorehitpause = 1
pausemovetime = 20+(var(47)=[0,420])*(9999999999)
[State -1, Distorted Clone Type 4 AI] ;Basic Jump In Combo
type = Helper
triggerall=alive&&roundstate=2
triggerall = var(28) = 0
triggerall = var(29) <= 0
triggerall = var(40)>=715
triggerall = numhelper(6660) = 0
triggerall = Var(59) != 0
triggerall = statetype != A && movetype != H
triggerall = stateno != 300 || (stateno != [800,852]) || (stateno != [1200,1230]) ;|| (stateno = [3000,3999])
triggerall=movecontact=[1,2]
triggerall = var(27) = 1
triggerall=random<=300
trigger1 =stateno=212
trigger2=stateno=222&&animelemtime(2)>0
ID = 6660
helpertype = player
name = "Khan Clone #4"
pos = 0,0;-330, 0
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)
postype = p1
ownpal = 1
stateno = 6663
ignorehitpause = 1
pausemovetime = 20+(var(47)=[0,420])*(999999999)

[State -1, Distorted Clone Type 2 AI] ;Grounded Spinny Funny
type = Helper
triggerall=alive&&roundstate=2
triggerall = var(28) = 0
triggerall = var(29) <= 0
triggerall = var(40)>=715
triggerall = numhelper(6660) = 0
triggerall = Var(59) != 0
triggerall = statetype != A && movetype != H
triggerall = stateno != 300 || (stateno != [800,852]) || (stateno != [1200,1230]) ;|| (stateno = [3000,3999])
triggerall=var(41)>1
trigger1 = ((random<=100||(playerid(var(8)),movetype=a&&random<=250))&&playerid(var(8)),movetype!=h)||playerid(var(8)),stateno=5120
trigger1=floor(fvar(38))=[-20,80]
trigger1=floor(fvar(39))>=-60
trigger1 = ctrl || (stateno = [200,299]) || (stateno = [301,499]) || (stateno = [1000,1199]) || (stateno = [1300,1599])
ID = 6660
helpertype = player
name = "Khan Clone #2"
pos = 0,0;-330, 0
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)
postype = p1
ownpal = 1
stateno = 6661
ignorehitpause = 1
pausemovetime = 20+(var(47)=[0,420])*(9999999999)
;==============================================================================

[State -1, �ꑾ��]
type = ChangeState
triggerall = var(47)<=0
triggerall = var(29) != 1
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "spinspin"
triggerall = power >= 3000
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time >= 15) || stateno = 40
trigger2 = stateno = 200 
trigger3 = stateno = 210 
trigger4 = stateno = 212 
trigger5 = stateno = 220
trigger6 = stateno = 222
trigger7 = stateno = 400 
trigger8 = stateno = 410 || stateno = 420
trigger9 = stateno = 195 && time >= 20
trigger10 = stateno = 5201
trigger11 = stateno = 1000
trigger12 = stateno = 1300
trigger13 = stateno = 1100 && var(2) = 2
value = 4000

[State -1, �c�[�a]
type = ChangeState
triggerall = !numhelper(3200600)
triggerall = var(47)<=0
triggerall = var(29) <= 0
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "28aa"
triggerall = power >= 2000
triggerall = !var(0)
triggerall = !var(34)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time >= 15) || (stateno = [40,52])
value = 3200

[State -1, �c�[�a]
type = ChangeState
triggerall = var(47)<=0
triggerall = var(29) != 1
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "236aa" || command = "236b" ;|| (var(36)&2**7)
triggerall = !var(0)
triggerall = !var(34)
triggerall = power >= 1000
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time >= 15) || stateno = 40
trigger2 = stateno = 200 
trigger3 = stateno = 210 
trigger4 = stateno = 212
trigger5 = stateno = 220 
trigger6 = stateno = 222
trigger7 = stateno = 400 
trigger8 = stateno = 410 || stateno = 420
trigger9 = stateno = 195 && time >= 20
trigger10 = stateno = 5201
trigger11 = stateno = 1000
trigger12 = stateno = 1300
trigger13 = stateno = 1100 && var(2) = 2
value = 3000

[State -1, �ꑾ��]
type = ChangeState
triggerall = var(47)<=0
triggerall = var(29) != 1
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "214aa" || command = "214b" ;|| (var(36)&2**8)
triggerall = !var(0)
triggerall = !var(34)
triggerall = power >= 1000
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time >= 15) || stateno = 40
trigger2 = stateno = 200 
trigger3 = stateno = 210 
trigger4 = stateno = 212 
trigger5 = stateno = 220 
trigger6 = stateno = 222
trigger7 = stateno = 400 
trigger8 = stateno = 410 || stateno = 420
trigger9 = stateno = 195 && time >= 20
trigger10 = stateno = 5201
trigger11 = stateno = 1000
trigger12 = stateno = 1300
trigger13 = stateno = 1100 && var(2) = 2
value = 3100

;==============================================================================
; �K�E�Z
;==============================================================================


[State -1, 11000]
type = ChangeState
triggerall = var(47)<=0
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall =  command = "46x" || command = "46y" || command = "46z" || command = "46b"
triggerall = !var(34)
trigger1 = ctrl
trigger2 = StateNo = 620 && animelemtime(3) > 1
trigger3 = StateNo = 610 && animelemtime(2) > 1
value = 1500

[State -1, 11000]
type = ChangeState
triggerall = var(47)<=0
triggerall = var(28) = 0
triggerall = !var(59) 
triggerall = NumHelper(1401) = 0 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "623a" ;|| (var(35)&2**3)
triggerall = !var(34)
trigger1 = ctrl || (stateno = 100 || stateno = 105) || stateno = 40
trigger2 = stateno = 200 
trigger3 = stateno = 210 
trigger4 = stateno = 212
trigger5 = stateno = 220
trigger6 = stateno = 222
trigger7 = stateno = 400 
trigger8 = stateno = 410 || stateno = 420
trigger9 = stateno = 195 && time >= 20
trigger10 = stateno = 1000
trigger11 = stateno = 1300
value = 1400

[State -1, 11000]
type = ChangeState
triggerall = !var(59)
triggerall = var(47)<=0
triggerall = var(28) = 0
triggerall = var(29) != 1
triggerall=!numhelper(1621)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "22a"
triggerall = !var(34)
trigger1 = ctrl || (stateno = 100 || stateno = 105) || stateno = 40
value = 1600

[State -1, 11000]
type = ChangeState
triggerall = var(47)<=0 
;triggerall = var(29) != 1
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "46x" || command = "46y" || command = "46z" || command = "46b" ;|| (var(36)&2**0) || (var(36)&2**1) || (var(36)&2**2)
triggerall = !var(34)
trigger1 = ctrl || (stateno = 100 || stateno = 105) || stateno = 40
trigger2 = stateno = 200 
trigger3 = stateno = 210 
trigger4 = stateno = 212
trigger5 = stateno = 220
trigger6 = stateno = 222
trigger7 = stateno = 400 
trigger8 = stateno = 410 || stateno = 420
trigger9 = stateno = 195 && time >= 20
trigger10 = stateno = 1300
value = ifelse(command="46x",1001,1000)

[State -1, 11000]
type = ChangeState
triggerall = var(47)<=0
triggerall = var(29) != 1
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "623x" || command = "623y" || command = "623z" || command = "623b" ;|| (var(36)&2**0) || (var(36)&2**1) || (var(36)&2**2)
triggerall = !var(34)
trigger1 = ctrl || (stateno = 100 || stateno = 105) || stateno = 40
trigger2 = stateno = 200 
trigger3 = stateno = 210 
trigger4 = stateno = 212 
trigger5 = stateno = 220 
trigger6 = stateno = 222
trigger7 = stateno = 400 
trigger8 = stateno = 410 || stateno = 420
trigger9 = stateno = 1000
trigger10 = stateno = 195 && time >= 20
trigger11 = stateno = 5201
trigger12 = stateno = 5120
trigger13 = stateno = 1300
value = ifelse(command = "623y",1110,ifelse(command = "623x",1101,1100))

;�������b�I
[State -1, Taunt]
type = ChangeState
triggerall = var(47)<=0
triggerall = var(29) != 1
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "214x" || command = "214y" || command = "214z" ;|| (var(36)&2**6)
triggerall = statetype != A
triggerall = !var(34)
trigger1 = ctrl || (stateno = 100 || stateno = 105) || stateno = 40
trigger2 = stateno = 200
trigger3 = stateno = 210 
trigger4 = stateno = 212 
trigger5 = stateno = 220
trigger6 = stateno = 222
trigger7 = stateno = 400 
trigger8 = stateno = 410 || stateno = 420
trigger9 = stateno = 195 && time >= 20
trigger10 = stateno = 5201
trigger11 = stateno = 1300
value = ifelse(command = "214y",1201,ifelse(command = "214z",1202,1200))

;==============================================================================
; �ړ��֘A
;==============================================================================
[State -1,Run]
type = ChangeState
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype = S
triggerall = command = "FF"
trigger1 = ctrl
value = 100

[State -1, Back Run]
type = ChangeState
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype = S
triggerall = command = "BB"
trigger1 = ctrl
value = 105

[State -1, Double Jump (Player Only)]
type = ChangeState
triggerall = !var(59)
triggerall = !var(1)
triggerall = command = "holdup"
triggerall = statetype = A
trigger1 = ctrl 
value = 48

[State -1, Taunt�]
type = ChangeState
value = 195
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = command = "start"
trigger1 = statetype != A
trigger1 = ctrl
;==============================================================================
; ����Z
;==============================================================================
[State -1, �K�[�h�L�����Z��]
type = ChangeState
triggerall = var(29) != 1
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "623x" || command = "623y" || command = "623z"
triggerall = prevstateno != [710,711]
trigger1 = (stateno = [150,153])
trigger1 = time <= 5
trigger2 = (stateno = [150,153])
trigger2 = time > 0
value = 700

[State -1, �K�[�h�L�����Z��-AI]
type = ChangeState
triggerall = var(29) != 1
triggerall = var(28) = 0
triggerall = var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = prevstateno != [710,711]
triggerall=random<=150
triggerall=floor(fvar(38))=[-20,50]
triggerall=floor(fvar(39))>=-100
trigger1 = (stateno = [150,153])
trigger1 = time <= 5
trigger2 = power >= 500
trigger2 = (stateno = [150,153])
trigger2 = time > 0
value = 700

[State -1, �A�h�o���V���O�K�[�h]
type = ChangeState
triggerall = var(29) != 1
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "recovery" || command = "b"
triggerall = prevstateno != [710,711]
;triggerall = ((helper(20032*(numhelper(20032)>0)),var(10)) = 0)
trigger1 = stateno = [150,153]
trigger1 = time > 0
value = 710

[State -1, ��荞��]
type = ChangeState
triggerall = var(29) != 1
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "xyz" || command = "b"
triggerall = !var(56)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time >= 3)
value = 300

[State -1, 4�f��]
type = ChangeState
triggerall = var(47)<=0
triggerall = !var(59)
triggerall = !var(34)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = command = "z" && (command = "holdfwd" || command = "holdback")
triggerall = p2statetype = A && p2statetype != L && p2movetype != H
triggerall = p2bodydist X < 35
trigger1 = ctrl
value = 849

[State -1,  ����]
type = ChangeState
triggerall = var(47)<=0
;triggerall = var(29) != 1
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "z" && command != "holddown" && (command = "holdfwd" || command = "holdback")
triggerall = p2bodydist x = [-25,25]
triggerall = p2statetype != A && p2statetype != L && p2movetype != H
trigger1 = ctrl || stateno = 195
value = 800

[State -1, �A�؎a]
type = ChangeState
triggerall = var(29) != 1
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "a" ;|| (var(35)&2**3)
triggerall = !var(34)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time >= 3) || stateno = 40
trigger2 = stateno = 200 
trigger3 = stateno = 210 
trigger4 = stateno = 212 
trigger5 = stateno = 220
trigger6 = stateno = 222
trigger7 = stateno = 400
trigger8 = stateno = 410 
trigger9 = stateno = 195 && time >= 20
trigger10=movecontact&&ishelper(3200600)
trigger10=stateno=200||stateno=210||stateno=220||stateno=212||stateno=400||stateno=410||stateno=420
value = 1300

[State -1, �A�؎aAIR]
type = ChangeState
triggerall = var(29) != 1
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = command = "a" ;|| (var(35)&2**3)
triggerall = !var(34)
trigger1 = ctrl
trigger2 = stateno = 610
trigger3 = stateno = 620
value = 1350

[State -1, 4��]
type = ChangeState
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "y" && command = "holdback" && command != "holddown"
triggerall = !var(34)
trigger1 = ctrl
trigger2 = StateNo = 200 && animelemtime(3) > 1
trigger3=movecontact&&ishelper(3200600)
trigger3=stateno=200||stateno=210||stateno=220||stateno=212||stateno=400||stateno=410||stateno=420
value = 212

;==============================================================================
; �ʏ�U���Z
;==============================================================================
[State -1, Soff��]
type = ChangeState
triggerall = !var(59)
triggerall = var(28) = 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "x" || (command = "b" && var(56)>0)) && command != "holddown"
triggerall = !var(34)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time >= 3)
trigger2 = StateNo = 200 && animelemtime(3) > 1
trigger3 = StateNo = 400 && (prevstateno != [100,105]) && animelemtime(3) > 1
trigger4=movecontact&&ishelper(3200600)
trigger4=stateno=200||stateno=210||stateno=220||stateno=212||stateno=400||stateno=410||stateno=420
value = 200

[State -1, Soff��]
type = ChangeState
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "y" && command != "holddown"
triggerall = !var(34)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time >= 3)
trigger2 = StateNo = 200 && animelemtime(3) > 1
trigger3=movecontact&&ishelper(3200600)
trigger3=stateno=200||stateno=210||stateno=220||stateno=212||stateno=400||stateno=410||stateno=420
value = 210

[State -1, Soff��]
type = ChangeState
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "z" && command != "holddown"
triggerall = !var(34)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time >= 3)
trigger2=movecontact&&ishelper(3200600)
trigger2=stateno=200||stateno=210||stateno=220||stateno=212||stateno=400||stateno=410||stateno=420
value = 220

[State -1, ��2]
type = ChangeState
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "z" && command != "holddown"
triggerall = !var(34)
trigger1 = (stateno = 220 && time >=15)
trigger3=movecontact&&ishelper(3200600)
trigger3=stateno=200||stateno=210||stateno=220||stateno=212||stateno=400||stateno=410||stateno=420
value = 222

[State -1, Soff����]
type = ChangeState
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command = "x" || (command = "b" && var(56)>0)) && command = "holddown"
triggerall = !var(34)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time >= 3)
trigger2 = StateNo = 200 && (prevstateno != [100,105]) && animelemtime(4) > 0
trigger3 = StateNo = 400 && (prevstateno != [100,105]) && animelemtime(3) > 1
trigger4=movecontact&&ishelper(3200600)
trigger4=stateno=200||stateno=210||stateno=220||stateno=212||stateno=400||stateno=410||stateno=420
value = 400

[State -1, Soff����]
type = ChangeState
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "z" && command = "holddown"
triggerall = !var(34)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time >= 3)
trigger2 = StateNo = 200 && animelemtime(3) > 1
trigger3 = StateNo = 210 && animelemtime(3) > 1
trigger4 = StateNo = 212 && animelemtime(3) > 1
trigger5 = StateNo = 220 && animelemtime(3) > 1
trigger6 = StateNo = 222 && animelemtime(3) > 1
trigger7 = StateNo = 400 && animelemtime(3) > 1
trigger8=movecontact&&ishelper(3200600)
trigger8=stateno=200||stateno=210||stateno=220||stateno=212||stateno=400||stateno=410||stateno=420
value = 410

[State -1, Soff����]
type = ChangeState
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "y" && command = "holddown"
triggerall = !var(34)
trigger1 = ctrl || ((stateno = 100 || stateno = 105) && time >= 3)
trigger2=movecontact&&ishelper(3200600)
trigger2=stateno=200||stateno=210||stateno=220||stateno=212||stateno=400||stateno=410||stateno=420
value = 420
;-------------------------------------------------------------------------------
[State -1, Soff�W�����v��]
type = ChangeState
value = 600
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = command = "y"
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 620 && animelemtime(3) > 1
trigger3 = StateNo = 610 && animelemtime(2) > 1

[State -1, Soff�W�����v��]
type = ChangeState
value = 610
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = command = "x" || command = "b"
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl

[State -1, Soff�W�����v��]
type = ChangeState
value = 620
triggerall = var(28) = 0
triggerall = !var(59)
triggerall = command = "z"
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 610 && animelemtime(3) > 1
;----------------------------------------------------------------------------------------------------------------------------------------
[State Khans] ;only activates against certain versions of Khan. meant to be a fun little easter egg, its not an anti-cheat.
type = VarSet
triggerall=numenemy
triggerall = !ishelper
trigger1 = enemynear,name = "PsychicKhan" || enemynear,name = "Khan Over Heaven" || enemynear,name = "Over Heaven Khan"
v = 28   ;fv = 10
value = 1
ignorehitpause = 1

[State KHAMPSTER!]
type = ChangeState
triggerall = var(28) = 1
triggerall = !ishelper
triggerall = alive
triggerall = stateno != 195
trigger1 = roundstate = 2 && ctrl 
value = 195
ctrl = 0